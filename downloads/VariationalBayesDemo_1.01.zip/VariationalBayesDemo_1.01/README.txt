Interactive comparison of the Laplace approximation and variational Bayes
=========================================================================

To run the demo, extract all files into a directory.

In MATLAB, change to this directory, then type:
vb_gui

Contact:
Kay H. Brodersen
khbrodersen@gmail.com
