% Approximate Bayesian inference demo. Compares the Laplace approximation with a
% variational approximation.
% 
% MATLAB code for vb_gui.fig
% 
% Usage:
%     vb_gui     - creates a new VB_GUI or raises the existing singleton
%
%     h = vb_gui - returns the handle to a new or the existing instance
%
%     vb_gui('CALLBACK',hObject,eventData,handles,...)
%                - calls the local function named CALLBACK
%
%     vb_gui('Property','Value',...) creates a new VB_GUI or raises the
%     existing singleton*.  Starting from the left, property value pairs are
%     applied to the GUI before vb_gui_OpeningFcn gets called.  An
%     unrecognized property name or invalid value makes property application
%     stop.  All inputs are passed to vb_gui_OpeningFcn via varargin.

% Last Modified by GUIDE v2.5 21-Mar-2014 22:21:08
% Kay H. Brodersen, ETH Zurich
% ------------------------------------------------------------------------------
function varargout = vb_gui(varargin)

    % Begin initialization code - DO NOT EDIT
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
                       'gui_Singleton',  gui_Singleton, ...
                       'gui_OpeningFcn', @vb_gui_OpeningFcn, ...
                       'gui_OutputFcn',  @vb_gui_OutputFcn, ...
                       'gui_LayoutFcn',  [] , ...
                       'gui_Callback',   []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
    % End initialization code - DO NOT EDIT
end

% ------------------------------------------------------------------------------
% Draws the plot.
function draw_plot(handles)

    % ===============================================
    % Specify unnormalized density to be approximated
    a = get(handles.slider_a, 'value');
    b = get(handles.slider_b, 'value');
    c = get(handles.slider_c, 'value');
    L = @(x) exp(-x.^2./a).*sigm(b.*x+c);
    % ===============================================
    
    % Laplace approximation
    laplace_mu    = NaN;
    laplace_sigma = NaN;
    if get(handles.chk_laplace,'value')
        %
        % (1) find mode
        negL = @(x) -L(x);
        laplace_mu = fminsearch(negL, 0);
        %
        % (2) evaluate curvature at the mode
        h   = 1e-5;
        dL  = @(x) (L(x+h)  - L(x))  / h;
        d2L = @(x) (dL(x+h) - dL(x)) / h;
        eta = -d2L(laplace_mu);
        laplace_sigma = 1/sqrt(eta);
    end
    
    % Variational approximation
    vb_mu    = NaN;
    vb_sigma = NaN;
    if get(handles.chk_vb,'value')
        %
        % (1) find expression for the free energy
        grid = -10:0.01:10;
        F = @(mu_logeta) trapz(grid, ...
            normpdf(grid,mu_logeta(1),1/sqrt(exp(mu_logeta(2)))) ...
            .* log(L(grid))) ...
            + 1/2 * (log(2*pi) + 1 - log(exp(mu_logeta(2))));
        %
        % (2) find mu and eta that maximize F
        negF = @(mu_logeta) -F(mu_logeta);
        [opt,free_energy] = fminsearch(negF, [0, 0]);
        vb_mu = opt(1);
        vb_sigma = 1/sqrt(exp(opt(2)));
    end
    
    % Prepare plot
    % Colors: 1:grey 2:green 3:black 4:red 5:blue 6:light-grey
    colors = [140 140 140;0 178 82;0 0 0;214 32 32;0 112 222;220 220 220]/255;
    xmin = min([norminv(0.001,laplace_mu,laplace_sigma), ...
                norminv(0.001,vb_mu,     vb_sigma)]);
    xmax = max([norminv(0.999,laplace_mu,laplace_sigma), ...
                norminv(0.999,vb_mu,     vb_sigma)]);
    if isnan(xmin), xmin = 0; end
    if isnan(xmax), xmax = 5; end
    x = linspace(xmin,xmax,1000);
    
    % Plot unnormalized posterior
    p = L(x);
    hold off;
    hs = plot(x,p,'-','color',colors(2,:),'linewidth',2);
    set(hs,'visible','off')
    plotfill(x,zeros(1,length(x)),p,'color',[153 217 165]/255,...
        'transparency',1,'edgecolor',[1 1 1]);
    legends = {'underlying density'};
    hold on;
    
    % Plot Laplace approximation
    if get(handles.chk_laplace,'value')
        qL = normpdf(x,laplace_mu,laplace_sigma);
        hs = [hs, plot(x,qL,'-','color',colors(3,:),'linewidth',2)];
        legends{length(legends)+1} = ['Laplace N(',...
          sprintf('%0.2f',laplace_mu),', ',sprintf('%0.2f',laplace_sigma),')'];
    end
    
    % Plot variational approximation
    if get(handles.chk_vb,'value')
        qVB = normpdf(x,vb_mu,vb_sigma);
        hs = [hs, plot(x,qVB,'-','color',colors(5,:),'linewidth',2)];
        legends{length(legends)+1} = ['Variational N(',...
          sprintf('%0.2f',vb_mu),', ',sprintf('%0.2f',vb_sigma),')'];
    end
    
    % Finalize plot
    axis tight;
    v=axis; v(4)=v(4)*1.05; axis(v);
    legend(hs,legends,'location','northwest');
    legend(gca,'boxoff')

    
    set(handles.text_a,'string',['a = ',num2str(a)]);
    set(handles.text_b,'string',['b = ',num2str(b)]);
    set(handles.text_c,'string',['c = ',num2str(c)]);
end

% ------------------------------------------------------------------------------
% Executes just before vb_gui is made visible.
function vb_gui_OpeningFcn(hObject, eventdata, handles, varargin)
    % This function has no output args, see OutputFcn.
    % hObject    handle to figure
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    % varargin   command line arguments to vb_gui (see VARARGIN)

    % Choose default command line output for vb_gui
    handles.output = hObject;

    % Update handles structure
    guidata(hObject, handles);

    % This sets up the initial plot - only do when we are invisible
    % so window can get raised using vb_gui.
    if strcmp(get(hObject,'Visible'),'off')
        % This sets the initial Gamma parameters
        set(handles.slider_a,'value',2);
        set(handles.slider_b,'value',20);
        set(handles.slider_c,'value',0);
        draw_plot(handles);
    end

    % UIWAIT makes vb_gui wait for user response (see UIRESUME)
    % uiwait(handles.figure1);
end

% ------------------------------------------------------------------------------
% Outputs from this function are returned to the command line.
function varargout = vb_gui_OutputFcn(hObject, eventdata, handles)
    % varargout  cell array for returning output args (see VARARGOUT);

    % Get default command line output from handles structure
    varargout{1} = handles.output;
end

% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
    file = uigetfile('*.fig');
    if ~isequal(file, 0)
        open(file);
    end
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
    printdlg(handles.figure1)
end

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
    selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                         ['Close ' get(handles.figure1,'Name') '...'],...
                         'Yes','No','Yes');
    if strcmp(selection,'No')
        return;
    end
    delete(handles.figure1)
end

% ------------------------------------------------------------------------------
% Executes on slider movement.
function slider_b_Callback(hObject, eventdata, handles)
    draw_plot(handles);
end

% ------------------------------------------------------------------------------
% Executes during object creation, after setting all properties.
function slider_b_CreateFcn(hObject, eventdata, handles)
    % Hint: slider controls usually have a light gray background.
    if isequal(get(hObject,'BackgroundColor'),...
        get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end
end

% ------------------------------------------------------------------------------
% Executes on slider movement.
function slider_a_Callback(hObject, eventdata, handles)
    draw_plot(handles);
end

% ------------------------------------------------------------------------------
% Executes during object creation, after setting all properties.
function slider_a_CreateFcn(hObject, eventdata, handles)
    % Hint: slider controls usually have a light gray background.
    if isequal(get(hObject,'BackgroundColor'),...
        get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end
end
    
% ------------------------------------------------------------------------------
% Executes on slider movement.
function slider_c_Callback(hObject, eventdata, handles)
    draw_plot(handles);
end

% ------------------------------------------------------------------------------
% Executes during object creation, after setting all properties.
function slider_c_CreateFcn(hObject, eventdata, handles)
    % Hint: slider controls usually have a light gray background.
    if isequal(get(hObject,'BackgroundColor'),...
        get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor',[.9 .9 .9]);
    end
end

% ------------------------------------------------------------------------------
% Executes on button press in chk_laplace.
function chk_laplace_Callback(hObject, eventdata, handles)
    draw_plot(handles);
end

% ------------------------------------------------------------------------------
% Executes on button press in chk_vb.
function chk_vb_Callback(hObject, eventdata, handles)
    draw_plot(handles);
end

% ------------------------------------------------------------------------------
% Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
    % Get new figure position
    fpos = get(hObject,'position');  % left bottom width height (pixels)

    % Set axes
    apos = get(handles.axes1,'position');
    apos = [50, 210, fpos(3)-70, fpos(4)-20-210];
    set(handles.axes1,'position',apos);

    % Set white background panel
    ppos = get(handles.bgpanel,'position');
    ppos = [0, 170, fpos(3)+10, fpos(4)+10];
    set(handles.bgpanel,'position',ppos);
end
    
