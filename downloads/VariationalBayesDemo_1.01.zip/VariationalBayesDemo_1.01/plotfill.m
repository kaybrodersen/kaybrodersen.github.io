% Draws the area between two curves.
%
% Usage:
%     [handle, msg] = plotfill(x, y1, y2, varargin)
%
% Arguments:
%     x: horizontal positions (must be a ROW vector)
%     y1: lower bound data points
%     y2: upper bound data points
%
% Optional named arguments:
%     color: color of the area
%     edge: color of the edge
%     add: whether to add this area to an existing plot
%     transparency: degree of transparency (0=invisible...1=opaque)
% 
% Modified from original code by John A. Bockstege.

% ----------- ORIGINAL DESCRIPTION ----------------------------------------
%USAGE: [fillhandle,msg]=jbfill(xpoints,upper,lower,color,edge,add,transparency)
%This function will fill a region with a color between the two vectors provided
%using the Matlab fill command.
%
%fillhandle is the returned handle to the filled region in the plot.
%xpoints= The horizontal data points (ie frequencies). Note length(Upper)
%         must equal Length(lower)and must equal length(xpoints)!
%upper = the upper curve values (data can be less than lower)
%lower = the lower curve values (data can be more than upper)
%color = the color of the filled area 
%edge  = the color around the edge of the filled area
%add   = a flag to add to the current plot or make a new one.
%transparency is a value ranging from 1 for opaque to 0 for invisible for
%the filled color only.
%
%John A. Bockstege November 2006;
%Example:
%     a=rand(1,20);%Vector of random data
%     b=a+2*rand(1,20);%2nd vector of data points;
%     x=1:20;%horizontal vector
%     [ph,msg]=jbfill(x,a,b,rand(1,3),rand(1,3),0,rand(1,1))
%     grid on
%     legend('Datr')
% -------------------------------------------------------------------------

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [handle, msg] = plotfill(x, y1, y2, varargin)

    % Set defaults
    defaults.color = 'b';
    defaults.edgecolor = 'k';
    defaults.add = 1;
    defaults.transparency = 0.5;
    defaults.edgeTransparency = 0;
    args = propval(varargin, defaults, 'strict', false);
    
    if (size(x,1) ~= 1), warning('x should be a row vector'); end
    
    if length(y2)==length(y1) && length(y1)==length(x)
        msg='';

        % Remove NaN values
        n = isnan(x)+isnan(y1)+isnan(y2);
        x = x(~n);
        y1 = y1(~n);
        y2 = y2(~n);
        
        filled=[y2,fliplr(y1)];
        x=[x,fliplr(x)];
        if args.add
            h = ishold;
            hold on
        end
        handle=fill(x,filled,args.color);%plot the data
        set(handle,...
            'FaceAlpha',args.transparency,...
            'EdgeColor',args.edgecolor,...
            'EdgeAlpha',args.edgeTransparency);
        if args.add
            if h
                hold on
            else
                hold off
            end
        end
    else
        msg='Error: Must use the same number of points in each vector';
    end
    
end
