% Simple skeleton for an fMRI classification analysis.

% Kay H. Brodersen & Ekaterina I. Lomakina, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% Modified: 24/02/2012
% -------------------------------------------------------------------------
function simple_classifier
    
    % Load data
    load ../data/fmri.mat
    nTrials = size(fmri,4);
    
    % Load mask
    load ../data/mask.mat
    nVoxels = sum(sum(sum(mask>0)));
    
    % Load labels
    load ../data/labels.mat
    
    % Create FEATURES x EXAMPLES matrix
    mask = repmat(mask, [1 1 1 nTrials]);
    data = reshape(fmri(mask>0), nVoxels, nTrials);
    
    % Begin leave-one-out cross-validation
    for t = 1:nTrials
        disp(['Cross-validation fold ', num2str(t), ' / ', num2str(nTrials)]);
        
        % Split up data into train and test data
        test_trials = t;
        train_trials = [1:t-1, t+1:nTrials];
    
        % Train classifier
        model = svmtrain(labels(train_trials)', data(:,train_trials)', '-t 0');
        
        % Test classifier on the left-out trial
        predicted_labels(t) = svmpredict(labels(test_trials)', data(:,test_trials)', model);
    end
    
    % Compute overall generalization performance
    Confusion_matrix = confusionmat(predicted_labels, labels)
    balanced_accuracy = bacc_mean(Confusion_matrix);
    p = bacc_p(Confusion_matrix);
    
    % Report result
    disp(' ');
    disp(['Cross-validated balanced accuracy: ', num2str(balanced_accuracy*100), '%']);
    disp(['p = ', num2str(p)]);
    
end
