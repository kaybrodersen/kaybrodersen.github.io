% Simple skeleton for an fMRI classification analysis.
%
% Requires:
%     LIBSVM libsvm-mat-2.91-1 (or later), available from:
%     http://www.csie.ntu.edu.tw/~cjlin/libsvm
%
% Author:
%     Kay H. Brodersen (khbrodersen@gmail.com)
%     Modified: 2014-02-12
% ------------------------------------------------------------------------------
function simple_classifier

    % Add path to LIBSVM
    addpath /terra/workspace/kbroders/studies/ana/tools/libsvm-mat-2.91-1
    
    % Add path to PosteriorBalancedAccuracy
    % http://www.mathworks.com/matlabcentral/fileexchange/29244
    addpath balacc_1.06
    
    % Load data
    load ../data/fmri.mat
    nTrials = size(fmri, 4);
    
    % Load mask
    load ../data/mask.mat
    nVoxels = sum(sum(sum(mask > 0)));
    
    % Load labels
    load ../data/labels.mat
    
    % Transform labels from [1 2] to [1 -1]
    labels(labels == 2) = -1;
    
    % Create FEATURES x EXAMPLES matrix
    mask = repmat(mask, [1 1 1 nTrials]);
    data = reshape(fmri(mask > 0), nVoxels, nTrials);

    % Initialize predictions
    predicted_labels = [];

    % Begin leave-one-out cross-validation
    for t = 1 : nTrials
        disp(['Cross-validation fold ', num2str(t), ' / ', num2str(nTrials)]);
        
        % Split up data into train and test data
        test_trials = t;
        train_trials = [1 : t - 1, t + 1 : nTrials];
        
        % Train classifier
        train_data = data(:, train_trials);
        train_labels = labels(train_trials);
        model = svmtrain(train_labels', train_data', '-t 0');
        
        % Test classifier on the left-out trial
        test_data = data(:, test_trials);
        test_labels = labels(:, test_trials);
        predicted_labels = [predicted_labels, ...
                            svmpredict(ones(size(test_data, 2), 1), ...
                                       test_data', model)];
    end
    
    % Compute sample accuracy
    correct_trials = (predicted_labels == labels);
    sample_accuracy = sum(correct_trials) / nTrials;
    p_accuracy = 1 - binocdf(sum(correct_trials), nTrials, 0.5);
    disp(' ');
    disp(['Cross-validated sample accuracy: ', ...
          num2str(sample_accuracy * 100), '%']);
    disp(['p = ', num2str(p_accuracy)]);
    
    % Compute balanced accuracy
    C = confusionmat(labels, predicted_labels);
    balanced_accuracy = bacc_mean(C);
    p_balanced_accuracy = bacc_p(C);
    disp(' ');
    disp(['Cross-validated balanced accuracy: ', ...
          num2str(balanced_accuracy * 100), '%']);
    disp(['p = ', num2str(p_balanced_accuracy)]);
    
    % Plot balanced accuracy (with error bars)
    figure;
    subplot(1, 2, 1);
    [lower, upper] = bacc_ppi(C, 0.05);
    errorbar(0, balanced_accuracy, balanced_accuracy - lower, ...
             upper - balanced_accuracy, 'linewidth', 2)
    hold on;
    plot([-1 1], [0.5 0.5], '-')
    axis([-1 1 0 1])
    
    % Plot balanced accuracy (full distribution)
    subplot(1, 2, 2);
    x = [0:0.01:1];
    y = betaavgpdf(x, C(1, 1) + 1, C(1, 2) + 1, ...
                   C(2, 2) + 1, C(2, 1) + 1);
    plot(x, y, 'linewidth', 2);
    hold on;
    v = axis;
    plot([0.5 0.5], [0 v(4)], '-')
end
