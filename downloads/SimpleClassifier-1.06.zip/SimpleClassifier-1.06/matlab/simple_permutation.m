% Simple skeleton for creating a probabilistic map of feature importance,
% using a permutation test.
%
% Requires:
%   - LIBSVM libsvm-mat-2.91-1 (or later), available from:
%     http://www.csie.ntu.edu.tw/~cjlin/libsvm
%
%   - FSL 5.0 (or later), available from:
%     http://fsl.fmrib.ox.ac.uk/fsldownloads
%
% Authors:
%     Ekaterina I. Lomakina & Kay H. Brodersen
%     Modified: 2014-02-12
% ------------------------------------------------------------------------------
function simple_permutation

    % Add path to LIBSVM
    addpath /terra/workspace/kbroders/studies/ana/tools/libsvm-mat-2.91-1
    
    % Add path to FSL Matlab tools; we will use save_avw() to write an image
    addpath /usr/share/fsl/5.0/etc/matlab
    
    % Load data
    load ../data/fmri.mat
    nTrials = size(fmri,4);
    
    % Load mask
    load ../data/mask.mat
    nVoxels = sum(sum(sum(mask>0)));
    
    % Load labels
    load ../data/labels.mat
    
    % Create FEATURES x EXAMPLES matrix
    mask_full = repmat(mask, [1 1 1 nTrials]);
    data = reshape(fmri(mask_full>0), nVoxels, nTrials);
    
    % Compute weights based on the real labels
    model = svmtrain(labels', data', '-t 0');
    weight_real = (model.sv_coef'*model.SVs)';
    
    % Number of permutations
    nPerm = 20;
    
    % Initialize weights matrix
    weights = zeros(nPerm,nVoxels);
    
    % Run permutations
    for p = 1:nPerm      
        disp(['Permutation ',num2str(p), ' / ',num2str(nPerm)]);
        
        % Shuffle labels randomly
        labels_cur = labels(randperm(nTrials));
        
        % Compute weights based on the shuffled labels  
        model = svmtrain(labels_cur', data', '-t 0');
        weights(p,:) = (model.sv_coef'*model.SVs)';
    end
    
    % Turn real weights into t-scores
    map = (weight_real' - mean(weights))./std(weights);
    
    % Save results
    map_final = zeros(size(mask)); 
    map_final(mask>0) = map;
    save_avw(map_final,'../results/result_t','d',[3 3 3 1]);
    
    % Compute corresponding threshold
    alpha = 0.05;
    thr = tinv(1-alpha/2,nPerm - 1);
    
    disp(['Threshold (alpha ' num2str(p) ') = ' num2str(thr)]);
    
end
