% Deprecated - use bacc_ppi instead.

% $Id: bacc_ci.m 8245 2010-10-22 12:57:51Z bkay $
% -------------------------------------------------------------------------
function [b_lower,b_upper] = bacc_ci(C,alpha)
    
    warning('The use of bacc_ci is deprecated - use bacc_ppi instead');
    [b_lower,b_upper] = bacc_ppi(C,alpha);
    
end
