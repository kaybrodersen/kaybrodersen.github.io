% PDF of the sum of two independently distributed Beta distributions.
%
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: betasumpdf.m 8245 2010-10-22 12:57:51Z bkay $
% -------------------------------------------------------------------------
function y = betasumpdf(x, alpha1, beta1, alpha2, beta2)
    
    % Compute convolution
    res = 0.001; % precision
    c = betaconv(res, alpha1, beta1, alpha2, beta2);
    
    % Prepare return value
    y = NaN(size(x));
    
    % Fill in return value
    % - values outside support
    y(x<0 | x>2) = 0;
    % - values 
    % - all other values
    idx = int32(x/res+1);
    y(isnan(y)) = c(idx(isnan(y)));
    
end
