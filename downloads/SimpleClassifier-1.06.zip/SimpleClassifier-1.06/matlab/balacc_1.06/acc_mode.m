% Most likely accuracy (i.e., the mode of a Beta distribution)
%
% Usage:
%     a = acc_mode(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_mode.m 8245 2010-10-22 12:57:51Z bkay $
% -------------------------------------------------------------------------
function a = acc_mode(C)
    
    if all(size(C)==1)
        a = 1;
    else
        a = (C(1,1)+C(2,2))/sum(sum(C));
    end
    
end
