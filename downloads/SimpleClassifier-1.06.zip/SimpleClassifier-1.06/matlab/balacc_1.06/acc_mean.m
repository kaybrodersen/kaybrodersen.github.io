% Posterior expectation of the accuracy (i.e., the mean of a Beta distribution).
%
% Usage:
%     a = acc_mean(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_mean.m 18931 2013-02-15 10:14:09Z bkay $
% -------------------------------------------------------------------------
function a = acc_mean(C)
    
    % Get alpha and beta
    A = C(1,1) + C(2,2) + 1;
    B = C(1,2) + C(2,1) + 1;
    
    % Compute mean
    a = A / (A + B);
    
end
