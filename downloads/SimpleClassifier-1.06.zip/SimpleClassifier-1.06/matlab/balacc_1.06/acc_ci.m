% Deprected - use acc_ppi instead.

% $Id: acc_ci.m 8245 2010-10-22 12:57:51Z bkay $
% -------------------------------------------------------------------------
function [a_lower,a_upper] = acc_ci(C,alpha)
    
    warning('The use of acc_ci is deprecated - use acc_ppi instead');
    [a_lower,a_upper] = acc_ppi(C,alpha);
    
end
