% Posterior probability interval of a fraction.
% 
% Usage:
%     [f_lower,f_upper] = frac_ppi(k,n,alpha)
% 
% Arguments:
%     k: number of interesting observations
%     n: number of observations in total
%     alpha - The posterior probability interval will cover 1-alpha of
%         probability mass such that (1-alpha)/2 remains on either end of
%         the distribution.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: frac_ppi.m 14789 2012-03-05 09:06:58Z bkay $
% -------------------------------------------------------------------------
function [f_lower,f_upper] = frac_ppi(k,n,alpha)
    
    try, alpha; catch; alpha = 0.05; end
    
    A = k + 1;
    B = n - k + 1;
    
    f_lower = betainv(alpha/2,A,B);
    f_upper = betainv(1-alpha/2,A,B);
    
end
