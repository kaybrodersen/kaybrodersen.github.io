% Convolves two Beta distributions.
%
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: betaconv.m 8246 2010-10-22 13:28:23Z bkay $
% -------------------------------------------------------------------------
function y = betaconv(res, alpha1, beta1, alpha2, beta2)
    
    % Set support
    x = 0:res:2;
    
    % Individual Beta pdfs
    f1 = betapdf(x, alpha1, beta1);
    f2 = betapdf(x, alpha2, beta2);
    
    % Compute convolution
    y = conv(f1, f2);
    
    % Reduce to [0..2] support
    y = y(1:length(x));
    
    % Normalize (so that all values sum to 1/res)
    y = y / (sum(y) * res);
    
    % Debug: visualize
    if 0
        hold off;
        plot(x, f1, 'color', [0,112,192]/255, 'linewidth', 2);
        hold on;
        plot(x, f2, 'color', [0,176,80]/255, 'linewidth', 2);
        plot(x, y, 'color', [192,0,0]/255, 'linewidth', 2);
        legend(['Beta(', num2str(alpha1), ', ', num2str(beta1), ')'], ...
            ['Beta(', num2str(alpha2), ', ', num2str(beta2), ')'], ...
            ['Convolution']);
    end
        
end
