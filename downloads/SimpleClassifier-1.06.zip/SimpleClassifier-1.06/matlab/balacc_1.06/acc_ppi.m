% Posterior probability interval of the accuracy.
% 
% Usage:
%     [a_lower,a_upper] = acc_ppi(C,alpha)
% 
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes
%     alpha - The posterior probability interval will cover 1-alpha of
%         probability mass such that (1-alpha)/2 remains on either end of
%         the distribution.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_ppi.m 16157 2012-05-28 09:24:16Z bkay $
% -------------------------------------------------------------------------
function [a_lower,a_upper] = acc_ppi(C,alpha)
    
    try, alpha; catch; alpha = 0.05; end
    if (alpha==0.95) | (alpha==0.975)
        warning('Note that alpha is the significance level. Don''t use 0.95 to obtain the upper limit.');
    end
    
    A = C(1,1)+C(2,2) + 1;
    B = C(1,2)+C(2,1) + 1;
    
    a_lower = betainv(alpha/2,A,B);
    a_upper = betainv(1-alpha/2,A,B);
    
end
