% Tests the null hypothesis that classifier 1 was better than classifier 2,
% where the two classifiers were tested on independent datasets.
% 
% This function is to be used to compare the accuracies obtained on
% independent datasets. In order to compare two classifiers used on the
% same dataset you have to do a paired comparison using ACC_CMP1.
% 
% Usage:
%     p = acc_cmp2(C1,C2)
%
% Arguments:
%     C1 - 2x2 confusion matrix of classification outcomes (classifier 1)
%     C2 - 2x2 confusion matrix of classification outcomes (classifier 2)
% 
% See also:
%     acc_cmp1

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_cmp2.m 10540 2011-05-06 15:08:51Z bkay $
% -------------------------------------------------------------------------
function p = acc_cmp2(C1,C2)
    
    % The size \alpha Wald test is to reject H_0 when |W|>z_\alpha/2, where
    % W = \frac{\delta_hat - 0}{se_hat}
    % and
    % \delta_hat = p1 - p2
    
    % Prepare test statistic
    p1 = acc_mode(C1);
    p2 = acc_mode(C2);
    m = sum(sum(C1));
    n = sum(sum(C2));
    W = (p1-p2) / sqrt(p1*(1-p1)/m + p2*(1-p2)/n);
    
    % Return p value of Wald test
    % N.B. This is a one-tailed test!
    p = 1-normcdf(W,0,1);
    
end
