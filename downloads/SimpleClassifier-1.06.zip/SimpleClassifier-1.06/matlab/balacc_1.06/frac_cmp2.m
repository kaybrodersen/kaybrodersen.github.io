% Tests the null hypothesis that the true probability underlying fraction 1
% is higher than that of fraction 2. The two fractions are based on
% independent datasets.
%
% This is a frequentist two-sample one-tailed Wald test.
% 
% Usage:
%     p = frac_cmp2(k1,n1,k2,n2,tail)
%
% Arguments:
%     k1: number of interesting observations in sample 1
%     n1: sample size 1
%     k2: number of interesting observations in sample 2
%     n2: sample size 2
%     tail:
%         'both' (default) - tests whether the two probabilities differ
%         'right' - tests whether probability 1 > probability 2
%         'left' - tests whether probability 1 < probability 2
% 
% Example:
%     To test whether 8 out of 10 is *different* from 14 out of 30, type:
%     frac_cmp2(8,10,14,30)
%     
%     To test whether 8 out of 10 is *higher* than 14 out of 30, type:
%     frac_cmp2(8,10,14,30,'right')

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: frac_cmp2.m 11545 2011-07-15 13:39:03Z bkay $
% -------------------------------------------------------------------------
function p = frac_cmp2(k1,n1,k2,n2,tail)
    
    % The size \alpha Wald test is to reject H_0 when |W|>z_\alpha/2, where
    % W = \frac{\delta_hat - 0}{se_hat}
    % and
    % \delta_hat = p1 - p2
    
    % Prepare test statistic
    p1 = k1/n1;
    p2 = k2/n2;
    W = (p1-p2) / sqrt(p1*(1-p1)/n1 + p2*(1-p2)/n2);
    
    % Return p value of Wald test
    try, tail; catch; tail = 'both'; end
    if strcmpi(tail,'right')
        p = (1-normcdf(W,0,1));
    elseif strcmpi(tail, 'left')
        p = (1-normcdf(-W,0,1));
    elseif strcmpi(tail, 'both')
        p = (1-normcdf(abs(W),0,1))*2;
    else
        error('invalid tail parameter');
    end
    
end
