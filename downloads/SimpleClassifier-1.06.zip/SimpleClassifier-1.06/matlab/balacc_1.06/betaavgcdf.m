% CDF of the average of two independent random variables which are
% distributed according to Beta distributions.
%
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: betaavgcdf.m 8245 2010-10-22 12:57:51Z bkay $
% -------------------------------------------------------------------------
function y = betaavgcdf(x, alpha1, beta1, alpha2, beta2)
    
    y = betasumcdf(2*x, alpha1, beta1, alpha2, beta2);
    
end
