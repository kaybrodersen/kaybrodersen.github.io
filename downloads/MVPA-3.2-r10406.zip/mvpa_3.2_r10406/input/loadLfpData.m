% Loads data from an M/EEG dataset in SPM8 format (.dat/.mat pair of
% files). In this variant, 'cy' is ignored and should always be 1.
%
% See 'loadData_wrapper' interface.
%
% Possible additional fields for loadData_args:
%     mode ('all', 'timebin', or 'location') - determines whether all
%         data from a certain range of timebins and channels will be
%         loaded, or just a single timebin, or just a single electrode.
%     timebinRange ('all' mode only) - which timebins to include; by
%         default, all timebins will be included.
%     channelRange ('all' mode only) - which channels to include; by
%         default, all channels will be included.

% Kay Henning Brodersen, ETHZ/UZH
% $Id: loadLfpData.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [subj, loadData_scratch] = loadLfpData(...
    subj, patname, filedata, nExpectedTrials, cy, ...
    loadData_args, loadData_scratch)
    
    % Set defaults
    defaults.mode = 'all';
    defaults.timebinRange = [];
    defaults.channelRange = [];
    args = propval(loadData_args, defaults);
    
    % Load data
    filedata = makeAbsolutePath(filedata);
    D = spm_eeg_load(filedata);
    out(['Loaded D: ', num2str(D.nchannels), ' channels x ', ...
        num2str(D.nsamples), ' timepoints x ', ...
        num2str(D.ntrials), ' trials']);
   
    % Which mode?
    if strcmp(args.mode, 'all')
        % Which timebins to include?
        if isempty(args.timebinRange)
            args.timebinRange = 1:D.nsamples;
        end
        args.timebinRange = sort(args.timebinRange);
        assert(containsOnly(args.timebinRange, [1:D.nsamples]));
        assert(~isempty(args.timebinRange));
        
        % Which channels to include?
        if isempty(args.channelRange)
            args.channelRange = 1:D.nchannels;
        end
        args.channelRange = sort(args.channelRange);
        assert(containsOnly(args.channelRange, [1:D.nchannels]));
        assert(~isempty(args.channelRange));
        
        % Make FEATURES x EXAMPLES matrix
        if cy~=1
            error('cycle should always be 1 when mode is ''all''');
        end
        X = nan(length(args.channelRange)*length(args.timebinRange),D.ntrials);
        for t = 1:D.ntrials
            thisData = squeeze(D(args.channelRange,args.timebinRange,t));
            X(:,t) = thisData(:);
        end
    
    elseif strcmp(args.mode, 'timebin')
        % Make FEATURES x EXAMPLES matrix
        if cy > D.nsamples
            error(['cycle must be in the range [1..', num2str(size(D,2)), ']']);
        end
        X = squeeze(D(:,cy,:));

    elseif strcmp(args.mode, 'location')
        % Make FEATURES x EXAMPLES matrix
        if cy > D.nchannels
            error(['cycle must be in the range [1..', num2str(size(D,1)), ']']);
        end
        X = squeeze(D(cy,args.timebinRange,:));
    end        
    
    % Check number of trials
    out(['Selected data matrix is: ', mat2str(size(X))]);
    if size(X,2) ~= nExpectedTrials
        error('unexpected number of trials in data');
    end
    
    % Create new pattern
    subj = init_object(subj, 'pattern', patname);
    subj = set_mat(subj, 'pattern', patname, X);
    subj = set_objfield(subj, 'pattern', patname, 'masked_by', '');
    hist_str = sprintf('Pattern ''%s'' created by load_analyze_pattern', patname);
    subj = add_history(subj, 'pattern', patname, hist_str, true);
    created.function = 'loadOpticalData';
    created.args = loadData_args;
    subj = add_created(subj, 'pattern', patname, created);
    
end
