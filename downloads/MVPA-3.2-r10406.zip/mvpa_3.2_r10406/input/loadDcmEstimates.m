% Loads parameter estimates from a DCM that was fitted individually to each
% trial. The parameter 'filename' should contain the placeholder '[TRIAL]'
% 
% Note that, since there is no within-trial temporal dimension to the data,
% 'tb' is meaningless and should always be 1.
%
% See 'loadData_wrapper' interface.

% Kay Henning Brodersen, ETHZ/UZH
% $Id: loadDcmEstimates.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [subj, loadData_scratch] = loadDcmEstimates(...
    subj, patname, filedata, nExpectedTrials, tb, ...
    loadData_args, loadData_scratch)

    % Check input
    if tb~=1
        error('tb should always be 1 in this function');
    end
    if isempty(strfind(filedata, '[TRIAL]'))
        error('filedata should contain the placeholder [TRIAL]');
    end
    
    % Load data into X
    out(['Loading ', filedata, ' ...']);
    xInitialized = false;
    nNotFound = 0;
    for t = 1:nExpectedTrials
        progress(t,nExpectedTrials);
        
        % Find file
        thisFile = strrep(makeAbsolutePath(filedata), '[TRIAL]', sprintf('%04d',t));
        % - legacy
        alterFile = strrep(makeAbsolutePath(filedata), '[TRIAL]', num2str(t));
        if ~exist(thisFile, 'file') && exist(alterFile, 'file')
            tryUnix(['mv ', alterFile, ' ', thisFile]);
        end
        
        % If file not found, continue with next trial. (Hence, the data
        % matrix will be all NaN for this trial. Further below, we will set
        % it to 0s. Note that we are not allowed to set it to NaN.)
        if ~exist(thisFile, 'file')
            nNotFound = nNotFound + 1;
            continue;
        end
        
        % Load DCM
        try
            DCM = load(thisFile);
            DCM = DCM.DCM;
        catch
            nNotFound = nNotFound + 1;
            continue;
        end
        
        % Which trial-by-trial-varying parameters the DCM contains depends
        % on its type (LFP or SEP) as well as on the number of areas.
        thisFeatures = extractDcmEstimates(DCM, loadData_args);
        
        % Initialize X matrix if not done yet (FEATURES x EXAMPLES)
        if ~xInitialized
            X = NaN(length(thisFeatures),nExpectedTrials);
            xInitialized = true;
        end
        
        % Add values to matrix
        X(:,t) = thisFeatures(:);
        
    end
    
    % Check number of loaded DCMs
    pNotFound = nNotFound/nExpectedTrials*100;
    if nNotFound>0
        out(' ');
        out(['WARNING: ', num2str(nNotFound), ' trials (', num2str(round(pNotFound)), ...
            ' %) were ignored because their DCM files were not found or were corrupt']);
        out(' ');
    end
    if nNotFound==nExpectedTrials
        error('Not a single DCM file was found');
    end
    if pNotFound>=30 && nNotFound<200
        error(['Only ', num2str(round(pNotFound)), ' % of all trials had a ', ...
            'corresponding DCM file. Are you sure you want to include this ', ...
            'subject in the analysis?']);
    end
    
    % Check data matrix
    out(['Constructed data matrix is: ', mat2str(size(X))]);
    assert(size(X,2) == nExpectedTrials);
    
    % Create new pattern
    subj = init_object(subj, 'pattern', patname);
    subj = set_mat(subj, 'pattern', patname, X);
    subj = set_objfield(subj, 'pattern', patname, 'masked_by', '');
    hist_str = sprintf('Pattern ''%s'' created by load_analyze_pattern', patname);
    subj = add_history(subj, 'pattern', patname, hist_str, true);
    created.function = 'loadOpticalData';
    created.args = loadData_args;
    subj = add_created(subj, 'pattern', patname, created);
    
end

% -------------------------------------------------------------------------
% Extracts relevant features from a DCM
function values = extractDcmEstimates(DCM, loadData_args)
    
    % Check input
    defaults.includeVariances = true;
    defaults.featureFilter = [];
    args = propval(loadData_args, defaults);
    
    % What kind of model?
    model = DCM.options.model;
    nRegions = length(DCM.A{1});
    
    % -------------------------------------
    % ERP MODEL
    % -------------------------------------
    if strcmpi(model, 'ERP')
        
        % 1 region
        if nRegions==1
            
            % - expectations
            valuesE = [DCM.Ep.T; DCM.Ep.H; DCM.Ep.S(:); DCM.Ep.C; DCM.Ep.R(:)];
            % - variances
            valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); ...
                DCM.Cp(8,8); DCM.Cp(10,10); DCM.Cp(11,11)];
            assert(length(valuesE)==length(valuesC) && length(valuesE)==7);
            
        % 2 regions
        elseif nRegions==2
            
            % ERP-A model
            if all(DCM.A{1}(:)==[0;1;0;0]) && all(DCM.A{2}(:)==[0;0;1;0]) && all(DCM.A{3}(:)==[0;0;0;0])
            
                % - expectations
                valuesE = [DCM.Ep.T(:); ...                  % 2 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.S(:); ...                         % 2 values
                    DCM.Ep.A{1}(2,1); DCM.Ep.A{2}(1,2); ...  % 2 values
                    DCM.Ep.C(1); ...                         % 1 value
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.R(:)];                            % 2 values
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(8,8); DCM.Cp(13,13); DCM.Cp(19,19); DCM.Cp(22,22); ...
                    DCM.Cp(23,23); DCM.Cp(25,25); DCM.Cp(26,26)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==13);
            
            % ERP-B model
            elseif all(DCM.A{1}(:)==[0;0;1;0]) && all(DCM.A{2}(:)==[0;1;0;0]) && all(DCM.A{3}(:)==[0;0;0;0])
                
                % - expectations
                valuesE = [DCM.Ep.T(:); ...                  % 2 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.S(:); ...                         % 2 values
                    DCM.Ep.A{1}(1,2); DCM.Ep.A{2}(2,1); ...  % 2 values
                    DCM.Ep.C(2); ...                         % 1 value
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.R(:)];                            % 2 values
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(9,9); DCM.Cp(12,12); DCM.Cp(20,20); DCM.Cp(22,22); ...
                    DCM.Cp(23,23); DCM.Cp(25,25); DCM.Cp(26,26)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==13);
            
            % ERP-C model
            elseif all(DCM.A{1}(:)==[0;0;0;0]) && all(DCM.A{2}(:)==[0;0;0;0]) && all(DCM.A{3}(:)==[0;1;1;0])
                
                % - expectations
                valuesE = [DCM.Ep.T(:); ...                  % 2 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.S(:); ...                         % 2 values
                    DCM.Ep.A{3}(2,1); DCM.Ep.A{3}(1,2); ...  % 2 values
                    DCM.Ep.C(:); ...                         % 2 values
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.R(:)];                            % 2 values
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(16,16); DCM.Cp(17,17); DCM.Cp(19,19); DCM.Cp(20,20); ...
                    DCM.Cp(22,22); DCM.Cp(23,23); DCM.Cp(25,25); DCM.Cp(26,26)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==14);
                
            end % model architecture
        end % nRegions
        
    % -------------------------------------
    % LFP MODEL
    % -------------------------------------
    elseif strcmpi(model, 'LFP')
        
        % 1 region
        if nRegions==1
            
            % - expectations
            valuesE = [DCM.Ep.R(:); DCM.Ep.T(:); DCM.Ep.H; DCM.Ep.G(:); ...
                DCM.Ep.C; DCM.Ep.I];
            % - variances
            valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); ...
                DCM.Cp(5,5); DCM.Cp(6,6); DCM.Cp(7,7); DCM.Cp(8,8); DCM.Cp(9,9); ...
                DCM.Cp(10,10); DCM.Cp(14,14); DCM.Cp(16,16)];
            assert(length(valuesE)==length(valuesC) && length(valuesE)==12);
            
        % 2 regions
        elseif nRegions==2
            
            % LFP-A model
            if all(DCM.A{1}(:)==[0;1;0;0]) && all(DCM.A{2}(:)==[0;0;1;0]) && all(DCM.A{3}(:)==[0;0;0;0])
                
                % - expectations
                valuesE = [DCM.Ep.R(:); ...                  % 2 values
                    DCM.Ep.T(:); ...                         % 4 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.G(:); ...                         % 10 values
                    DCM.Ep.A{1}(2,1); DCM.Ep.A{2}(1,2); ...  % 2 values
                    DCM.Ep.C(1); ...                         % 1 value
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.I];                               % 1 value
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(7,7); DCM.Cp(8,8); DCM.Cp(9,9); DCM.Cp(10,10); DCM.Cp(11,11); ...
                    DCM.Cp(12,12); DCM.Cp(13,13); DCM.Cp(14,14); DCM.Cp(15,15); DCM.Cp(16,16); ...
                    DCM.Cp(17,17); DCM.Cp(18,18); DCM.Cp(20,20); DCM.Cp(25,25); DCM.Cp(31,31); ...
                    DCM.Cp(34,34); DCM.Cp(35,35); DCM.Cp(37,37)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==24);
                
            % LFP-B model
            elseif all(DCM.A{1}(:)==[0;0;1;0]) && all(DCM.A{2}(:)==[0;1;0;0]) && all(DCM.A{3}(:)==[0;0;0;0])
                
                % - expectations
                valuesE = [DCM.Ep.R(:); ...                  % 2 values
                    DCM.Ep.T(:); ...                         % 4 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.G(:); ...                         % 10 values
                    DCM.Ep.A{1}(1,2); DCM.Ep.A{2}(2,1); ...  % 2 values
                    DCM.Ep.C(2); ...                         % 1 value
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.I];                               % 1 value
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(7,7); DCM.Cp(8,8); DCM.Cp(9,9); DCM.Cp(10,10); DCM.Cp(11,11); ...
                    DCM.Cp(12,12); DCM.Cp(13,13); DCM.Cp(14,14); DCM.Cp(15,15); DCM.Cp(16,16); ...
                    DCM.Cp(17,17); DCM.Cp(18,18); DCM.Cp(21,21); DCM.Cp(24,24); DCM.Cp(32,32); ...
                    DCM.Cp(34,34); DCM.Cp(35,35); DCM.Cp(37,37)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==24);
            
            % LFP-C model
            elseif all(DCM.A{1}(:)==[0;0;0;0]) && all(DCM.A{2}(:)==[0;0;0;0]) && all(DCM.A{3}(:)==[0;1;1;0])
                
                % - expectations
                valuesE = [DCM.Ep.R(:); ...                  % 2 values
                    DCM.Ep.T(:); ...                         % 4 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.G(:); ...                         % 10 values
                    DCM.Ep.A{3}(2,1); DCM.Ep.A{3}(1,2); ...  % 2 values
                    DCM.Ep.C(:); ...                         % 2 values
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.I];                               % 1 value
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); ...
                    DCM.Cp(5,5); DCM.Cp(6,6); DCM.Cp(7,7); DCM.Cp(8,8); DCM.Cp(9,9); ...
                    DCM.Cp(10,10); DCM.Cp(11,11); DCM.Cp(12,12); DCM.Cp(13,13); ...
                    DCM.Cp(14,14); DCM.Cp(15,15); DCM.Cp(16,16); DCM.Cp(17,17); ...
                    DCM.Cp(18,18); DCM.Cp(28,28); DCM.Cp(29,29); DCM.Cp(31,31); ...
                    DCM.Cp(32,32); DCM.Cp(34,34); DCM.Cp(35,35); DCM.Cp(37,37)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==25);
                
            end % model architecture
        end % nRegions
        
    % -------------------------------------
    % SEP model
    % -------------------------------------
    elseif strcmpi(model, 'SEP')
        
        % 1 region
        if nRegions==1
            
            % - expectations
            valuesE = [DCM.Ep.T
                DCM.Ep.H; ...
                DCM.Ep.S(1); ...
                DCM.Ep.S(2); ...
                DCM.Ep.C; ...
                DCM.Ep.R(1); ...
                DCM.Ep.R(2)];
            % - variances
            valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); ...
                DCM.Cp(8,8); DCM.Cp(10,10); DCM.Cp(11,11)];
            assert(length(valuesE)==length(valuesC) && length(valuesE)==7);
            
        % 2 Regions
        elseif nRegions==2
            
            % SEP-A model
            if all(DCM.A{1}(:)==[0;1;0;0]) && all(DCM.A{2}(:)==[0;0;1;0]) && all(DCM.A{3}(:)==[0;0;0;0])
                
                % - expectations
                valuesE = [DCM.Ep.T(:); ...                  % 2 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.S(:); ...                         % 2 values
                    DCM.Ep.A{1}(2,1); DCM.Ep.A{2}(1,2); ...  % 2 values
                    DCM.Ep.C(1); ...                         % 1 value
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.R(:)];                            % 2 values
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(8,8); DCM.Cp(13,13); DCM.Cp(19,19); DCM.Cp(22,22); ...
                    DCM.Cp(23,23); DCM.Cp(25,25); DCM.Cp(26,26)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==13);
                
            % SEP-B model
            elseif all(DCM.A{1}(:)==[0;0;1;0]) && all(DCM.A{2}(:)==[0;1;0;0]) && all(DCM.A{3}(:)==[0;0;0;0])
                
                % - expectations
                valuesE = [DCM.Ep.T(:); ...                  % 2 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.S(:); ...                         % 2 values
                    DCM.Ep.A{1}(1,2); DCM.Ep.A{2}(2,1); ...  % 2 values
                    DCM.Ep.C(2); ...                         % 1 value
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.R(:)];                            % 2 values
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(9,9); DCM.Cp(12,12); DCM.Cp(20,20); DCM.Cp(22,22); ...
                    DCM.Cp(23,23); DCM.Cp(25,25); DCM.Cp(26,26)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==13);
                
            % SEP-C model
            elseif all(DCM.A{1}(:)==[0;0;0;0]) && all(DCM.A{2}(:)==[0;0;0;0]) && all(DCM.A{3}(:)==[0;1;1;0])
                
                % - expectations
                valuesE = [DCM.Ep.T(:); ...                  % 2 values
                    DCM.Ep.H(:); ...                         % 2 values
                    DCM.Ep.S(:); ...                         % 2 values
                    DCM.Ep.A{3}(2,1); DCM.Ep.A{3}(1,2); ...  % 2 values
                    DCM.Ep.C(:); ...                         % 2 values
                    DCM.Ep.D(2,1); DCM.Ep.D(1,2); ...        % 2 values
                    DCM.Ep.R(:)];                            % 2 values
                % - variances
                valuesC = [DCM.Cp(1,1); DCM.Cp(2,2); DCM.Cp(3,3); DCM.Cp(4,4); DCM.Cp(5,5); ...
                    DCM.Cp(6,6); DCM.Cp(16,16); DCM.Cp(17,17); DCM.Cp(19,19); DCM.Cp(20,20); ...
                    DCM.Cp(22,22); DCM.Cp(23,23); DCM.Cp(25,25); DCM.Cp(26,26)];
                assert(length(valuesE)==length(valuesC) && length(valuesE)==14);
                
            end % model architecture
        end % nRegions
    end % model
    
    % Check values
    assert(~isempty(valuesE));
    assert(~isempty(valuesC));
    assert(length(valuesE)==length(valuesC));
    
    % Expectations only, or include variances as well?
    if ~args.includeVariances
        values = valuesE;
    else
        values = [valuesE; valuesC];
    end
    clear valuesE;
    clear valuesC;
    
    % Additional custom feature filter?
    if ~isempty(args.featureFilter)
        if length(args.featureFilter)~=length(values)
            error('featureFilter has unexpected length');
        end
        assert(containsOnly(args.featureFilter, [0 1]));
        args.featureFilter = logical(args.featureFilter);
        values = values(args.featureFilter);
        assert(length(values)==sum(args.featureFilter));
    end
    
    % Return column vector
    values = values(:);
end
