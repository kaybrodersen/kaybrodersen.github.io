% Loads an fMRI dataset.
%
% See 'loadData_wrapper' interface.
%
% Custom arguments:
%     'file' - filename of the volume to be loaded
%     'phases' - phase filter

% Kay Henning Brodersen, ETHZ/UZH
% $Id: loadFmriData.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [data, loadData_scratch] = loadFmriData(subj, loadData_args, loadData_scratch)
    
    % Process input
    defaults.file = '';
    defaults.phases = [];
    args = propval(loadData_args, defaults);
    args.file = insertScan(args.file, subj.scan);
    
    % Check whether file present
    if ~exist(args.file, 'file') && ~exist([args.file, '.nii'], 'file') && ~exist([args.file, '.nii.gz'], 'file')
        error([args.file, ' does not seem to be an existing NIFTI file']);
    end
    
    % Load data
    data = read_avw(args.file);
    
    % Apply phase filter
    if ~isempty(args.phases)
        if size(args.phases,1)==1
            phaseFilter = args.phases;
            out(['Applying cycle-independent phase filter ', mat2str(phaseFilter), '...']);
        else
            phaseFilter = args.phases(subj.cy,:);
            out(['Applying CYCLE-SPECIFIC phase filter ', mat2str(phaseFilter), '...']);
        end
        data = applyPhaseFilter(data, phaseFilter);
    end
		
end
