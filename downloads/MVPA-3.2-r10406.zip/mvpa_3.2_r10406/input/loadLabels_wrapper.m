% Wrapper function for loading labels.
% 
% When subj.nClasses>0, labels will be assumed to be positive integers (an
% important assumption throughout the MVPA code in the case of
% classification). Loaded labels that are 0 or NaN will be set to NaN (the
% convention for trials that are to be ignored).
% 
% When subj.nClasses==0, labels are allowed to take any continuous value.
% Loaded labels that are NaN will be ignored later.
% 
% Callee interface:
%     labels = loadLabels_func(subj, loadLabels_args)

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: loadLabels_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function labels = loadLabels_wrapper(subj, loadLabels_func, loadLabels_args)
    
    % Load labels
    out(' ');
    out(['Loading labels using ''', func2str(loadLabels_func), '''']);
    loadLabels_func_actual = str2func(func2str(loadLabels_func));
    labels = loadLabels_func_actual(subj, loadLabels_args);
    
    % Check return value
    if (size(labels,1)~=1) && (size(labels,2)~=1)
        error('labels must be a vector');
    end
    
    % Force row vector
    labels = labels(:)';
    
    % In classification mode?
    if subj.nClasses>0
        % If a label is 0 or NaN, it will be set to NaN, the convention for
        % trials to be ignored.
        if any(labels==0)
            out(['NOTE: ', num2str(sum(labels==0)), ' labels are 0. These trials will be ignored.']);
        end
        if any(isnan(labels))
            out(['NOTE: ', num2str(sum(isnan(labels))), ' labels are NaN. These trials will be ignored.']);
        end
        labels(labels==0 | isnan(labels)) = NaN;
        
        % If any remaining label is not NaN or a positive integer, error
        if ~containsOnly(labels, [NaN, 1:99]);
            error('illegal labels were found');
        end
        
    % In regression mode?
    else
        if any(isnan(labels))
            out(['NOTE: ', num2str(sum(isnan(labels))), ' labels are NaN. These trials will be ignored.']);
        end
    end
    
    % Show how many labels we have loaded
    out(['Loaded ', num2str(length(labels)), ' labels']);
    
end
