% Wrapper function for loading balancing criteria.
% 
% Callee interface:
%     balancingCriteria = loadBalancingCriteria(subj, ...
%         loadBalancingCriteria_func, loadBalancingCriteria_args)
%
% Arguments:
%     loadBalancingCriteria_func: one or several functions for loading
%         criteria; several functions must be passed as a cell array
%     loadBalancingCriteria_args: corresponding arguments; when several
%         functions are provided, a cell array of the same dimensionality
%         with args structs must be given

% Kay H. Brodersen, ETHZ/UZH
% $Id: loadBalancingCriteria_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
    loadBalancingCriteria_func, loadBalancingCriteria_args)
    
    % Load balancing criteria
    if ~isempty(loadBalancingCriteria_func)
        
        % Ensure cell array
        if ~iscell(loadBalancingCriteria_func)
            loadBalancingCriteria_func = {loadBalancingCriteria_func};
        end
        if ~iscell(loadBalancingCriteria_args)
            loadBalancingCriteria_args = {loadBalancingCriteria_args};
        end
        assert(length(loadBalancingCriteria_func)==length(loadBalancingCriteria_args));
        
        % Go through all criteria
        balancingCriteria = [];
        for c = 1:length(loadBalancingCriteria_func)
            out(' ');
            out(['Loading balancing criterion ', num2str(c), '/', num2str(length(loadBalancingCriteria_func)), ...
                ' using ''', func2str(loadBalancingCriteria_func{c}), '''']);
            loadBalancingCriteria_func_actual = str2func(func2str(loadBalancingCriteria_func{c}));
            thisCriterion = loadBalancingCriteria_func_actual(subj, loadBalancingCriteria_args{c});
            thisCriterion = thisCriterion(:)';
            
            % Check return value
            if (size(thisCriterion,1)~=1) && (size(thisCriterion,2)~=1)
                error('balancingCriterion must be a vector');
            end
            
            % Append to criteria
            balancingCriteria = [balancingCriteria; thisCriterion];
        end
        
    else
        balancingCriteria = [];
    end
    
end
