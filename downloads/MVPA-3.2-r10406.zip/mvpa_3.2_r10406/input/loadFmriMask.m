% Loads an fMRI mask.
%
% Implements the 'loadMask_wrapper' interface.
% 
% Custom arguments:
%     file: full filename of the mask; may contain [SCAN] wildcard

% Kay Henning Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function mask = loadFmriMask(subj, args)
    
    % Check input
    defaults.file = '';
    args = propval(args, defaults);
    assert(~isempty(args.file), 'No mask file specified');
    
    % Get full filename
    file = insertScan(args.file, subj.scan);
    
    % Check whether file present
    if ~exist(file, 'file') && ~exist([file, '.nii'], 'file') && ~exist([file, '.nii.gz'], 'file')
        error([file, ' does not seem to be an existing NIFTI file']);
    end
    
    % Load mask (new)
    mask = read_avw(file);

end
