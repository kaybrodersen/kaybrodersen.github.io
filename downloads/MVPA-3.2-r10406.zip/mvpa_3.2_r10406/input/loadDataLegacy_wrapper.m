% Wrapper function for loading data into a Princeton struct. Also provides
% memory/recall functionality.
%
% Callee interface:
%     [subj, loadData_scratch] = loadDataLegacy_func(subj, loadData_args, loadData_scratch)
% 
% Optional named arguments processed by loadDataLegacy_wrapper:
%     'name' - will be used for Princeton and for memory functionality
%     'useMemory' - whether to store/recall data rather than loading it afresh

% Kay H. Brodersen, ETHZ/UZH
% $Id: loadDataLegacy_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
    loadData_func, loadData_args, loadData_scratch, varargin)
	
    % Check input
    defaults.name = '';
    defaults.useMemory = false;
    args = propval(varargin, defaults, 'strict', false);
    out(' ');
    
	% Recall from memory?
    memory = [];
	memFile = [args.name, '_', num2str(subj.cy)];
    if args.useMemory && isempty(args.name)
        out(['WARNING: in order to use memory functionality, need to specify a name']);
    end
    if ~isempty(args.name)
        if args.useMemory
            memory = recallData(subj.dirMem, memFile);
        else
    		clearData(subj.dirMem, memFile);
        end
    end
	
    % If loaded from memory, try to use the loaded data
    if ~isempty(memory)
        try; subj.patterns(end+1) = memory; catch; memory = []; end
    end
    
	% Otherwise do a full load from disk
	if isempty(memory)
		% Load data
        out(['Loading data using ''', func2str(loadData_func), '''...']);
        loadData_args.patname = args.name;
        loadData_func_actual = str2func(func2str(loadData_func));
		[subj, loadData_scratch] = loadData_func_actual(subj, loadData_args, loadData_scratch);
        
		% Memorize for future calls
		if args.useMemory
			out(' ');
			memorizeData(subj.dirMem, memFile, subj.patterns(end));
		end
    end
    
end
