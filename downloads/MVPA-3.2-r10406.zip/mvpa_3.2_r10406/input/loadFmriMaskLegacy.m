% Loads an fMRI mask into a Princeton struct.
%
% Implements the 'loadMaskLegacy_wrapper' interface.
% 
% Custom arguments:
%     file: full filename of the mask; may contain [SCAN] wildcard

% Kay Henning Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function subj = loadFmriMaskLegacy(subj, args)
    
    % Check input
    defaults.file = '';
    defaults.maskname = 'the_mask';
    args = propval(args, defaults);
    assert(~isempty(args.file), 'No mask file specified');
    
    % Get full mask filename
    file = insertScan(args.file, subj.scan);
    
    % Check whether file present
    if ~exist(file, 'file') && ~exist([file, '.nii'], 'file') && ~exist([file, '.nii.gz'], 'file')
        error([file, ' does not seem to be an existing NIFTI file']);
    end
    
    % Load mask (Princeton)
    subj = load_nifti_mask(subj, args.maskname, file);

end
