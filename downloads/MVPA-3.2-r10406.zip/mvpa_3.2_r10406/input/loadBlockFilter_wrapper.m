% Wrapper function for loading a block filter. If no block filter function
% is specified, returns an empty vector (unlike in the loadFilter_wrapper
% specification).
%
% Callee interface:
%     blockFilter = loadBlockFilter_func(dirScan, cv_args)

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% -------------------------------------------------------------------------
function blockFilter = loadBlockFilter_wrapper(dirScan, cv_args)
    
    % Check input
    defaults.loadBlockFilter_func = [];
    defaults.loadBlockFilter_args = [];
    defaults.nExpectedBlocks = [];
    cv_args = propval(cv_args, defaults, 'strict', false);
    
    % Load block filter?
    out(' ');
    if ~isempty(cv_args.loadBlockFilter_func)
        out(['Loading block filter using ''', func2str(cv_args.loadBlockFilter_func), '''']);
        loadBlockFilter_func_actual = str2func(func2str(cv_args.loadBlockFilter_func));
        blockFilter = loadBlockFilter_func_actual(dirScan, cv_args.loadBlockFilter_args);
		
    % Or default filter?
    else
        out('(No block filtering)');
        blockFilter = [];
    end
    
    % Check return value
    blockFilter = checkFilter(blockFilter, cv_args.nExpectedBlocks);
    
    % Display info about filter
    if isempty(blockFilter)
        out('Block filter is going to keep ALL blocks');
    else
        if ~isempty(cv_args.nExpectedBlocks)
            out(['Block filter is going to keep ', ...
                num2str(sum(blockFilter)), ' out of ', ...
                num2str(cv_args.nExpectedBlocks), ' blocks:']);
        else
            out(['Block filter is going to keep ', ...
                num2str(sum(blockFilter)), ' blocks:']);
        end
        out([num2str(find(blockFilter==1))]);
    end
    
end
