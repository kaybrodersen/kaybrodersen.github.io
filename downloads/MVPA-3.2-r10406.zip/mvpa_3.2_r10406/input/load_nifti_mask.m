% LOAD_NIFTI_MASK - Loads a mask from a NIFTI file into a SUBJ struct
%
% Usage: analogous to 'load_analyze_mask' (MVPA)
%     subj = load_nifti_mask(subj, newMaskName, fileName)

% Kay Henning Brodersen, University of Oxford
% $Id: load_nifti_mask.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = load_nifti_mask(subj, newMaskName, fileName)

    % Check input
    % 'filename' must not contain extension
    [path,file,ext] = fileparts(fileName); % ext will only contain '.gz'
    [file,file] = fileparts(file); % to also strip off the '.nii'
    
    % Get a temporary filestem
    tmpFilestem = ['tmp_', getUniqueId, '_'];
    
    % Convert existing NIFTI mask into ANALYZE mask (and store in tmp
    % directory)
    s = tryFsl(['fslchfiletype ANALYZE ', ...
        fullfile(path,file), '.nii.gz ', ...
        fullfile(tempdir,[tmpFilestem,file])]);
    
    % Check whether file was written properly
    if ~exist([fullfile(tempdir,[tmpFilestem,file]), '.img'], 'file')
        out(s);
        error(['file not written properly: ', fullfile(tempdir,[tmpFilestem,file]), '.img']);
    end
    
    % Load ANALYZE mask (from tmp directory)
    spm_defaults;
    subj = load_analyze_mask(subj, newMaskName, ...
        fullfile(tempdir,[tmpFilestem,file,'.img']));

    % Delete ANALYZE files
    unix(['rm ', fullfile(tempdir,[tmpFilestem,file,'.img'])]);
    unix(['rm ', fullfile(tempdir,[tmpFilestem,file,'.hdr'])]);
    
end