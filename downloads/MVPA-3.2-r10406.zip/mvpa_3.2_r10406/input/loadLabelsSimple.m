% Loads labels from disk.

% Kay Henning Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function labels = loadLabelsSimple(subj, args)
    
    % If called without arguments, return number of classes
    if nargin==0
        labels = 2;
        return;
    end
    
    % Load labels
    labels = diveIntoStruct(load(insertScan(args.file,subj.scan)));
    labels = labels(:)';
    
    % Transform?
    if containsOnly(labels, [0 1])
        labels(labels==0) = 2;
    end
    if containsOnly(labels, [-1 1])
        labels(labels==-1) = 2;
    end
    
    % Check result
    assert(containsOnly(labels, [1 2]));
    
end
