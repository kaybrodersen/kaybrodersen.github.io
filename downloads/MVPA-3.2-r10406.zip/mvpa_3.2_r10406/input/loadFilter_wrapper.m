% Wrapper function for loading a trial filter. If no filter function is
% specified, returns all ones (unlike in the loadBlockFilter_wrapper
% specification). The returned filter contains 1s for good trials and 0s
% for trials that are to be ignored.
%
% Callee interface:
%     filter = loadFilter_func(subj, loadFilter_args);

% Kay H. Brodersen, ETHZ/UZH
% $Id: loadFilter_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function filter = loadFilter_wrapper(subj, invertFilter, nExpectedTrials, ...
	loadFilter_func, loadFilter_args)
	
    % Load filter?
    if isa(loadFilter_func, 'function_handle')
        out(['Loading trial filter using ''', func2str(loadFilter_func), '''']);
        loadFilter_func_actual = str2func(func2str(loadFilter_func));
        filter = loadFilter_func_actual(subj, loadFilter_args);
        
    % Default filter?
    else
        out('(No trial filtering)');
        filter = ones(1,nExpectedTrials);
    end
    assert(~isempty(filter));
    
    % Quite often, a function is used as a filter that is normally used to
    % get class labels. These functions return classes [1, 2, ...] (usually
    % 1 and 2 only). Thus: transform to [1 0] interval, so that all the 1's
    % are kept and the 2's are ignored.
    if containsOnly(filter, [NaN 1 2]) && any(filter==2)
        out(['WARNING: turning [1 2] filter into [1 0]']);
        filter(filter == 2) = 0;
    end
    
    % Invert filter?
    if invertFilter
        filter = 1-filter;
        out('Filter inverted');
    end
    
    % Turn NaNs into 0s
    if sum(isnan(filter))>0
        out(['NOTE: turning NaN trials into 0 trials']);
        filter(isnan(filter)) = 0;
    end
    
    % Check return value
    filter = checkFilter(filter, nExpectedTrials);
    
    % Display info about filter
    if ~all(filter==1)
        tmpExample = find(filter==1);
        tmpExample = tmpExample(1:min([5,length(tmpExample)]));
        out(['Filter is going to keep ', num2str(sum(filter)), ' out of ', ...
            num2str(length(filter)), ' examples, such as: ', num2str(tmpExample), ' ...']);
    end
end
