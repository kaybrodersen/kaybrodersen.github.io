% Loads a data matrix from disk.

% Kay Henning Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [mat, loadData_scratch] = loadDataSimple(subj, loadData_args, loadData_scratch)
    
    % Load data
    mat = diveIntoStruct(load(insertScan(loadData_args.file,subj.scan)));
    
end
