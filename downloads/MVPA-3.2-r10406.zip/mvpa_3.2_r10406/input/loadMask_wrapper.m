% Wrapper function for loading a mask.
%
% Callee interface:
%     mask = loadMask_func(subj, loadMask_args);

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function mask = loadMask_wrapper(subj, loadMask_func, loadMask_args)
	
	% Load mask
    loadMask_func_actual = str2func(func2str(loadMask_func));
	mask = loadMask_func_actual(subj, loadMask_args);
	
    % Print some mask info
    nVoxelsMask = sum(sum(sum(mask~=0)));
    out(['Loaded mask with ', num2str(nVoxelsMask), ' voxels']);
    
end
