% Loads an fMRI dataset into a Princeton subj struct.
%
% See 'loadDataPrinceton_wrapper' interface.
% 
% Custom arguments:
%     'patname' - name for the new pattern to be created
%     'maskname' - name of the mask that is to be applied to the volume
%     'file' - filename of the volume to be loaded
%     'phases' - phase filter

% Kay Henning Brodersen, ETHZ/UZH
% $Id: loadFmriDataLegacy.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [subj, loadData_scratch] = loadFmriDataLegacy(subj, loadData_args, loadData_scratch)
    
    % Process input
    defaults.patname = '';
    defaults.maskname = 'the_mask';
    defaults.file = '';
    defaults.phases = [];
    args = propval(loadData_args, defaults);
    args.file = insertScan(args.file, subj.scan);
    if isempty(args.patname)
        error('patname must not be empty');
    end
    
    % Check whether file present
    if ~exist(args.file, 'file') && ~exist([args.file, '.nii'], 'file') && ~exist([args.file, '.nii.gz'], 'file')
        error([args.file, ' does not seem to be an existing NIFTI file']);
    end
    
    % Load data
    subj = load_nifti_pattern(subj, args.patname, args.maskname, args.file);
    
    % Apply phase filter
    if ~isempty(args.phases)
        if size(args.phases,1)==1
            phaseFilter = args.phases;
            out(['Applying cycle-independent phase filter ', mat2str(phaseFilter), '...']);
        else
            phaseFilter = args.phases(subj.cy,:);
            out(['Applying CYCLE-SPECIFIC phase filter ', mat2str(phaseFilter), '...']);
        end
        mat = get_mat(subj, 'pattern', args.patname);
        mat = applyPhaseFilter(mat, phaseFilter);
        subj = set_mat(subj, 'pattern', args.patname, mat, 'ignore_diff_size', true);
    end
		
end
