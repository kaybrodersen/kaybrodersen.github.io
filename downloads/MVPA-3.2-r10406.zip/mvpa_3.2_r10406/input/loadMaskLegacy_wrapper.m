% Wrapper function for loading a mask into a Princeton struct.
%
% Callee interface:
%     subj = loadMaskLegacy_func(subj, loadMask_args);

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function subj = loadMaskLegacy_wrapper(subj, loadMask_func, loadMask_args)
	
	% Load mask
    if ~isempty(loadMask_func)
        loadMask_func_actual = str2func(func2str(loadMask_func));
        subj = loadMask_func_actual(subj, loadMask_args);
    end
    
end
