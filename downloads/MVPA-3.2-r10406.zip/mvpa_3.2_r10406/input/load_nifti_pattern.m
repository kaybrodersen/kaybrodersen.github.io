% LOAD_NIFTI_PATTERN - Loads a pattern from a NIFTI file into a SUBJ struct
%
% Usage: analogous to 'load_analyze_pattern' (MVPA)
%     subj = load_nifti_pattern(subj, newPatternName, maskName, fileName)

% Kay Henning Brodersen, University of Oxford
% -------------------------------------------------------------------------
function subj = load_nifti_pattern(subj, newPatternName, maskName, fileName)

    % Check input
    % 'filename' must not contain extension
    [path,file,ext] = fileparts(fileName);
    
    % Get a temporary filestem
    tmpFilestem = ['tmp_', getUniqueId, '_'];
    
    % Convert existing NIFTI mask into ANALYZE pattern (and store in tmp
    % directory)
    tryFsl(['fslchfiletype ANALYZE ', ...
        fullfile(path,file), '.nii.gz ', ...
        fullfile(tempdir,[tmpFilestem,file])]);
    
    % Load ANALYZE mask (from tmp directory)
    spm_defaults;
    subj = load_analyze_pattern(subj, newPatternName, maskName, ...
        fullfile(tempdir,[tmpFilestem,file,'.img']));

    % Delete ANALYZE files
    unix(['rm ', fullfile(tempdir,[tmpFilestem,file,'.img'])]);
    unix(['rm ', fullfile(tempdir,[tmpFilestem,file,'.hdr'])]);
    
end
