function [data,scratch] = loadDataLight(subj, args, scratch)
    data = args.data;
end
