function labels = loadLabelsLight(subj, args)
    if nargin==0
        labels = 2;
    else
        labels = args.labels;
    end
end
