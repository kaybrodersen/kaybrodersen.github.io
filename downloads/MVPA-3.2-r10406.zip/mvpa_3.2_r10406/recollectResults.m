% Recollect results.
%
% Usage:
%     recollectResults(fileSettings);
%     recollectResults(fileSettings, checkOnly);
%
% Parameters:
%     fileSettings - filename of the settings file; this may be a local or
%         a remote file
%
% Additional named arguments:
%     'checkOnly' [default: false] Quick check whether all results are
%         present or whether some haven't finished yet
%     'recollect_func' [default: whatever is defined in the settings file
%         that is loaded] A recollection function, e.g.,
%         @recollect_accuracies
%     'recollect_args'
%     'iScans' - NaN (default): prompt to select scans
%                [1:24]: select scans 1 through 24
%                []: select whichever scans are available
%
% If the specified settings file cannot be found locally, the user will be
% prompted to choose a retrieve function. This function will in turn be
% invoked to retrieve the results from a remote location and put them
% neatly in place locally so that they look as if they had been produced
% locally.

% Kay H. Brodersen, University of Oxford / ETZH / UZH
% $Id: recollectResults.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function settings = recollectResults(fileSettings, varargin)
    
    % Try to load settings from local disk
    if ~exist('fileSettings', 'var')
        error('no settings file specified');
    end
    settings = loadSettings(fileSettings, false, false, false);
    
    % Declare global variables
    global LOGFILE;
    LOGFILE = [];
    global OUTPUT_INDENT;
    OUTPUT_INDENT = 0;
    global FSL_COMMAND_PREFIX;
    try
        FSL_COMMAND_PREFIX = settings.fslCommandPrefix;
    end
    
    % Check input
    defaults.checkOnly = false;
    defaults.recollect_func = [];
    defaults.recollect_args = [];
    defaults.iScans = NaN;
    args = propval(varargin, defaults, 'strict', false);
    
    % If not found, try legacy format
    if isempty(settings)
        fileSettingsLegacy = strrep(strrep(fileSettings, '/analysis', '/mvpa/analysis'), '/log', '');
        out(' ');
        out('File not found. Now trying legacy file format:');
        out(fileSettingsLegacy);
        settings = loadSettings(fileSettingsLegacy, false, false, false);
        if ~isempty(settings)
            fileSettings = fileSettingsLegacy;
        end
    end
    
    % Settings still not found locally?
    while isempty(settings)
        out(' ');
        out('Settings not found. Choose an option:');
        out('    1 - abort');
        retrieve_funcs = find_retrieve_funcs;
        for i=1:length(retrieve_funcs)
            out(['    ', num2str(i+1), ' - retrieve using ''', func2str(retrieve_funcs{i}), '''']);
        end
        tmp = inputout('Choice: ');
        if tmp==1
            % Abort
            out('Abort');
            return;
        else
            % Retrieve data
            retrieve_func = retrieve_funcs{tmp-1};
            out(['Retrieving results using <', func2str(retrieve_func), '>...']);
            out(['Using ', fileSettings]);
            increaseIndent;
            retrieve_func_actual = str2func(func2str(retrieve_func));
            retrieve_func_actual(fileSettings, varargin{:});
            decreaseIndent;
        end
        
        % Now try again to load settings
        settings = loadSettings(fileSettings, false, false, false);
    end
    
    % Return settings and quit?
    if nargout==1
        return;
    end
    
    % Display info
    [tmp, tmp] = fileparts(fileSettings);
    out(' ');
    out(['Analysis: ', tmp ' | ', num2str(settings.analysisId)]);
    
    % Add additional paths (e.g., for loadEV functions)
    try settings.version; catch; settings.version = 3; end
    if settings.version < 2
        if isfield(settings, 'additionalMatlabPaths')
            addpath(settings.additionalMatlabPaths);
        end
    else
        addpath(settings.matlabPaths);
    end
    
    % Find results
    [allScans, iScans] = findResults(settings, '.running', '.completed', args.checkOnly);
    if args.checkOnly || isempty(iScans)
        return
    end
    
    % Pick scans to analyse?
    if isnan(args.iScans)
        if length(iScans)>1
            out(' ');
            out(['Choose which scans you want to process. Press Enter to select all scans.']);
            for s = iScans
                out(['    ', num2str(s), ' - ', allScans{s}]);
            end
            idxScans_input = inputout('Pick your scans: ');
            if ~isempty(idxScans_input)
                iScans = idxScans_input;
            end
        end
    elseif isempty(args.iScans)
        out(' ');
        out(['Selected all ', num2str(length(iScans)), ' available scans']);
    else
        assert(containsOnly(args.iScans, iScans), 'some of your iScans were not found');
        iScans = args.iScans;
        out(' ');
        out(['Selected ', num2str(length(iScans)), ' scans']);
    end
    
    % Process results
    if ~isempty(args.recollect_func)
        % Call one specific recollection function
        recollect_wrapper(args.recollect_func, args.recollect_args, settings, allScans, iScans, varargin{:});
    else
        % Call all functions specified in 'settings'
        if ~iscell(settings.main.recollect_func)
            settings.main.recollect_func = {settings.main.recollect_func};
        end
        try settings.main.recollect_args; catch; settings.main.recollect_args = []; end
        if ~iscell(settings.main.recollect_args)
            settings.main.recollect_args = {settings.main.recollect_args};
        end
        while length(settings.main.recollect_args) < length(settings.main.recollect_func)
            settings.main.recollect_args{end+1} = [];
        end
        for r = 1:length(settings.main.recollect_func)
            recollect_wrapper(settings.main.recollect_func{r}, settings.main.recollect_args{r}, ...
                settings, allScans, iScans, varargin{:});
        end
    end    
end

% -------------------------------------------------------------------------
% Returns a list of all existing 'retrieve_*' functions found on the path.
function retrieve_funcs = find_retrieve_funcs
    
    % Initialize return value
    retrieve_funcs = {};
    
    try
        % Get path to 'retrieval' directory
        p = which('mvpaAnalysis');
        p = fileparts(p);
        p = fullfile(p, 'retrieval');
        
        % Find all 'retrieve*' functions
        fs = dir(fullfile(p, 'retrieve_*.m'));
        fs = {fs.name};
        
        % Turn them into functions
        for i=1:length(fs)
            [f, f] = fileparts(fs{i});
            retrieve_funcs{end+1} = str2func(f);
        end
    catch
        disp('(An error occurred while trying to find retrieval functions.)');
    end
    
end
