% Recollects results from a particular study and a particular analysis,
% making some assumptions about directory structures. For the full
% comprehensive function, see 'recollectResults.'
%
% Usage:
%     quickRecollect(analysisId);
%     quickRecollect(study, analysisId);
%     settings = quickRecollect(...);
% 
% Arguments:
%     study [optional]: directory name of the study (e.g., 'decmak'); if no
%         study is given, then possible studies will be listed
%     analysisId: id of the analysis
%
% Further named arguments will be passed on to 'recollectResults.'
%
% If the returned settings are caught, then no recollection will be carried
% out. The function will load the settings, return them, and quit.
% 
% See also:
%     recollectResults

% Kay H. Brodersen, University of Oxford / ETZH / UZH
% $Id: quickRecollect.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function settings = quickRecollect(arg1, arg2, varargin)
    
    % Hard-code studies location
    dirStudies = '~/studies';
    
    % Check input
    if nargin==0
        error('missing input arguments');
    elseif nargin==1
        % Assume: arg1 is an analysisId
        % Ask for study
        files = dir(fullfile(dirStudies, '*'));
        files = {files.name};
        studies = {};
        for f = 1:length(files);
            if exist(fullfile(dirStudies, files{f}), 'dir')
                studies{end+1} = files{f};
            end
        end
        disp('Choose a study:');
        for s = 1:length(studies)
            disp(['   ', num2str(s), ' - ', studies{s}]);
        end
        s = input('Choice: ');
        if ~containsOnly(s, [1:length(studies)])
            error('invalid input');
        end
        study = studies{s};
        analysisId = arg1;
    elseif nargin>=2
        % arg1: study
        % arg2: analysisId
        study = arg1;
        analysisId = arg2;
    end
    
    % Construct filename of settings file
    fileSettings = fullfile(dirStudies, study, ...
        ['results/analysis', num2str(analysisId)], 'log', ...
        ['settings', num2str(analysisId), '.mat']);
    
    if nargout==0
        disp(['Using ', fileSettings]);
        recollectResults(fileSettings, varargin{:});
    else
        settings = recollectResults(fileSettings, varargin{:});
    end
        
end
