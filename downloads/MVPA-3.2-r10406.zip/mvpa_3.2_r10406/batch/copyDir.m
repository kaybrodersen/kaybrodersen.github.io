% Copies a file or a directory recursively (like rsync -r)
%
% Usage:
%     copyDir(sourceDir, targetDir)
%     copyDir(sourceDir, targetDir, remoteHost, viaHost, selfHost)
%     copyDir(..., pars, retrieveFromRemoteHost)
%
% Arguments:
%     sourceDir - source directory (or source file)
%     targetDir - target directory (parent dir must exist)
%     remoteHost (optional) - remote host, e.g. 'bkay@brutus.ethz.ch'
%     viaHost (optional) - via host, e.g. 'kbroders@planck.inf.ethz.ch'
%     selfHost (optional) - self host, e.g. 'kbroders@iewnash.uzh.ch'
%     retrieveFromRemoteHost (optional) - set to 'true' if data is to be
%       copied from the remote host to the local host instead of from the
%       local host to the remote host (Todo: come up with a more elegant
%       interface at some point)
%     pars (optional) - additional parameters for rsync (e.g., '-p')
%
% Examples:
%     copyDir('~/results/analysis1', '~/results/analysis2');

% Kay H. Brodersen, ETHZ / UZH
% $Id: copyDir.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function copyDir(sourceDir, targetDir, remoteHost, viaHost, selfHost, pars, ...
    retrieveFromRemoteHost)
    
    % Check input
    if ~exist('remoteHost', 'var'), remoteHost = ''; end
    if ~exist('viaHost', 'var'), viaHost = ''; end
    if ~exist('selfHost', 'var'), selfHost = ''; end
    if ~exist('retrieveFromRemoteHost', 'var'), retrieveFromRemoteHost = false; end
    if ~exist('pars', 'var'), pars = ''; end
    if ~isempty(pars)
        pars = [' ', pars, ' '];
    end
    
    % Prepare shell command
    if isempty(remoteHost)
        if retrieveFromRemoteHost
            error('warning: illegal option when no remote host specified');
        end
        shellCmd = ['rsync -r ', pars, sourceDir, ' ', targetDir];
        
    elseif ~isempty(remoteHost) && isempty(viaHost) && isempty(selfHost)
        if ~retrieveFromRemoteHost
            shellCmd = ['rsync -r ', pars, sourceDir, ' ', remoteHost, ':', targetDir];
        else
            shellCmd = ['rsync -r ', pars, remoteHost, ':', sourceDir, ' ', targetDir];
        end
        
    elseif ~isempty(remoteHost) && ~isempty(viaHost) && ~isempty(selfHost)
        if ~retrieveFromRemoteHost
            shellCmd = ['ssh ', viaHost, ' <<"EOF"', sprintf('\n'), ...
                ['ssh ', remoteHost, ' ''rsync -r ', pars, ...
                selfHost, ':', sourceDir, ' ''', targetDir, ''''''], ...
                sprintf('\n'), 'EOF'];
        else
            shellCmd = ['ssh ', viaHost, ' <<"EOF"', sprintf('\n'), ...
                ['ssh ', remoteHost, ' ''rsync -r ', pars, ...
                sourceDir, ' ''', selfHost, ':', targetDir, ''''''], ...
                sprintf('\n'), 'EOF'];
        end
        
    else
        error('unexpected case');
    end
    
    % Execute shell command
    tryUnix(shellCmd);
end
