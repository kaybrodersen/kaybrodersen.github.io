% Creates an empty directory. The parent directory must exist. Works both
% for local drives as well as ssh connections.
%
% Usage:
%     createDir(targetDir)
%     createDir(targetDir, remoteHost)
%     createDir(targetDir, remoteHost, viaHost, selfHost)
%
% Arguments:
%     targetDir - target directory (parent dir must exist)
%     remoteHost - remote host
%     viaHost - via host
%     selfHost - self host
%     batch_args - batchRun args
%         .confirmCreateDir=true: ask whether to continue if directory
%         exists
%
% Examples:
%     createDir('~/results/analysis1');
%     createDir('~/results/analysis1', 'kbroders@planck');

% Kay H. Brodersen, ETHZ / UZH
% $Id: createDir.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function createDir(targetDir, remoteHost, viaHost, selfHost, batch_args)
    
    % Check input
    if ~exist('remoteHost', 'var'), remoteHost = ''; end
    if ~exist('viaHost', 'var'), viaHost = ''; end
    if ~exist('selfHost', 'var'), selfHost = ''; end
    defaults.confirm = true;
    args = mergestructs(batch_args,defaults);
    
    % Create temp dir
    tmpDir = [fullfile(tempdir, getUniqueId)];
    tryUnix(['mkdir ', tmpDir]);
    
    % If local directory: check if exists
    if args.confirmCreateDir && isempty(remoteHost) && isempty(viaHost) && isempty(selfHost)
        if exist(targetDir, 'dir')
            inputout(['Directory exists. Continue? (Ctrl+C to cancel)']);
        end
    end
    
    % Copy temp dir to target
    copyDir(fullfile(tmpDir, '/'), targetDir, remoteHost, viaHost, selfHost);
    
    % Remove temp dir
    tryUnix(['rm -r ', tmpDir]);
    
end
