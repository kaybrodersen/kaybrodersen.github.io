% Submits a job to a local SGE which runs it as a Matlab DCT worker job.
% 
% See 'submit_wrapper' interface.
% 
% Additional accepted name/value pairs:
%     'queue' - 'short', 'long', ...
%     'node' - 'planck', 'anduin', ...
%
% These name/value pairs will be passed on from batchRun().

% Kay H. Brodersen, ETHZ / UZH
% $Id: submit_local_sge_dct.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [s, submit_scratch] = submit_local_sge_dct(unixCmd, dirLog, ...
    submit_args, submit_scratch, varargin)
    
    % Get args from input?
    if ~isfield(submit_scratch, 'args')
        % Set defaults
        defaults.queue = 'short';
        defaults.node = '';
        args = propval(varargin, defaults, 'strict', false);
        
    % Get args from previous run?
    else
        args = submit_scratch.args;
    end        
        
%     % Check input
%     if ~stringInSet(args.queue, {'veryshort', 'short', 'long', 'bigmem', 'verylong'})
%         if stringInSet(args.queue, {'veryshort.q', 'short.q', 'long.q', 'bigmem.q', 'verylong.q'})
%             args.queue = args.queue(1:end-2);
%         else
%             error('invalid queue name');
%         end
%     end
    
    % Initialize scheduler (first time only)
    if ~isfield(submit_args, 'sched')
        submit_args.sched = findResource('scheduler','type','generic');
        submit_args.sched.SubmitFcn = @sgeSubmitFcnMvpa;
        submit_args.sched.DataLocation = dirLog;
        submit_args.sched.HasSharedFilesystem = true;
        submit_args.sched.ClusterMatlabRoot = '/filer/workspace/tools/matlab/diser_nash';
    end
    
    % Configure job
    job = createJob(submit_args.sched);
    job.createTask(@eval_cmd_file, 1, {submit_args.fileMatlabCmd});
    %job.Tasks(1).CaptureCommandWindowOutput = true; % debug
    
    % Prepare SUBMIT command
    % - qsub
    % - optionally with specific queue and node
    % - and unix command defined in parent function
    jobname = strrep(submit_args.jobname, '/', '_');
    if isempty(args.node)
        submitCmd = ['cd ', dirLog, '; ', ...
            'qsub -N ', jobname, ' -o ', dirLog, ' -e ', dirLog, ...
                ' -q ', args.queue, '.q "', submit_args.sgeWrapper, '"'];
        out(['Submitting job to ', args.queue, '.q']);
    else
        submitCmd = ['cd ', dirLog, '; ', ...
            'qsub -N ', jobname, ' -o ', dirLog, ' -e ', dirLog, ...
                ' -q ', args.queue, '.q@', args.node, ' "', submit_args.sgeWrapper, '"'];
        out(['Submitting job to ', args.queue, '.q@', args.node]);
    end
    job.UserData.submitCmd = submitCmd;
    
    % Submit job
    submit(job);
    s = '';
    
    % Return args in submit_scratch
    submit_scratch.args = args;
end
