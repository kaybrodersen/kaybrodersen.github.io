% Loads a matlab cmd file and executes its contents as Matlab commands.
% This is the function wrapped as a DCT worker job when using batchRun.
% 
% Usage:
%     eval_cmd_file(file)
%
% Arguments:
%     file - file with Matlab commands to be executed

% Kay H. Brodersen, ETHZ/UZH
% $Id: eval_cmd_file.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function results = eval_cmd_file(file)
    
    disp(['Now in eval_cmd_file...']);
    
    matlabCmd = tryUnix('cat /filer/workspace/kbroders/studies/tmp/matlabCmd');
    eval(matlabCmd);
    results = [];
    
end
