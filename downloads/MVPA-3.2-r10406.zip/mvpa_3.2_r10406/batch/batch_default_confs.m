% Contains default settings for s.batch.confs
%
% Usage:
%     confs = batch_default_confs
%
% Example:
%     s.batch.confs = batch_default_confs;

% Kay Henning Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function confs = batch_default_confs

    confs = struct;
    confs(1).confname = 'iewnash -> Local SGE';
    confs(1).dirCodeSource = '/filer/home/kbroders/studies/ana/mvpa/trunk';
    confs(1).login = [];
    confs(1).via = [];
    confs(1).self = [];
    confs(1).submit_func = @submit_local_sge;
    confs(1).submit_args = [];
    confs(1).svnExport = true;
    
    confs(2).confname = 'iewnash -> Local SGE/DCT (beta)';
    confs(2).dirCodeSource = '/filer/home/kbroders/studies/ana/mvpa/trunk';
    confs(2).login = [];
    confs(2).via = [];
    confs(2).self = [];
    confs(2).submit_func = @submit_local_sge_dct;
    confs(2).submit_args.sgeWrapper = '/filer/workspace/tools/matlab/dct_sge/sgeWrapper.sh';
    confs(2).svnExport = true;
    
    confs(3).confname = 'iewnash -> ETH Brutus LSF (via free)';
    confs(3).dirCodeSource = '/filer/home/kbroders/studies/ana/mvpa/trunk';
    confs(3).login = 'bkay@brutus.ethz.ch';
    confs(3).via = 'bkay@free.inf.ethz.ch';
    confs(3).self = 'kbroders@iewnash.uzh.ch';
    confs(3).submit_func = @submit_brutus_lsf;
    confs(3).submit_args = [];
    confs(3).svnExport = true;

end
