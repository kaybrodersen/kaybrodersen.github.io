% Submits a job to ETH Brutus cluster.
%
% See 'submit_wrapper' interface.
%
% Additional accepted name/value pairs:
%     'wallClockTime' - if given, overwrites submit_args.wallClockTime setting
%     'memory' - if given, overwrites submit_args.memory setting

% Kay H. Brodersen, ETHZ / UZH
% $Id: submit_brutus_lsf.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [s, submit_scratch] = submit_brutus_lsf(unixCmd, dirLog, ...
    submit_args, submit_scratch, varargin)
    
    % Get args from input?
    if ~isfield(submit_scratch, 'args')
        % Set defaults
        if isfield(submit_args, 'wallClockTime')
            defaults.wallClockTime = submit_args.wallClockTime;
        else
            defaults.wallClockTime = []; % required run time in minutes (Brutus default: 60 min)
        end
        if isfield(submit_args, 'memory')
            defaults.memory = submit_args.memory;
        else
            defaults.memory = [];
        end
        args = propval(varargin, defaults, 'strict', false);
        
    % Get args from previous run?
    else
        args = submit_scratch.args;
    end        
    
    % Check input
    increaseIndent;
    if isempty(args.wallClockTime)
        out(' ');
        out('Without defining a WallClockTime value, all jobs will be killed after');
        out('60 minutes. Do you wish to specify a wallClockTime now?');
        tmpWallClockTime = inputout('WallClockTime [Enter = default 60 min]: ');
        if ~isempty(tmpWallClockTime)
            out(['WallClockTime [min]: ', num2str(tmpWallClockTime), ' min']);
        else
            tmpWallClockTime = 'default';
            out(['WallClockTime [min]: (default)']);
        end
        args.wallClockTime = tmpWallClockTime;
    end
    if isempty(args.memory)
        out(' ');
        out('Without defining a Memory value, the job is only allowed 2048 MB of memory.');
        out('Do you wish to specify a Memory value now?');
        tmpMemory = inputout('Memory [Enter = default 2048 MB]: ');
        if ~isempty(tmpMemory)
            out(['Memory [MB]: ', num2str(tmpMemory), ' MB']);
        else
            tmpMemory = 'default';
            out(['Memory [MB]: (default)']);
        end
        args.memory = tmpMemory;
        out(' ');
    end
    decreaseIndent;
    
    % Retrospectively modify MATLAB command (a bit of a hack)
    % see http://brutuswiki.ethz.ch/brutus/MATLAB
    unixCmd = strrep(unixCmd, '-nojvm', '-nojvm -singleCompThread');
    
    % Prepare SUBMIT command
    % - source Brutus default bashrc for general envt variables
    % - set up what is set up in my .bashrc when in an interactive shell:
    %     - set FSLDIR
    %     - add FSLDIR/bin to PATH
    % - cd to analysis-specific remote joblog directory
    % - submit job with unix command defined by parent function
    submitCmd = ['source /etc/bashrc ', ...
        '&& export FSLDIR=/cluster/home/infk/bkay/studies/software/fsl ', ...
        '&& source ${FSLDIR}/etc/fslconf/fsl.sh ', ... 
        '&& export PATH=$FSLDIR/bin:/cluster/apps/matlab/r2010a/bin:$PATH ', ...
        '&& export OMP_NUM_THREADS=1 ', ...   % see brutuswiki.ethz.ch/brutus/MATLAB
        '&& cd ', dirLog, ' ', ...
        '&& bsub -r'];
    if ~isempty(args.wallClockTime) && ~strcmp(args.wallClockTime, 'default')
        submitCmd = [submitCmd, ' -W ', num2str(args.wallClockTime)];
    end
    if ~isempty(args.memory) && ~strcmp(args.memory, 'default')
        submitCmd = [submitCmd, ' -R ''rusage[mem=', num2str(args.memory), ']'''];
    end
    if ~isempty(submit_args.jobname)
        submitCmd = [submitCmd ' -J "', submit_args.jobname, '"'];
    end
    submitCmd = [submitCmd, ' "', unixCmd, '"'];
    
    % Submit job (by executing SSH command)
    s = trySsh(submitCmd, submit_args.login, submit_args.via);
%     if isempty(submit_args.via) && isempty(submit_args.self)
%         sshCmd = ['ssh ', submit_args.login, ' ''', submitCmd, ''''];
%     elseif ~isempty(submit_args.via) && ~isempty(submit_args.self)
% %         sshCmd = ['ssh ', submit_args.via, ' ''ssh ', submit_args.login, ' ''', ...
% %             submitCmd, ''''''];
%         sshCmd = ['ssh ', submit_args.via, ' <<"EOF"', sprintf('\n'), ...
%             ['ssh ', submit_args.login, ' ''', submitCmd, ''''], ...
%             sprintf('\n'), 'EOF'];
%     else
%         error('unexpected case');
%     end
    
    % A correct sshCmd should look as follows:
    % - if direct route to host:
    % ssh bkay@brutus 'source /etc/bashrc && export FSLDIR=/cluster/home/infk/bkay/software/fsl && source ${FSLDIR}/etc/fslconf/fsl.sh && export PATH=$PATH:$FSLDIR/bin && cd ~/studies/decmak/results/mvpa/analysis416 && bsub -r -J "settings_decmak/a416/s1" "matlab -nojvm -nodisplay -nosplash < ~/studies/decmak/results/mvpa/analysis416/matlabCmd"'
    %
    % - if via other host:
    % ssh kbroders@planck.inf.ethz.ch <<"EOF"
    % ssh bkay@brutus.ethz.ch 'source /etc/bashrc && export FSLDIR=/cluster/home/infk/bkay/software/fsl && source ${FSLDIR}/etc/fslconf/fsl.sh && export PATH=$PATH:$FSLDIR/bin && export OMP_NUM_THREADS=1 && cd ~/studies/decmak/results/analysis500/log && bsub -r -J "settings_decmak/a500/s1" "matlab -nojvm -singleCompThread -nodisplay -nosplash < ~/studies/decmak/results/analysis500/log/matlabCmd-20100125-175837-995762-4596"'
    % EOF
    
%     % Submit job
%     s = tryUnix(sshCmd);
    
    % Return args in submit_scratch
    submit_scratch.args = args;
 
end
