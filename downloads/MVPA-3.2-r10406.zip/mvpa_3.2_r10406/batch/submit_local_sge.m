% Submits a job to a local SGE.
%
% See 'submit_wrapper' interface.
% 
% Additional accepted name/value pairs:
%     'queue' - 'short', 'long', ...
%     'node' - 'planck', 'anduin', ...
%
% These name/value pairs will be passed on from batchRun().

% Kay H. Brodersen, ETHZ / UZH
% $Id: submit_local_sge.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [s, submit_scratch] = submit_local_sge(unixCmd, dirLog, ...
    submit_args, submit_scratch, varargin)
    
    % Get args from input?
    if ~isfield(submit_scratch, 'args')
        % Set defaults
        defaults.queue = 'short.q';
        defaults.node = '';
        args = propval(varargin, defaults, 'strict', false);
        
    % Get args from previous run?
    else
        args = submit_scratch.args;
    end        
        
%     % Check input
%     if ~stringInSet(args.queue, {'veryshort', 'short', 'long', 'bigmem', 'verylong'})
%         if stringInSet(args.queue, {'veryshort.q', 'short.q', 'long.q', 'bigmem.q', 'verylong.q'})
%             args.queue = args.queue(1:end-2);
%         else
%             error('invalid queue name');
%         end
%     end
    
    % Prepare SUBMIT command
    % - fsl_sub
    % - optionally with specific queue and node
    % - and unix command defined in parent function
    if isempty(args.node)
        submitCmd = ['cd ', dirLog, '; ', ...
            'fsl_sub -q ', args.queue, ' "', unixCmd, '"'];
        out(['Submitting job to ', args.queue]);
    else
        submitCmd = ['cd ', dirLog, '; ', ...
            'fsl_sub -q ', args.queue, '@', args.node, ' "', unixCmd, '"'];
        out(['Submitting job to ', args.queue, '@', args.node]);
    end
    
    % A correct submitCmd should now look as follows:
    % cd ~/studies/decmak/results/mvpa/analysis416; fsl_sub -q short.q "matlab -nojvm -nodisplay -nosplash < ~/studies/decmak/results/mvpa/analysis416/matlabCmd"
    
    % Submit job
    s = tryUnix(submitCmd);
    
    % Return args in submit_scratch
    submit_scratch.args = args;
end
