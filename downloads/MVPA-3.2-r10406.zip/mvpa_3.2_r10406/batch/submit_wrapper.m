% Wrapper for submitting a job to a batch system.
%
% Callee interface:
%     s = submit_func(submit_func, unixCmd, dirLog, submit_args, varargin)
%
% Arguments:
%     settings
%     iScans
%     jobname
%     submit_func
%     submit_args
%     submit_scratch
%
% Any additional name/value pairs will be passed on to 'submit_func'.

% Kay H. Brodersen, ETHZ/UZH
% $Id: submit_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [s, submit_scratch] = submit_wrapper(settings, iScans, jobname, ...
    submit_func, submit_args, submit_scratch, varargin)
    
    % Turn iScans into string
    strScans = strrep(mat2str(iScans), ' ', ',');
    
    % Go through all instances
    for instance = 1:settings.nInstances
        
        % Prepare MATLAB command
        % - cd into analysis-specific remote code directory
        % - add mvpa/main to path
        % - then invoke addMvpaPaths
        % - then run mvpaAnalysis
        matlabCmd = ['cd(''', fullfile(settings.dirCode, 'mvpa'), ''');', ...
            'addMvpaPaths(''', fullfile(settings.dirCode, 'mvpa'), ''');', ...
            'args.fileSettings=''', [settings.dirLog, '/settings', ...
            num2str(settings.analysisId), '.mat'], ''';', ...
            'args.iScans=', strScans, ';args.instance=', num2str(instance), ';' ...
            'mvpaAnalysis(args);quit;'];
        
        % Store this MATLAB command in log directory
        fileMatlabCmd = ['matlabCmd_', getUniqueId];
        f=fopen(fullfile(tempdir, fileMatlabCmd), 'w');
        fwrite(f, matlabCmd);
        fclose(f);
        copyDir(fullfile(tempdir, fileMatlabCmd), fullfile(settings.dirLog, fileMatlabCmd), ...
            settings.batch.login, settings.batch.via, settings.batch.self, '-p');
        tryUnix(['rm ', fullfile(tempdir, fileMatlabCmd)]);
        submit_args.fileMatlabCmd = fullfile(settings.dirLog, fileMatlabCmd);
        
        % Prepare UNIX command
        % - run matlab (without jvm, display, splash)
        % - pipe in the matlab command defined above
        try settings.matlabBin; catch; settings.matlabBin = 'matlab'; end
        unixCmd = [settings.matlabBin, ' -nojvm -nodisplay -nosplash -singleCompThread < ', ...
            fullfile(settings.dirLog, fileMatlabCmd)];
        
        % Set login and jobname
        submit_args.login = settings.batch.login;
        submit_args.via = settings.batch.via;
        submit_args.self = settings.batch.self;
        thisJobname = jobname;
        if settings.nInstances > 1
            thisJobname = [thisJobname, '/i', num2str(instance)];
        end
        submit_args.jobname = thisJobname;
        
        % Invoke submit function
        %out(['Invoking ''', func2str(submit_func), '''']);
        out(' ');
        out(['Submitting job: ', submit_args.jobname]);
        submit_func_actual = str2func(func2str(submit_func));
        [s, submit_scratch] = submit_func_actual(unixCmd, settings.dirLog, ...
            submit_args, submit_scratch, varargin{1});
        out(s);
    
        % Print output
        %out(['    Job submitted: ', num2str(settings.analysisId), '/', num2str(out)]);
        
    end % instance
    
end
