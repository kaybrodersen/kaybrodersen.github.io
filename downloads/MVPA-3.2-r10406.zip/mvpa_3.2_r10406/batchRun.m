% Runs an MVPA analysis in batch mode.
%
% Usage:
%     batchRun;
%     batchRun(settings);
%     batchRun(settings, iScans);
%     batchRun(settings, iScans, varargin)
%
% Main parameters:
%     settings - filename of a settings file (.m or .mat) or a settings struct
%     iScans [optional] - if missing, will be asked interactively
%
% Optional name/value parameters:
%     'nSubjectsPerJob' (default: 1)
%
% All further name/value parameters will be passed on to the 'submit'
% function (via the @submit_wrapper interface). See the 'submit' functions
% for information about accepted name/value pairs.
%
% Examples:
%     - Running the currently defined analysis:
%         batchRun('settings_decmak');
%         batchRun('settings_decmak', 1:18);
%     - When using a local SGE:
%         batchRun('settings_decmak', 1:18, 'short');
%         batchRun('settings_decmak', [], 'short.q', 'anduin');
%     - When using ETH's remote LSF
%         batchRun('settings_decmak', 1:18);
%     - (Re)running a previously defined analysis:
%         batchRun('/usr/people/kbroders/study/timresults/analyses/analysis99/settings99.mat');
%     - Running a manually prepared settings struct:
%         batchRun(mySettings, 1:18);

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: batchRun.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function batchRun(fileSettings, iScans, varargin)
    
    % Initialize output
    global OUTPUT_INDENT; OUTPUT_INDENT = 0;
    welcome;
    out('BATCH MODE'); out(' ');
    
    % Default settings
    defaults.nSubjectsPerJob = 1;
    defaults.confirmCreateDir = true;
    args = propval(varargin, defaults, 'strict', false);
    
    % Initialize submit_scratch
    submit_scratch = [];
    
    % Check input
    if ~exist('fileSettings','var'); error('must specify a settings file'); end
    if ~exist('iScans', 'var') || isempty(iScans); error('must specify iScans'); end
    
    % Load settings
    settings = loadSettings(fileSettings, false, false, true);
    
    % Display info
    out(['Analysis: ', settings.dirBase]);
    out(['with ID ', num2str(settings.analysisId)]);
    out(['for subjects ', mat2str(iScans)]);
    %out(['with ', num2str(settings.nInstances), ' working instances']);
    
    % Finalize settings
    settings = finalizeSettings(settings, 'caller', 'batchRun');
    
    % If old analysis, ask whether want to use old code as well
    if strcmp(settings.origin, '.mat')
        out(' ');
        out(['Do you want to use the original code of this analysis?'])
        out(['    1 - use original code']);
        out(['    2 - replace by latest version of code']);
        codeToUse = inputout(['Which code to use: ']);
    end
    
    % Prepare new analysis directory
    try settings.batch.login; catch; settings.batch.login = []; end
    try settings.batch.via; catch; settings.batch.via = []; end
    try settings.batch.self; catch; settings.batch.self = []; end
    %
    out(' ');
    out(['Setting up output directories...']);
    out(settings.dirAnalysis);
    createDir(settings.dirAnalysis, ...
        settings.batch.login, settings.batch.via, settings.batch.self, args);
    
    % - store settings file (in dirLog)
    out(settings.dirLog);
    createDir(settings.dirLog, ...
        settings.batch.login, settings.batch.via, settings.batch.self, args);
    tmpDir = fullfile(tempdir, getUniqueId);
    tryUnix(['mkdir ', tmpDir]);
    tmpFile = ['settings', num2str(settings.analysisId), '.mat'];
    save(fullfile(tmpDir, tmpFile), 'settings');
    copyDir(fullfile(tmpDir, '/'), settings.dirLog, ...
        settings.batch.login, settings.batch.via, settings.batch.self, '-p');
    tryUnix(['rm -r ', tmpDir]);
    
    % - store code (in dirCode)
    if strcmp(settings.origin, '.m') || codeToUse==2
        createDir(settings.dirCode, ...
            settings.batch.login, settings.batch.via, settings.batch.self, args);
        if isfield(settings.batch, 'svnExport') && settings.batch.svnExport
            out([settings.dirCode, ' (exported from SVN)']);
            % export SVN trunk first
            tmpDirCode = [fullfile(tempdir, getUniqueId)];
            tryUnix(['svn export ', settings.batch.dirCodeSource, ' ', tmpDirCode]);
            % then copy
            copyDir(fullfile(tmpDirCode, '/'), fullfile(settings.dirCode, 'mvpa'), ...
                settings.batch.login, settings.batch.via, settings.batch.self, ...
                '-p -t -u --delete --force');  % --exclude ".*"
            % delete temp
            tryUnix(['rm -rf ', tmpDirCode]);
        else
            % copy directly
            out([settings.dirCode, ' (copied directly)']);
            out(['Copying trunk to ', fullfile(settings.dirCode, 'mvpa'), '...']);
            copyDir(fullfile(settings.batch.dirCodeSource, '/'), fullfile(settings.dirCode, 'mvpa'), ...
                settings.batch.login, settings.batch.via, settings.batch.self, ...
                '-p -t -u --delete --force');  % --exclude ".*"
        end
    else
        out([settings.dirCode, ' (untouched)']);
    end
    out(' ');
    
    % Submit job(s) to queue
    try settings.batch.submit_args; catch; settings.batch.submit_args = struct; end
    nScans = length(iScans);
    nJobs = fix((nScans-1)/args.nSubjectsPerJob) + 1;
    for iJob = 1:nJobs
        thisScans = iScans((iJob-1)*args.nSubjectsPerJob+1:min(iJob*args.nSubjectsPerJob,nScans));
        if length(thisScans)==1
            thisJobname = ['a', num2str(settings.analysisId), '/s', num2str(thisScans)];
        else
            thisJobname = ['a', num2str(settings.analysisId), '/s*'];
        end
        [submit_scratch, submit_scratch] = submit_wrapper(settings, thisScans, thisJobname, ...
            settings.batch.submit_func, settings.batch.submit_args, submit_scratch, varargin);
    end
    
end
