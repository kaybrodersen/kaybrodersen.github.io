% Wrapper for recollect functions.
%
% Callee interface:
%     recollect_func(settings, allScans, iScans, recollect_args, varargin);
%
% Named arguments will be passed on to the callee.

% Kay H. Brodersen, ETHZ / UZH
% -------------------------------------------------------------------------
function recollect_wrapper(recollect_func, recollect_args, settings, allScans, iScans, varargin)
    
    % Check input
    if isempty(recollect_func)
        disp(' ');
        disp('No recollection function specified');
        return;
    end
    
    out(' ');
    out('---------------------------------------------------------------');
    out(upper(func2str(recollect_func)));
    out('---------------------------------------------------------------');
    
    increaseIndent;
    recollect_func_actual = str2func(func2str(recollect_func));
    recollect_func_actual(settings, allScans, iScans, recollect_args, varargin{:});
    decreaseIndent;
    
    %out(['Recollection ''', func2str(recollect_func), ''' completed.']);
    
end
