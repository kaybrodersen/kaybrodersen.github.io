% General purpose recollection function for classification performance. Can
% be overridden by custom functions. Makes use of several supplied building
% blocks (loadPredResults, computeAccs, ...).
% 
% (See 'recollect_wrapper' interface.)
%
% Additional named arguments:
%     'forPublication' [true|false]
%     'spacing' (only when forPublication==true)
%     'offset' (only when forPublication==true)

% Kay H. Brodersen, ETHZ/UZH
% $Id: recollect_accuracies.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_accuracies(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults.forPublication = false;
    defaults.spacing = 1;
    defaults.offset = 0;
    defaults.faceColor = [0 112/255 192/255];
    defaults.errorBarsColor = [0 0 0];
    args = propval(recollect_args, defaults, 'strict', false);
    args = propval(varargin, args, 'strict', false);
    
    % Load raw results matrices (SCANS x CYCLES x TRIALS).
    %     T: targets (desired class labels)
    %     P: predictions (guessed class labels)
    %     V: decision values (if present)
    %     I: test trial indices
    %     S: scratch
    [T,P,V,I,S] = loadPredResults(settings, allScans, iScans);
    
    % Compute A: accuracies (SCANS x CYCLES)
    A = computeAccuracies(T,P);
    
    % Compute B: balanced accuracies (SCANS x CYCLES)
    B = computeBaccs(T,P);
    
    % Compute C: all confusion matrices (2 x 2 x SCANS x CYCLES)
    C = computeConfmats(T,P);
    
    % Show accuracies vs. scans (averaging across cycles)
    out(' ');
    out(['Scan                                       mean A   mean B          p_A          p_B']);
    out(['====================================================================================']);
    for s = 1:length(iScans)
        iScan = iScans(s);
        str1 = allScans{iScan};
        str2 = sprintf('%9.3f', nanmean(A(s,:),2));
        str3 = sprintf('%9.3f', nanmean(B(s,:),2));
        str4 = sprintf('%13.7f', acc_p(sum(C(:,:,s,:),4)));
        str5 = sprintf('%13.7f', bacc_p(sum(C(:,:,s,:),4)));
        out([str1, repmat(' ', 1, max([1,40-length(str1)])), str2, str3, str4, str5]);
    end
    
    % Show accuracies vs. cycles (averaging across scans)
    out(' ');
    out(['Cycle                                      mean A   mean B        p_B_heur']);
    out(['==========================================================================']);
    for cy = 1:length(settings.cycles)
        iCycle = settings.cycles(cy);
        str1 = ['CY ', num2str(iCycle)];
        str2 = sprintf('%9.3f', nanmean(A(:,cy),1));
        str3 = sprintf('%9.3f', nanmean(B(:,cy),1));
        out([str1, repmat(' ', 1, max([1,40-length(str1)])), str2, str3]);
    end
    
    % Set title
    if size(T,1)==1
        tmpTitle = ['Accuracies (', allScans{iScans}, ')'];
    else
        tmpTitle = 'Mean accuracies (averaging across scans)';
    end
    
    % Plot accuracies vs. cycles (averaging across scans)
    a = nanmean(A,1);  % average accuracy across <meanDim>
    b = nanmean(B,1);  % average balanced accuracy across <meanDim>
    nsTrials = sum(sum(~isnan(T),3),1);
    plotAccuracies(settings.cycles, a, b, [], nsTrials, settings, args, 'sig', ...
        'xlabel', 'Cycles', 'title', tmpTitle);
    
    % Plot accuracies vs. scans (across timebins and repetitions)
    a = nanmean(A,2);  % average accuracy across timebins
    b = nanmean(B,2);  % average balanced accuracy across timebins
    c = sum(C,4);      % sum confusion matrices over timebins
    nsTrials = sum(sum(~isnan(T),3),2);
    plotAccuracies(iScans, a, b, c, nsTrials, settings, args, 'ci', ...
        'xlabel', 'Scans', 'title', tmpTitle);
    
    % Plot accuracies vs. scans (but sort with descending accuracy)
    [~,sort_idx] = sortrows(b); sort_idx = sort_idx(end:-1:1);
    a_sorted = a(sort_idx);
    b_sorted = b(sort_idx);
    c_sorted = c(:,:,sort_idx);
    plotAccuracies(iScans, a_sorted, b_sorted, c_sorted, nsTrials, settings, args, 'ci', ...
        'xlabel', 'Scans', 'title', tmpTitle);
    
    % Write baccs to simple MAT file
    out(' ');
    filename = fullfile(settings.dirAnalysis, ['B', num2str(settings.analysisId), '.mat']);
    save(filename, 'B');
    out(['Written results to: ', filename]);
    
end

% -------------------------------------------------------------------------
% Produces an accuracy plot
%   a - vector of accuracies to be plotted
%   b - vector balanced accuracies to be plotted
%   c - all corresponding confusion matrices
% where size(c,3) == length(a) == length(b)
function plotAccuracies(x, a, b, c, nsTrials, settings, args, sig_or_ci, varargin)
    
    % Check input
    defaults.xlabel = '';
    defaults.title = '';
    defaults.nClasses = 2;
    defaults.newFigure = true;
    args = propval(args, defaults, 'strict', false);
    args = propval(varargin, args);
            
    % Create figure
    if args.newFigure
        figure('Name', ['Analysis ', num2str(settings.analysisId)]); hold on;
    else
        hold on;
    end
    alpha = 0.05;
    %alpha = 0.025/30; 
    
    % - draw values
%     bar(x-0.3, a, 'b', 'BarWidth', 0.8);
%     bar(x,     b, 'g', 'BarWidth', 0.8);
    if strcmp(sig_or_ci, 'sig')
        if args.forPublication
            bar([1:length(x)]*arg.spacing+args.offset-0.3, a, 0.8/args.spacing, 'facecolor', [0.8 0.8 0.8], 'edgecolor', 'none');
            bar([1:length(x)]*arg.spacing+args.offset,     b, 0.8/args.spacing, 'facecolor', args.faceColor,   'edgecolor', 'none');
        else
            bar(x-0.3, a, 0.8/args.spacing, 'facecolor', [0.8 0.8 0.8], 'edgecolor', 'none');
            bar(x,     b, 0.8/args.spacing, 'facecolor', [0 112/255 192/255], 'edgecolor', 'none');
        end            
    else
        alpha = 0.05;
        if args.forPublication
            bar([1:length(x)]*args.spacing+args.offset,b, 0.8/args.spacing, 'facecolor', args.faceColor, 'edgecolor', 'none');
        else
            bar(x-0.3, a, 0.8/args.spacing, 'facecolor', [0.8 0.8 0.8], 'edgecolor', 'none');
            bar(x,b, 0.8/args.spacing, 'facecolor', args.faceColor, 'edgecolor', 'none');
        end
        for i=1:length(a)
            if args.forPublication
                [b_lower, b_upper] = bacc_ci(c(:,:,i),alpha);
                adjustErrorBarWidth(errorbar(i*args.spacing+args.offset, b(i), b(i)-b_lower, b_upper-b(i), ...
                    'Color', args.errorBarsColor, 'LineWidth', 2), 0.2);
                %plot(i, ydm(c,:), '.', 'color', color);
            else
                [b_lower, b_upper] = bacc_ppi(c(:,:,i),alpha);
                adjustErrorBarWidth(errorbar(x(i), b(i), b(i)-b_lower, b_upper-b(i), ...
                    'Color', args.errorBarsColor, 'LineWidth', 2), 0.2);
                %plot(x, ydm(c,:), '.', 'color', color);
            end
        end
    end
    
    if length(nsTrials)==1
        % - one for all: draw a single chance and significance bar
        nTrials = nsTrials;
        [pChance, pSig] = whatIsChance(args.nClasses, nTrials, alpha/2);
        line([0 max(x)+1], [pChance pChance], 'Color', [1 1 1], 'LineWidth', 2);
        if strcmp(sig_or_ci, 'sig')
            if args.forPublication
                plotfill([0 length(x)+1+args.offset]*args.spacing, repmat(2*pChance-pSig,1,2), repmat(pSig,1,2), ...
                    'color', [0.8 0.8 0.8], 'edgecolor', 'none');
            else
                plotfill([0 max(x)+1], repmat(2*pChance-pSig,1,2), repmat(pSig,1,2), ...
                    'color', [0.8 0.8 0.8], 'edgecolor', 'none');
            end
        end
    else
        % - per scan: draw scan-specific chance and significance bars
        for xi = 1:length(x)
            iScan = x(xi);
            nTrials = nsTrials(xi);
            [pChance, pSig] = whatIsChance(args.nClasses, nTrials, alpha/2);
            if args.forPublication
                line([xi*args.spacing+args.offset-0.4 xi*args.spacing+args.offset+0.4], ...
                    [pChance pChance], 'Color', [1 1 1], 'LineWidth', 2);
            else
                line([iScan-0.4 iScan+0.4], [pChance pChance], 'Color', [1 1 1], 'LineWidth', 2);
            end
            if strcmp(sig_or_ci, 'sig')
                if args.forPublication
                    plotfill([xi*args.spacing+args.offset-0.4 xi*args.spacing+args.offset+0.4], ...
                        repmat(2*pChance-pSig,1,2), repmat(pSig,1,2), ...
                        'color', [0.8 0.8 0.8], 'edgecolor', 'none');
                else
                    plotfill([iScan-0.4 iScan+0.4], repmat(2*pChance-pSig,1,2), repmat(pSig,1,2), ...
                        'color', [0.8 0.8 0.8], 'edgecolor', 'none');
                end
            end
        end
    end
   
%     % - draw mean line
%     line([min(x)-1 max(x)+1], [nanmean(a) nanmean(a)], 'Color', 'b', 'LineWidth', 3);
%     line([min(x)-1 max(x)+1], [nanmean(b) nanmean(b)], 'Color', 'g', 'LineWidth', 3);
    
    % - adjust axes
    axis tight;
    v = axis;
    v(3:4) = [0 1];
    axis(v);
    title(['Analysis ', num2str(settings.analysisId), ' - ', args.title], 'interpreter', 'none');
    xlabel(args.xlabel);
    set(gca, 'box', 'on');
    if args.forPublication
        set(gca, 'xtick', []); % remove x ticks
    end
    
%     % Further adjustments
%     if args.forPublication
%         set(gca, 'XTick', []);
%         xlabel('');
%         set(gca, 'Box', 'on');
%     end
end
