% Recollection function for learn-model runs using anaLearnModel.m and when
% based on LIBSVM.
% 
% This function analyses two things:
%
%     1. the parameter estimates from the configuration (optimization) phase
%     2. the model from the training phase, which in turn contain the
%        support vectors which allow us to compute feature weights
% 
% (See 'recollect_wrapper' interface.)

% Kay H. Brodersen, ETHZ/UZH
% $Id: recollect_conf_libsvm.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_conf_libsvm(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults.invertWeights = false;
    defaults.xaxis = [];
    defaults.parlabels = {'A(2,1)','A(3,1)','A(1,2)','A(3,2)','A(1,3)','A(2,3)','B(2,1,2)','B(2,1,3)','C(1,1)'};
    
    args = propval(recollect_args, defaults, 'strict', false);
    args = propval(varargin, args, 'strict', false);
    
    % Load raw results matrices (SCANS x CYCLES x TRIALS).
    %     T: targets (desired class labels)
    %     P: predictions (guessed class labels)
    %     V: decision values (if present)
    %     I: test trial indices
    %     S: scratch (SCANS x CYCLES cell array)
    [T,P,V,I,S] = loadPredResults(settings, allScans, iScans);
    
    % Collect LIBSVM parameter optima into a matrix
    % allPars = SCANS x CYCLES x nPARS
    %
    % Missing results (e.g., due to cancelled timebins) will be represented
    % by NaNs.
    allPars = [];
    
    % Go through all SCANS
    for s = 1:length(iScans)
        iScan = iScans(s);
        
        % Go through all CYCLES
        for cy = 1:length(settings.cycles)
            iCycle = settings.cycles(cy);
            
            % Do the preallocation of 'allPars'
            if isempty(allPars)
                % - get parameter names and ranges
                pars = S{s,cy}.args.conf.pars;
                % - preallocate 'allPars'
                allPars = NaN(max(iScans), length(settings.cycles), length(pars));
            end
            
            % Collect parameter optima for this subject
            allPars(s,cy,:) = S{s,cy}.args.conf.opt;
            
%             % Visualize (debug)
%             if isfield(thisResult.data.conf, 'results')
%                 m = fix(sqrt(length(iScans)));
%                 n = ceil(length(iScans)/m);
%                 subplot(m,n,i); hold on;
%                 title(['Subject ', num2str(s)]);
%                 pars = thisResult.data.conf.pars;
%                 results = thisResult.data.conf.results;
%                 [v_opt, i_opt] = max(results.vs);
%                 x_opt = results.xs(i_opt,:);
% 
%                 if length(pars) == 2
%                     plot(log(pars(2).range)./log(2),results.vs,'.');
%                     xlabel(['log_2 ', pars(2).name]);
%                     plot(log(x_opt(2))/log(2), v_opt, 'r.');
%                     axis([log(pars(2).range(1))/log(2), log(pars(2).range(end))/log(2), 50, 100]);
% 
%                 elseif length(pars) == 3
%                     r1 = pars(2).range';
%                     r2 = pars(3).range';
%                     z = reshape(results.vs, length(r2), length(r1));
%                     surf(r1,r2,z);
%                     plot3(results.xs(:,2), results.xs(:,3), results.vs, '.');
%                     plot3(x_opt(2), x_opt(3), v_opt, 'r.');
%                     xlabel(pars(2).name);
%                     ylabel(pars(3).name);
%                 end
%             end

        end % cycle
    end % subject
    
    
    % ---------------------------------------------------------------------
    % ANALYSIS 1
    % Analyses the results from the conf stage: the parameter estimates
    % ---------------------------------------------------------------------
    x = allPars;
    warning off MATLAB:log:logOfZero
    
    % Show individual parameters
    out(' ');
    out(['All         log_2 pars      ']);
    out(['=========================================']);
    for cy = 1:length(settings.cycles)
        iCycle = settings.cycles(cy);
        out(['Cycle ', num2str(iCycle)]);
        for s = iScans
            str1 = allScans{s};
            tmp = x(s,cy,:);
            tmp = tmp(:)';
            tmp = log(tmp) ./ log(2);
            str2 = mat2str(tmp);
            out([str1, repmat(' ', 1, 12-length(str1)), ...
                str2]);
        end % s
    end % cy
            
    % Show parameters per subject (across all timebins)
    out(' ');
    out(['Scan        log_2 mean pars']);
    out(['==========================================']);
    for s = iScans
        str1 = allScans{s};
        tmp = nanmean(x(s,:,:),2);
        tmp = tmp(:)';
        tmp = log(tmp) ./ log(2);
        str2 = mat2str(tmp);
        out([str1, repmat(' ', 1, 12-length(str1)), ...
            str2]);
    end
    
    % Show parameters per timebins (across all subjects)
    out(' ');
    out(['Cycle       log_2 mean pars']);
    out(['==========================================']);
    for cy = 1:length(settings.cycles)
        iCycle = settings.cycles(cy);
        str1 = ['CY ', num2str(iCycle)];
        str2 = mat2str(log(squeeze(nanmean(x(:,cy,:),1)))'/log(2));
        out([str1, repmat(' ', 1, 12-length(str1)), ...
            str2]);
    end % cy
    
    % Show grand mean
    out(' '); out(' ');
    tmp = nanmean(nanmean(x,1),2);
    tmp = tmp(:)';
    tmp = log(tmp)./log(2);
    out(['Log_2 grand mean ......: ', mat2str(tmp)]);
    
    tmpPlot = inputout(['Show parameter plots? (0=no 1=yes) ']);
    
    % Plot pars vs. cycles (across subjects)
    if tmpPlot
        meanDim = 1;
        strXLabel = 'Cycles';
        strDescr = 'Parameters (means across subjects)';
        plotPars(settings, pars, x, meanDim, strXLabel, strDescr);
    end
    
    % Plot pars vs. subjects (across cycles)
    if tmpPlot
        meanDim = 2;
        strXLabel = 'Scans';
        strDescr = 'Parameters (means across cycles)';
        plotPars(settings, pars, x, meanDim, strXLabel, strDescr);
    end
    
    % ---------------------------------------------------------------------
    % ANALYSIS 2
    % Analyses the results from the train phase: given the support vectors,
    % computes the feature weights.
    % ---------------------------------------------------------------------
    assert(numel(S)==length(iScans));
    
    % Check that a linear or polynomial kernel was used
    kernel = S{1,1}.model.Parameters(1);
    if ~containsOnly(kernel, [0 1])
        error(['feature weights only implemented yet for linear and polynomial kernel']);
    end
    
    % This is what LIBSVM stores in its .model.Parameters vector:
    % In the case of a linear kernel:
    % 1: svm_type s (0)
    % 2: kernel_type t (0)
    % 3: degree d (3) [meaningless]
    % 4: gamma g (1/nFeatures) [meaningless]
    % 5: coef0 (0) [meaningless]
    %
    % In the case of a polynomial kernel
    % 1: svm_type s (0)
    % 2: kernel_type t (1)
    % 3: degree d (if polynomial, 3)
    % 4: gamma g
    % 5: coef0 r
    
    % Reconstruct feature weights for each subject
    if true
        acc_w = [];
        acc_k = [];
        for s = 1:length(iScans)
            iScan = iScans(s);
            scan = allScans{iScan};
            scr = S{s,1};
            
            % Get everything needed to compute weight vector
            % w = \sum y_i alpha_i phi(x_i)
            assert(kernel==0 || kernel==1);
            y     = scr.sv_labels';     % nSVs x 1
            alpha = scr.model.sv_coef;  % nSVs x 1
            x     = scr.model.SVs;      % nSVs x nFeatures
            
            % Get feature space phi(x)
            dirMem = fullfile(settings.dirAnalysis, scan);
            memFile = ['fs', num2str(settings.analysisId)];
            try
                % Try and load from disk
                fs = recallData(dirMem, memFile, false);
                phix = fs.phix;
                k = fs.k;
                features = fs.features;
                out(['Scan ', num2str(iScan), ': loaded feature space from disk']);
            catch
                % Compute from scratch
                out(['Scan ', num2str(iScan), ': now computing feature space...']);
                % - Linear kernel
                if kernel==0
                    %    K(x,y) = x'*y
                    %    phi(x) = x
                    phix = x;
                    k = [];
                    features = [];
                % - Polynomial kernel?
                elseif kernel==1
                    %    K(x,y) = (gamma * x'*y + coef0) ^ degree
                    %    phi(x) = a lenghty sum of polynomials
                    degree = scr.model.Parameters(3);
                    gamma = scr.model.Parameters(4);
                    coef0 = scr.model.Parameters(5);
                    [phix, k, features] = feature_map_polynomial(x, degree, gamma, coef0);
                end
                
                % Save to disk
                fs = struct;
                fs.phix = phix;
                fs.k = k;
                fs.features = features;
                memorizeData(dirMem, memFile, fs, false);
            end
            
            % Compute weight vector
            nFeatures = size(phix,2);
%             w = repmat(y,1,nFeatures) ...
%                 .* repmat(alpha,1,nFeatures) ...
%                 .* phix;
            w = repmat(alpha,1,nFeatures) ...
                .* phix;
            w = full(sum(w,1));
            
            % Accumulate
            acc_w = [acc_w; w];
            acc_k = [acc_k; k];
        end
        
        % Normalize
        out(['Normalizing weight vector']);
        for i=1:size(acc_w,1)
            acc_w(i,:) = acc_w(i,:) / sum(abs(acc_w(i,:)));
            %disp(['Sum is: ', num2str(sum(abs(acc_w(i,:))))]);
            
            % Invert weights?
            if any(args.invertWeights==i)
                acc_w(i,:) = -acc_w(i,:);
            end
        end
        
        % Visualize weight vectors for all scans
        visualizeWeights(acc_w, acc_k, features, allScans(iScans), args);
    end
    
end

% -------------------------------------------------------------------------
% Helper function: visualizes a weight vector
function visualizeWeights(acc_w, acc_k, features, scans, args)
    
    % Check input
    n = size(acc_w,1);
    assert(isempty(acc_k)||n==size(acc_k,1));
    assert(n==length(scans));
    assert(n>0);
    assert(size(acc_w,2)>0);
    
    % Create figure
    figure; hold on;
    for i=1:n
        % Make subplot
%         rows = round(sqrt(n));
%         cols = ceil(n/rows);
        rows = 1;
        cols = n;
        subplot(rows, cols, i); hold on;
            
        % Draw unsorted bars
        barh(acc_w(i,:), 'facecolor', [0 176 80]/255, 'edgecolor', 'none');
        %xlabel('hyperplane component');
        %ylabel('feature');
        axis ij;
        set(gca, 'box', 'on');
        set(gca, 'ygrid', 'on');
        
        if ~isempty(args.xaxis)
            v=axis;
            v(1:2) = args.xaxis;
            axis(v);
        end
        
        % Add variable names
        if i==1
            ticks = 1:size(acc_w,2);
            set(gca, 'YTickLabel', args.parlabels);
            set(gca, 'YTick', ticks);
        else
            set(gca, 'YTick', ticks);
            set(gca, 'YTickLabel', {});
        end
    end
    
end

% -------------------------------------------------------------------------
% Helper function: produces a parameter plot
function plotPars(settings, pars, x, meanDim, strXLabel, strDescr)
    
    % Set color map
    mymap = [0 0 1; 0 0.8 0; 0.8 0 0; 0 0 0; 1 1 0; 0 1 1];
    
    % Make figure
    figure('Name', ['Analysis ', num2str(settings.analysisId)]); hold on;
    handles = [];
    
    for p = 1:size(x,3)
        thisValues = nanmean(x(:,:,p),meanDim);
        % - range lines
        plot([0.5 length(thisValues)+0.5], log([pars(p).range(1), pars(p).range(1)])./log(2), ...
            'color', mymap(p,:), 'linewidth', 2);
        plot([0.5 length(thisValues)+0.5], log([pars(p).range(end), pars(p).range(end)])./log(2), ...
            'color', mymap(p,:), 'linewidth', 2);
        % - range fill area
        plotfill([0.5 length(thisValues)+0.5], log([pars(p).range(1), pars(p).range(1)])./log(2), ...
            log([pars(p).range(end), pars(p).range(end)])./log(2), 'color', mymap(p,:)+([1 1 1]-mymap(p,:))/2, ...
            'transparency', 0.2);
        % - values
        handles(p) = plot([1:length(thisValues)]+0.2*p, log(thisValues) ./ log(2), '.', 'color', mymap(p,:), ...
            'markersize', 25);
    end
    title(['Analysis ', num2str(settings.analysisId), ' - ', strDescr], ...
        'interpreter', 'none');
    xlabel(strXLabel);
    ylabel('log_2');
    strLegend = cell(size(x,3),1);
    for p = 1:size(x,3)
        strLegend{p} = pars(p).name;
    end
    legend(handles, strLegend);
    
end
