% Recollection function for spatial LFP analyses.
% 
% (See 'recollect_wrapper' interface.)
%
% Example:
%     recollectResults('~/studies/elec/results/mvpa/analysis55/settings55.mat',
%     'recollect_func', @recollect_lfp_spatial)
%
% Additional named arguments:
%     electrodes: if given, data will be reordered to match the
%         physical layout of the electrode. Argument can be given as a
%         vector or as a filename from which locations will be loaded

% Kay H. Brodersen, ETHZ/UZH
% $Id: recollect_lfp_spatial.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_lfp_spatial(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults.electrodes = [];
    args = propval(recollect_args, defaults);
    args = propval(varargin, args, 'strict', false);
    
    % Load raw results matrices (SCANS x CYCLES x TRIALS).
    [D,G,V] = loadRawResults(settings, allScans, iScans);
    nsTrials = sum(sum(~isnan(D),3),2);
    nTrials = sum(nsTrials);
    
    % Compute accuracies
    [A,B,C] = computeAccuracies(D,G);
    
    % Make scans string
    strScans = '';
    for s = iScans
        strScans = [strScans, allScans{s}, ' '];
    end
    strScans = strScans(1:end-1);
    
    % Get electrode locations
    electrodes = args.electrodes;
    if ischar(electrodes)
        electrodes = load(electrodes);
    elseif isempty(electrodes)
        electrodes = 1:size(B,2);
    end
    electrodes = electrodes(:)';
    assert(containsOnly(electrodes, [1:size(B,2)]));
    assert(length(unique(electrodes))==length(electrodes));
    x = 1:length(electrodes);
    
    b = nanmean(B,1);
    b = b(electrodes);
    
    % Plot accuracies vs. electrodes (averaging across scans)
    hold on;
    % - draw values
    barh(x, b, 'facecolor', [255 189 17]/255, 'edgecolor', [183 133 0]/255, 'BarWidth', 0.8);
%     % - draw confidence intervals
%     alpha = 0.05;
%     loadLabels_func_actual = str2func(func2str(settings.loadLabels_func));
%     nClasses = loadLabels_func_actual();
%     [pChance, pSig] = whatIsChance(nClasses, nTrials, alpha/2);
%     c = squeeze(round(mean(C,3)));
%     for i=1:length(b)
%         [b_lower, b_upper] = bacc_ci(c(:,:,i),alpha);
%         adjustErrorBarWidth(errorbar(x(i), b(i), b(i)-b_lower, b_upper-b(i), ...
%             'Color', [183 133 0]/255, 'LineWidth', 2), 0.2);
%         %plot(x, ydm(c,:), '.', 'color', color);
%     end
    % - draw chance bar
    alpha = 0.05;
    loadLabels_func_actual = str2func(func2str(settings.loadLabels_func));
    nClasses = loadLabels_func_actual();
    [pChance, pSig] = whatIsChance(nClasses, nTrials, alpha/2);
    line([min(x) max(x)], [pChance pChance], 'Color', [0.5 0.5 0.5], 'LineWidth', 3);
    % - set title, axes
    %axis tight;
    axis ij;
    v = axis;
    v(1:2) = [0 1];
    axis(v);
    title(['Analysis ', num2str(settings.analysisId), ' - Mean accuracies (scans ', strScans, ')'], ...
        'interpreter', 'none');
    tmpLabel = 'Electrodes';
    if ~all(electrodes==[1:size(x,2)])
        tmpLabel = [tmpLabel, ' (in true physical order)'];
    end
    ylabel(tmpLabel);
    v = axis;
    v(1) = 0.7;
    axis(v);
    
end
