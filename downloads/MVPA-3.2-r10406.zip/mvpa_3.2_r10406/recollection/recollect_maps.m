% Recollects maps.
% 
% See 'recollect_wrapper' interface.
%
% Additional named arguments:
%     'debug' (true|false) - if set to true, intermediate maps will
%         not be removed at the end of the process (default: false)
%     'smoothingSigma' (mm) - determine smoothing of resulting maps. If
%         provided, overrides the value in recollect_args
%     'compute_t_above_chance_map' - whether to compute a map of t scores
%         of a statistical test whether the accuracy is significantly above
%         chance (default: false)

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: recollect_maps.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_maps(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults.debug = false;
    defaults.smoothingSigma = 2;
    defaults.compute_t_above_chance_map = false;
    args = propval(recollect_args, defaults, 'strict', false);
    args = propval(varargin, args, 'strict', false);
    if ~exist(args.fileStandardBrain, 'file')
        error(['Standard brain ''', args.fileStandardBrain, ''' not found']);
    end
    if ~exist(args.fileStandardMask, 'file')
        error(['Standard mask ''', args.fileStandardMask, ''' not found']);
    end
    if ~isfield(recollect_args, 'smoothingSigma')
        out(['NOTE: using default value for smoothingSigma := ', ...
            num2str(args.smoothingSigma), ' mm' ]);
        out(' ');
    end
    
    % Get some general info from settings
    nScans = length(iScans);
    nCycles = length(settings.cycles);
    try loadLabels_func = settings.loadLabels_func; catch; loadLabels_func = settings.loadTrainLabels_func; end
    loadLabels_func_actual = str2func(func2str(loadLabels_func));
    nClasses = loadLabels_func_actual();
    if nClasses>0
        pChance = 1/nClasses;
    else
        args.compute_t_above_chance_map = false;
    end
    
    % Welcome
    out(['Creating maps for: ', settings.fileSettings, ' | ', ...
        num2str(length(settings.cycles)), ' cycle(s) | ', num2str(nScans), ' subjects']);
    out(['Both positive and negative values will be dealth with correctly.']);
    
    % Transform into standard space
    out(' ');
    out(['Step 1: transforming maps into standard space and smoothing (sigma=', num2str(args.smoothingSigma) 'mm)...']);
    fileOut = ['map', num2str(settings.analysisId)];
    filesRefmaskStandardBin = '';
    filesRefmaskStandardBinSmoothed = '';
    for is = 1:length(iScans)
        s = iScans(is);
        progress(is,nScans);
        
        % Define filenames
        fileMap = fullfile(settings.dirAnalysis, allScans{s}, fileOut);
        fileMapStandard = [fileMap, '_standard'];
        fileRefmask = [fileMap, '_refmask'];
        fileRefmaskStandard = [fileRefmask, '_standard'];
        
        % Create mask of non-zero elements
        tryFsl(['fslmaths ', fileMap, ' -abs -bin ', fileRefmask]);
        
        % Transform both map and refmask into standard space
        transform2std(args, settings, allScans{s}, fileMap);
        transform2std(args, settings, allScans{s}, fileRefmask);
        
        % Create binary refmask (for masking at end of this loop)
        fileRefmaskStandardBin = [fileRefmaskStandard, '_bin'];
        tryFsl(['fslmaths ', fileRefmaskStandard, ' -bin ', fileRefmaskStandardBin]);
        filesRefmaskStandardBin = [filesRefmaskStandardBin, ' ', fileRefmaskStandardBin];
        % (Does not contain holes any more, because smoothed values will be
        % binarized to 1.)
        
        % Smoothe both map and refmask (default value: 2)
        if args.smoothingSigma>0
            tryFsl(['fslmaths ', fileMapStandard, ' -s ', num2str(args.smoothingSigma), ' ', fileMapStandard]);
            tryFsl(['fslmaths ', fileRefmaskStandard, ' -s ', num2str(args.smoothingSigma), ' ', fileRefmaskStandard]);
        end
        
        % Divide smoothed map by smoothed refmask
% ####### PROBLEM HERE: holes in the refmask have led to small
% values, dividing by these will boost map values!
% ########
        tryFsl(['fslmaths ', fileMapStandard, ' -div ' , fileRefmaskStandard, ' ', fileMapStandard]);
        
        % Mask result with binary unsmoothed refmask
        tryFsl(['fslmaths ', fileMapStandard, ' -mas ', fileRefmaskStandardBin, ' ', fileMapStandard]);
        
%         % Create binary smoothed refmask (for subject numbers)
%         fileRefmaskStandardBinSmoothed = [fileRefmaskStandard, '_smoothed_bin'];
%         tryUnix(['LD_LIBRARY_PATH=; fslmaths ', fileRefmaskStandard, ' -bin ', fileRefmaskStandardBinSmoothed]);
%         filesRefmaskStandardBinSmoothed = [filesRefmaskStandardBinSmoothed, ' ', fileRefmaskStandardBinSmoothed];
%         % (Does not contain holes any more, because smoothed values will be
%         % binarized to 1.)
    end
    
    % Merge all binary unsmoothed refmasks (so that we know which subjects
    % contributed to a given voxel)
    fileRefmaskBins = fullfile(settings.dirAnalysis, [fileOut, '_bin']);
    fileNs = fullfile(settings.dirAnalysis, [fileOut, '_n']);
    tryFsl(['fslmerge -t ', fileRefmaskBins, ' ', filesRefmaskStandardBin]);
    tryFsl(['fslmaths ', fileRefmaskBins, ' -Tmean -mul ', num2str(nScans), ...
        ' ', fileNs]);
    if args.compute_t_above_chance_map
        fileNm1s = fullfile(settings.dirAnalysis, [fileOut, '_nm1']);
        fileSqrtNs = fullfile(settings.dirAnalysis, [fileOut, '_sqrtn']);
        tryFsl(['fslmaths ', fileNs, ' -sub 1 ', fileNm1s]);
        tryFsl(['fslmaths ', fileNs, ' -sqrt ', fileSqrtNs]);
    end
    
    % Split maps into cycle-maps
    out(' ');
    out('Step 2: splitting up cycles...');
    for is = 1:length(iScans)
        s = iScans(is);
        progress(is,length(iScans));
        
        % Split up cycles
        fileMapStandard = fullfile(settings.dirAnalysis, allScans{s}, ...
            [fileOut, '_standard']);
        tryFsl(['fslsplit ', fileMapStandard, ' ', fileMapStandard, '_cy']);
    end
    
    % Average cycle-maps across subjects
    out(' ');
    out('Step 3: putting cycles back together...');
    for cy = 1:nCycles
        
        % Make list of cycle-maps
        fileCycleMaps = '';
        for s = iScans
            fileCycleMaps = [fileCycleMaps, ' ', ...
                fullfile(settings.dirAnalysis, allScans{s}, ...
                [fileOut, '_standard_cy', ...
                sprintf('%04d',cy-1), '.nii.gz'])];
        end
        
        % Now merge these
        fileBase = fullfile(settings.dirAnalysis, ...
            [fileOut, '_standard_cy', num2str(cy)]);
        fileMergedMap = [fileBase, '_merged'];
        tryFsl(['fslmerge -t ', fileMergedMap, ' ', fileCycleMaps]);
        
        % Delete individual maps
        if ~args.debug
            tryUnix(['rm ', fileCycleMaps]);
        end
        
        % Compute mean map
        fileMean = [fileBase, '_mean'];
        tryFsl(['fslmaths ', fileMergedMap, ' -Tmean -mul ', ...
            num2str(nScans), ' -div ', fileNs, ' ', fileMean]);
        
        % Compute t statistic (if classification)
        if args.compute_t_above_chance_map
            % - compute std dev
            fileStd = [fileBase, '_std'];
            tryFsl(['fslmaths ', fileMergedMap, ' -sub ', fileMean, ...
                ' -sqr -Tmean -mul ', num2str(nScans), ' -div ', fileNm1s, ' -sqrt ', fileStd]);
            % - compute t
            fileT = [fileBase, '_t'];
            tryFsl(['fslmaths ', fileMean, ...
                ' -sub ', num2str(pChance), ...
                ' -div ', fileStd, ...
                ' -mul ', fileSqrtNs, ' ', fileT]);
        end
    end
    
    % Merge averaged cycle-maps across cycles
    out(' ');
    out('Step 4: putting cycle-wise statistics back together...');
    fileBaseIn = fullfile(settings.dirAnalysis, [fileOut, '_standard']);
    fileBaseOut = fullfile(settings.dirAnalysis, fileOut);
    progress(1,2); mergeMaps(fileBaseIn, fileBaseOut, nCycles, '_mean');
    if args.compute_t_above_chance_map
        progress(2,2); mergeMaps(fileBaseIn, fileBaseOut, nCycles, '_t');
    end
    
    % Mask with standard brain, to get rid of stuff outside brain
    fileMniMask = args.fileStandardMask;
    fileFinalMean = fullfile(settings.dirAnalysis, [fileOut, '_mean']);
    fileFinalT = fullfile(settings.dirAnalysis, [fileOut, '_t']);
    tryFsl(['fslmaths ', fileFinalMean, ' -mas ', fileMniMask, ' ', fileFinalMean]);
    if args.compute_t_above_chance_map
        tryFsl(['fslmaths ', fileFinalT, ' -mas ', fileMniMask, ' ', fileFinalT]);
    end
    
    % Delete temporary files
    if ~args.debug
        out('Step 5: deleting temporary files...');
        for s = iScans
            %progress(s, iScans+nCycles);
            fileMap = fullfile(settings.dirAnalysis, allScans{s}, fileOut);
            
            %tryUnix(['rm ', fileMap, '_standard.nii.gz']);
            tryUnix(['rm ', fileMap, '_refmask.nii.gz']);
            tryUnix(['rm ', fileMap, '_refmask_standard.nii.gz']);
            tryUnix(['rm ', fileMap, '_refmask_standard_bin.nii.gz']);
        end
        for cy = 1:nCycles
            %progress(iScans+cy, iScans+nCycles);
            tryUnix(['rm ', fullfile(settings.dirAnalysis, [fileOut, ...
               '_standard_cy', num2str(cy), '_merged.nii.gz'])]);
            tryUnix(['rm ', fullfile(settings.dirAnalysis, [fileOut, ...
                '_standard_cy', num2str(cy), '_mean.nii.gz'])]);
            if args.compute_t_above_chance_map
                tryUnix(['rm ', fullfile(settings.dirAnalysis, [fileOut, ...
                    '_standard_cy', num2str(cy), '_std.nii.gz'])]);
                tryUnix(['rm ', fullfile(settings.dirAnalysis, [fileOut, ...
                    '_standard_cy', num2str(cy), '_t.nii.gz'])]);
            end
        end
        tryUnix(['rm ', fileRefmaskBins, '.nii.gz']);
        %tryUnix(['rm ', fileNs, '.nii.gz']);
        if args.compute_t_above_chance_map
            tryUnix(['rm ', fileNm1s, '.nii.gz']);
            tryUnix(['rm ', fileSqrtNs, '.nii.gz']);
        end
    end
    out(['Done']);
    
end

% -------------------------------------------------------------------------
% Helper function
function mergeMaps(fileBaseIn, fileBaseOut, nCycles, suffix)
    
    % Make list of cycle maps
    cycleMaps = '';
    for cy = 1:nCycles
        cycleMaps = [cycleMaps, ' ', fileBaseIn, '_cy', num2str(cy), suffix];
    end
    
    % Merge
    tryFsl(['fslmerge -t ', [fileBaseOut, suffix], ...
        ' ', cycleMaps]);
end

% -------------------------------------------------------------------------
% Transforms a map into standard space
function transform2std(args, settings, scan, fileMap)
    
    % Filenames of maps
    fileMapStandard = [fileMap, '_standard'];
    
    % Set directories and files
    dirReg = getScanDir(args.dirReg, scan);
    fileRegL = getScanDir(fullfile(dirReg, 'example_func2highres.mat'), scan);
    fileRegNL = getScanDir(fullfile(dirReg, 'highres2standard_warp.nii.gz'), scan);
    if ~exist([fileMap, '.nii.gz'], 'file')
        error(['Map not found: ', fileMap]);
    end
    if ~exist(fileRegL, 'file')
        error(['Registration file not found: ', fileRegL]);
    end            
    if ~exist(fileRegNL, 'file')
        out(['WARNING: registration file not found: ', fileRegNL]);
        out(['--> will fall back to linear registration']);
    end
    
    % Delete existing file
    %deleteIfExists([fileMap, '_standard.nii.gz']);
    
    % Linear version?
    if ~exist(fileRegNL, 'file')
        %out('Attempting linear transform back into standard space');
        tryUnix(['flirt -in ', [makeAbsolutePath(fileMap), '.nii.gz'], ...
            ' -ref ', makeAbsolutePath(args.fileStandardBrain), ...
            ' -applyxfm -init ', makeAbsolutePath(fileRegL), ...
            ' -out ', makeAbsolutePath(fileMapStandard)]);
    
    % Nonlinear version?
    else
        %out('Attempting nonlinear transform back into standard space...');
        tryFsl(['applywarp -i ', makeAbsolutePath([fileMap, '.nii.gz']), ...
            ' -o ', makeAbsolutePath(fileMapStandard), ...
            ' -r ', makeAbsolutePath(args.fileStandardBrain) ...
            ' -w ', makeAbsolutePath(fileRegNL), ...
            ' --premat=', makeAbsolutePath(fileRegL)]);
    end
    
end
