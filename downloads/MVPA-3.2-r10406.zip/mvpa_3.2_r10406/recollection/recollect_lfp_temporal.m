% Recollection function for temporal LFP analyses. Allows you to overlay
% the raw signal or a signal contrast.
% 
% (See 'recollect_wrapper' interface.)
%
% Example:
%     recollectResults('~/studies/elec/results/mvpa/analysis55/settings55.mat',
%     'recollect_func', @recollect_lfp_temporal)
%
% Additional named arguments:
%     stimulusOnset: if given, a vertical stimulus line will be drawn
%     xEnd: if given, sets the right end of the x axis (in ms)
%     forPublication: true or false, determines font sizes etc.
%     overlayTransparency: 0 (invisible) ... 1 (opaque)

% Kay H. Brodersen, ETHZ/UZH
% $Id: recollect_lfp_temporal.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_lfp_temporal(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults.stimulusOnset = [];
    defaults.xEnd = [];
    defaults.forPublication = false;
    defaults.overlayTransparency = 0.1;
    args = propval(recollect_args, defaults);
    args = propval(varargin, args, 'strict', false);
    
    % One after another or averaged?
    if length(iScans)>1
        out(['You can display different scans one after another or as an average.']);
        out(['    1 - one after another']);
        out(['    2 - averaged']);
        dispMode = inputout(['Display mode: ']);
        
        if dispMode == 1
            dispRuns = length(iScans);
        else
            dispRuns = 1;
        end
    else
        dispRuns = 1;
    end
    
    % Make figure
    figure; hold on;
    
    % Go through all display runs, and remember the choices made during the
    % first run for all subsequent runs
    mem = [];
    iScans_global = iScans;
    for iDisp = 1:dispRuns
        if dispRuns > 1
            iScans = iScans_global(iDisp);
            out(' ');
            out(' ');
            out(['DISPLAY RUN ', num2str(iDisp), '/', num2str(dispRuns), ...
                ' for scan ', allScans{iScans}]);
            out(' ');
        else
            iScans = iScans_global;
        end
        
        % Make subplot
        rows = round(sqrt(length(iScans_global)));
        cols = ceil(length(iScans_global)/rows);
        %subplot(floor((iDisp-1)/cols)+1, mod(iDisp-1,cols)+1, iDisp);
        subplot(rows, cols, iDisp);
        hold on;
        
        % Load raw results matrices (SCANS x CYCLES x TRIALS).
        [D,G,V] = loadRawResults(settings, allScans, iScans);
        
        % Compute accuracies
        [A,B] = computeAccuracies(D,G);
        
        
        % -----------------------------------------------------------------
        % Plot accuracies over time
        % -----------------------------------------------------------------
        
        % Make scans string
        strScans = '';
        if length(iScans)>1 || dispRuns>1
            strScans = num2str(iScans);
        else
            for s = iScans
                strScans = [strScans, allScans{s}, ' '];
            end
            strScans = strScans(1:end-1);
        end
        
        % Load any arbitary dataset simply to obtain sampling rate (for the
        % x-axis)
        dfD_file = makeAbsolutePath(fullfile(getScanDir(settings.dirData, allScans{iScans(1)}), settings.fileDataTrain));
        dfD = spm_eeg_load(dfD_file);
        t = dfD.time(settings.cycles)*1000;
        if ~isempty(args.stimulusOnset)
            t = t - args.stimulusOnset;
        end
        
        % Indicate stimulus onset line?
        if ~isempty(args.stimulusOnset)
            plot([0, 0], [0 1], '-', 'color', [0.8 0 0], 'linewidth', 2);
        end
        
        % Plot accuracies vs. cycles (across scans)
        % - draw values
        %bar(t, nanmean(B,1), 'facecolor', [0 0 0], 'edgecolor', [0.3 0.3 0.3], 'BarWidth', 0.8);
        %plot(t, nanmean(B,1), '-w', 'linewidth', 4);
        plot(t, nanmean(B,1), '-k', 'linewidth', 2);
        % - adjust axes
        axis tight;
        v = axis;
        v(3:4) = [0 1];
        % - draw chance bar
        alpha = 0.05;
        loadLabels_func_actual = str2func(func2str(settings.loadLabels_func));
        nClasses = loadLabels_func_actual();
        [pChance, pSig] = whatIsChance(nClasses, size(D,1)*size(D,3), alpha/2);
        line([-10000 10000], [pChance pChance], 'Color', [1 1 1], 'LineWidth', 2);
        % - draw significance bars
        %line([min(t) max(t)], [pSig pSig], 'Color', [0.5 0.5 0.5], 'LineWidth', 2);
        plotfill([-10000 10000], repmat(2*pChance-pSig,1,2), repmat(pSig,1,2), ...
            'color', [0.5 0.5 0.5], 'edgecolor', [1 1 1], 'edgeTransparency', 1);
        % - finalise
        axis(v);
        title(['Analysis ', num2str(settings.analysisId), ...
            ' - Mean accuracies (scans ', strScans, ')'], ...
            'interpreter', 'none');
        if isempty(args.stimulusOnset)
            xlabel('Time [ms]');
        else
            xlabel('Peristimulus time [ms]');
        end
        ylabel('Classification accuracy');
        set(gca, 'Box', 'on');
        
        % Set right end of x axis?
        if ~isempty(args.xEnd) && args.xEnd>0
            v = axis;
            v(2) = args.xEnd;
            axis(v);
        end
        
        % -----------------------------------------------------------------
        % Overlay raw signal [optional]
        % -----------------------------------------------------------------
        
        % Overlay raw signal?
        if length(iScans)==1
            s = iScans;
            out(' ');
            out(['Do you want to overlay the signal from ''', allScans{s}, ''' onto the accuracy plot?']);
            out('Hit Enter to continue, or Ctrl+C to abort');
            
            % Load chosen data file
            dfD_file = makeAbsolutePath(fullfile(getScanDir(settings.dirData, allScans{s}), settings.fileDataTrain));
            dfD = spm_eeg_load(dfD_file);
            
            % Load labels
            dirScan = fullfile(settings.dirScans, allScans{s});
            loadLabels_func_actual = str2func(func2str(settings.loadLabels_func));
            labels = loadLabels_func_actual(dirScan, settings.loadLabels_args);
            
            % Mean signals from all classes or signal contrast (difference
            % between two classes)?
            out(' ');
            out(['Do you want to overaly raw signals or a signal contrast?']);
            out(['    1 - raw signals']);
            out(['    2 - signal contrast (difference)']);
            try
                type = mem.type;
            catch
                type = inputout(['Choose a type: ']);
                mem.type = type;
            end
            assert(type==1 || type==2);
            
            % Choose channels
            out(' ');
            out(['Which channels do you want to include?']);
            out(['    There are ', num2str(dfD.nchannels), ' channels']);
            out(['    You can enter a single number of a vector of numbers.']);
            try
                chs = mem.chs;
            catch
                chs = inputout('Channels (Enter to select all channels): ');
                mem.chs = chs;
            end
            if isempty(chs), chs = 1:dfD.nchannels; end
            assert(containsOnly(chs, [1:dfD.nchannels]));
            
            % Get data (data_mean and data_sem)
            data = dfD(:,:,:);
            data1 = data(chs,:,labels==1);
            data2 = data(chs,:,labels==2);
            % - type 1: raw signals
            if type==1
                data_mean = mean(data1,3);
                data_mean(:,:,end+1) = mean(data2,3);
                data_se = std(data1,0,3)/sqrt(size(data1,3));
                data_se(:,:,end+1) = std(data2,0,3)/sqrt(size(data2,3));
            % - type 2: contrast (difference)
            elseif type==2
                data_mean = mean(data2,3) - mean(data1,3); % deviants - standards
                data_se = sqrt(var(data1,0,3)/size(data1,3) + var(data2,0,3)/size(data2,3));
                out(' ');
                out(['Do you want to display the contrast data on an upside-down y scale?']);
                try
                    upsidedown = mem.upsidedown;
                catch
                    upsidedown = inputout('Upside-down y scale? ');
                    mem.upsidedown = upsidedown;
                end
                if upsidedown
                    data_mean = -data_mean;
                end
            end
            data_mean = data_mean(:,settings.cycles,:);
            data_se = data_se(:,settings.cycles,:);
            
            % Output min and max of the raw data (before transforming it)
            out(' ');
            out(['Min and max of the raw data']);
            out(['   Min: ', num2str(min(min(data_mean,[],2)))]);
            out(['   Max: ', num2str(max(max(data_mean,[],2)))]);
            
            % Scale and shift data to fit display
            % - shift data down to mean zero
            for cond = 1:size(data_mean,3)
                for r = 1:size(data_mean,1)
                    data_mean(r,:,cond) = data_mean(r,:,cond)-data_mean(r,1,cond);
                end
            end
            % - scale data so that its max is no greater than 0.5 and its min
            %   is no less than -0.5
            if max(max(max(data_mean+2*data_se))) > -min(min(min(data_mean-2*data_se)))
                k = max(max(max(data_mean+2*data_se)));
                data_mean = data_mean / k / 2;
                data_se = data_se / k / 2;
            else
                k = -min(min(min(data_mean-2*data_se)));
                data_mean = data_mean / k / 2;
                data_se = data_se / k / 2;
            end
            % - shift data so that its mean is 0.5 (instead of 0)
            data_mean = data_mean + 0.5;
            
            % Plot
            if type==1
                assert(size(data_mean,3)==2);
                assert(size(data_se,3)==2);
                cols = [0.2 0.2 0.8; 0.8 0.2 0.2];
                for cond = 1:2
                    for r = 1:size(data_mean,1)
                        col = cols(cond,:);
                        plot(t, data_mean(r,:,cond), '-', 'color', col, 'linewidth', 2);
                        plotfill(t, data_mean(r,:,cond)-2*data_se(r,:,cond), ...
                            data_mean(r,:,cond)+2*data_se(r,:,cond), ...
                            'color', col, 'transparency', args.overlayTransparency);
                    end % r
                end % cond
                
            elseif type==2
                assert(size(data_mean,3)==1);
                assert(size(data_se,3)==1);
                for r = 1:size(data_mean,1)
                    cols = colormap;
                    for r = 1:size(data_mean,1)
                        col = cols(mod(r*10,size(cols,1))+1,:);
                        %plot(t, data_mean(r,:), '-', 'color', col, 'linewidth', 2);
                        plotfill(t, data_mean(r,:,cond)-2*data_se(r,:,cond), ...
                            data_mean(r,:,cond)+2*data_se(r,:,cond), ...
                            'color', col, 'transparency', args.overlayTransparency);
                    end
                end
            end
            v = axis;
            v(3:4)=[0 1];
            axis(v);
            
            % Amend title
            if type==1
                tmpStr = 'average signals';
            elseif type==2
                tmpStr = 'signal difference';
            end
            tmpStr = [tmpStr, ' (ch ', num2str(chs), ')'];
            ti = get(gca, 'title');
            tc = get(ti, 'String');
            tmpStr = [tc, ' & overlay: ', tmpStr];
            set(ti, 'String', tmpStr);
        end
    
        % Set right end of x axis?
        if ~isempty(args.xEnd) && args.xEnd>0
            v = axis;
            v(2) = args.xEnd;
            axis(v);
        end
        
        % Plot accuracies again so that they're on top
        plot(t, nanmean(B,1), '-k', 'linewidth', 2);
        
    end % display run
end
