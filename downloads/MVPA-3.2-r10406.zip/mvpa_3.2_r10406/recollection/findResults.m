% Finds results for recollection.
%
% Usage:
%     [allScans, idxScans] = findResults(settings, file, checkOnly)
%
% Arguments:
%     settings - settings struct loaded from disk
%     fileRunning - file whose presence indicates an analysis is
%         still running or failed
%     fileCompleted - file whose presence indicates an analysis is
%         complete
%     checkOnly - if true, will list found subjects; if false, won't
% 
% Return values:
%     allScans - names of all existing scan directories
%     idxScans - indices of completed scans

% Kay H. Brodersen, University of Oxford / ETZH / UZH
% $Id: findResults.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [allScans, idxScans] = findResults(settings, fileRunning, fileCompleted, checkOnly)
    
    % Go through all scans
    allScans = locateScans(fullfile(settings.dirAnalysis, settings.dirScansFilter));
    nAllScans = length(allScans);
    idxScans = [];
    nExpected = nAllScans;
    
    % Go through all instances
    if isfield(settings, 'nInstances')
        nInstances = settings.nInstances;
        assert(nInstances>=1);
    else
        nInstances = 1;
    end
    
    for s = 1:nAllScans
        
        % Try and find all instance files
        tmpFound = true;
        for i = 1:nInstances
            % Try and find 'completed' instance file
            if ~exist(fullfile(settings.dirAnalysis, allScans{s}, ...
                    [fileCompleted, '_i', num2str(i)]), 'file')
                tmpFound = false;
                break;
            end
        end % i
        
        % If not found, try legacy files
        if ~tmpFound
            try
                if exist(fullfile(settings.dirAnalysis, allScans{s}, ...
                        fileCompleted), 'file')
                    tmpFound = true;
                end
            end                
        end
        if ~tmpFound
            try
                if exist(fullfile(getScanDir(settings.dirOut, allScans{s}), ...
                    ['.completed_a', num2str(settings.analysisId)]), 'file')
                    tmpFound = true;
                end
            end
        end
        
        % If found, good
        if tmpFound
            idxScans = [idxScans, s];
            
        % If not found, check whether it never ran in the first place
        else
            neverRan = true;
            for i = nInstances
                if exist(fullfile(settings.dirAnalysis, allScans{s}, [fileRunning, '_i', num2str(i)]))
                    neverRan = false;
                    break;
                end
            end
            if exist(fullfile(settings.dirAnalysis, allScans{s}, fileRunning), 'file')
                neverRan = false;
            end
            if neverRan
                nExpected = nExpected - 1;
            end
        end
    end % s
    
    % Show which ones were found
    nScans = length(idxScans);
    out(' ');
    out(['Available scans ...........: ', num2str(nAllScans)]);
    out(['Completed analyses ........: ', num2str(nScans)]);
    out(['Still running or failed ...: ', num2str(nExpected-length(idxScans))]);
    
    if checkOnly
        % If found fewer than expected, list the ones that were found
        if (nScans < nExpected)
            for s=1:nAllScans
                thisFile = fullfile(settings.dirAnalysis, allScans{s}, file);
                if exist(thisFile, 'file')
                    out([num2str(s), ': ', thisFile]);
                else
                    out([num2str(s), ': ', fullfile(settings.dirAnalysis, allScans{s}) ]);
                end
            end
        end
        return;
    end
    
    % If no completed scans
    if nScans == 0
        try error(' '); catch;
            out(' ');
            out('No results found.');
        end
    elseif nScans < nExpected
        out(' ');
        out(['Only ', num2str(nScans), ' out of ', num2str(nExpected), ' expected results found.']);
        %input('Continue? ');
    end
end
