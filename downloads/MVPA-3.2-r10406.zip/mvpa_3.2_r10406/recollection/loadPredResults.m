% Load raw prediction results stored in a 'pred' file.
% 
% Usage:
%     [T,P,V,I,S] = loadPredResults(settings, allScans, iScans)
%     [T,P,V,I,S] = loadPredResults(settings, allScans, iScans, verbose)
%
% Arguments:
%     settings - settings struct loaded from disk
%     allScans - cell array of scan names
%     iScans - scans to be loaded
%     verbose - whether to print unnecessary details about the loading
%         process (default: true)
% 
% Return values:
%     T: targets
%     P: predictions
%     V: decision values (if present)
%     I: test trial indices
%     - These return values are SCANS x CYCLES x TRIALS matrices.
%     
%     S: scratch structs reflecting the model (if present)
%     - This return value is a SCANS x CYCLES cell array.

% Kay H. Brodersen, ETHZ/UZH
% $Id: loadPredResults.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [T,P,V,I,S] = loadPredResults(settings, allScans, iScans, verbose)
    
    % Check inputs
    try; verbose; catch; verbose = true; end
    
    % Initialize
    T = NaN(length(iScans), length(settings.cycles), 1);
    P = NaN(length(iScans), length(settings.cycles), 1);
    V = NaN(length(iScans), length(settings.cycles), 1);
    I = NaN(length(iScans), length(settings.cycles), 1);
    S = cell(length(iScans), length(settings.cycles), 1);
    
    % Init warnings
    nWarnings = 0;
    
    % Go through all SCANS
    for s = 1:length(iScans)
        iScan = iScans(s);
        
        % Go through all CYCLES
        for cy = 1:length(settings.cycles)
            progress(cy,length(settings.cycles));
            %disp([num2str(cy), '/', num2str(length(settings.cycles))]);
            
            iCycle = settings.cycles(cy);
            
            % Get filename of results file
            try fileOut = settings.main.fileOut; assert(~isempty(fileOut)); catch; fileOut = 'pred'; end
            thisFile = fullfile(settings.dirAnalysis, allScans{iScan}, ...
                [fileOut, num2str(settings.analysisId), ...
                '_cy', num2str(iCycle), '.mat']);
            
            % Load file
            thisResult = [];
            try thisResult = diveIntoStruct(load(thisFile)); end
            
            % Ignore if not found
            if isempty(thisResult) ...
                || (isfield(thisResult, 'cancelled') && thisResult.cancelled) ...
                || (isfield(thisResult, 'cancel') && thisResult.cancel)
                nWarnings = nWarnings + 1;
                if nWarnings <= 20
                    out(['Note: ignoring missing or cancelled ', thisFile]);
                elseif nWarnings == 21
                    out([' ']);
                    out(['Suppressing further warnings...']);
                    out([' ']);
                end
                continue;
            end
            
            % Collect data
            thisT = [];
            thisP = [];
            thisV = [];
            thisI = [];
            thisS = {};
            for i=1:size(thisResult.folds,2)
                thisT = [thisT, thisResult.folds(i).targs(:)'];
                thisP = [thisP, thisResult.folds(i).preds(:)'];
                if ~isempty(thisResult.folds(i).preds(:))
                    thisI = [thisI, thisResult.folds(i).test(:)'];
                end
                if isfield(thisResult.folds(i), 'scratch')
                    if isempty(thisS)
                        thisS = thisResult.folds(i).scratch;
                    else
                        thisS = {thisS, thisResult.folds(i).scratch}; %%% buggy
                    end
                    if isfield(thisResult.folds(i).scratch, 'dvs')
                        tmp = thisResult.folds(i).scratch.dvs(:)';
                        % UPDATE 18/04/2011 b
                        % NO MORE FLIPPING - APPARENTLY NOT NECESSARY!
                        
%                         if thisResult.folds(i).scratch.model.rho>0
%                             % UPDATED 18/04/2011
%                             % Used to be 'rho<1' but has to be 'rho>0'
%                             % since rho represents -b, i.e., (-1)*the bias
%                             % of the hyperplane.
%                             %
%                             % Hyperplane has negative bias, therefore
%                             % decision_values are 'turned round', therefore
%                             % multiply them by (-1) in order to make them
%                             % comparable to other train/test runs.
%                             tmp = -tmp;
%                         end
                        thisV = [thisV, tmp];
                    end
                end
            end
            
            % Collect globally
            diff = length(thisP) - size(P,3);
            if diff > 0
                T(:,:,end+1:end+diff) = NaN(length(iScans), length(settings.cycles), diff);
                P(:,:,end+1:end+diff) = NaN(length(iScans), length(settings.cycles), diff);
                V(:,:,end+1:end+diff) = NaN(length(iScans), length(settings.cycles), diff);
                I(:,:,end+1:end+diff) = NaN(length(iScans), length(settings.cycles), diff);
            end
            if ~isempty(thisP)
                T(s,cy,1:length(thisT)) = thisT;
                P(s,cy,1:length(thisP)) = thisP;
                V(s,cy,1:length(thisV)) = thisV;
                I(s,cy,1:length(thisI)) = thisI;
                S{s,cy} = thisS;
            end
            
        end % cycle
    end % scan
    
    % Check results
    assert(size(T,1)==length(iScans) && size(T,2)==length(settings.cycles));
    assert(size(P,1)==length(iScans) && size(P,2)==length(settings.cycles));
    assert(size(V,1)==length(iScans) && size(V,2)==length(settings.cycles));
    assert(size(I,1)==length(iScans) && size(I,2)==length(settings.cycles));
    assert(size(T,3)==size(P,3) && size(P,3)==size(V,3) && size(V,3)==size(I,3));
    
end
