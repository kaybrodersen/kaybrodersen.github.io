% Recollection function for continuous predictions.
% 
% Implements the 'recollect_wrapper' interface.
%
% Additional named arguments:
%     (none)

% Kay H. Brodersen, ETHZ/UZH
% $Id: recollect_predictions.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_predictions(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults = [];
    args = propval(recollect_args, defaults, 'strict', false);
    args = propval(varargin, args, 'strict', false);
    
    % Load raw results matrices (SCANS x CYCLES x TRIALS).
    %     T: targets
    %     P: predictions
    %     V: decision values (if present)
    [T,P,V] = loadPredResults(settings, allScans, iScans);
    
    % Show performance vs. scans (combining across cycles)
    out(' ');
    out(['Scan                                  R^2      RMSE         rho_s   p_s']);
    out(['==========================================================================']);
    for s = 1:length(iScans)
        targs = T(s,:,:); targs = targs(:);
        preds = P(s,:,:); preds = preds(:);
        [R2, RMSE, RHO_S, P_S] = analyse_residuals(targs, preds);
        %[B,BINT,R,RINT,STATS] = regress(targs, [preds, ones(length(preds),1)]);
        iScan = iScans(s);
        str1 = allScans{iScan};
        str2 = sprintf('%9.3f', R2);
        str3 = sprintf('%9.3f', RMSE);
        str4 = sprintf('%9.3f', RHO_S);
        str5 = sprintf('%9.4f', P_S);
        str6 = [' ', p2star(P_S)];
        out([str1, repmat(' ', 1, max([1,34-length(str1)])), str2, str3, '    ', str4, str5, str6]);
    end
    
    % Show accuracies vs. cycles (combining across scans)
    out(' ');
    out(['Cycle                                 R^2      RMSE         rho_s   p_s']);
    out(['==========================================================================']);
    for cy = 1:length(settings.cycles)
        targs = T(:,cy,:); targs = targs(:);
        preds = P(:,cy,:); preds = preds(:);
        [R2, RMSE, RHO_S, P_S] = analyse_residuals(targs, preds);
        iCycle = settings.cycles(cy);
        str1 = ['CY ', num2str(iCycle)];
        str2 = sprintf('%9.3f', R2);
        str3 = sprintf('%9.3f', RMSE);
        str4 = sprintf('%9.3f', RHO_S);
        str5 = sprintf('%9.4f', P_S);
        str6 = [' ', p2star(P_S)];
        out([str1, repmat(' ', 1, max([1,34-length(str1)])), str2, str3, '    ', str4, str5, str6]);
    end
    
    % Plot
    figure('Name', ['Analysis ', num2str(settings.analysisId)]); hold on;
    targs = squeeze(T);
    preds = squeeze(P);
    targs = targs(:);
    preds = preds(:);
    plot(targs, preds, '.');
    v = axis;
    v = [min([v(1) v(3)]), max([v(2) v(4)]), min([v(1) v(3)]), max([v(2) v(4)])];
    axis(v);
    axis square;
    xlabel('targs');
    ylabel('preds');
    title(['Analysis ', num2str(settings.analysisId)]);
end
