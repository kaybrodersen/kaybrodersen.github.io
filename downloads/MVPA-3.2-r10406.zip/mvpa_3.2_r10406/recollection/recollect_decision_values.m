% Recollection function that analyses decision values.
% 
% (See 'recollect_wrapper' interface.)

% Kay H. Brodersen, ETHZ/UZH
% $Id: recollect_decision_values.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function recollect_decision_values(settings, allScans, iScans, recollect_args, varargin)
    
    % Check input
    defaults = [];
    args = propval(recollect_args, defaults);
    args = propval(varargin, args, 'strict', false);
    
    % Load raw results matrices (SCANS x CYCLES x TRIALS).
    [D,G,DV] = loadRawResults(settings, allScans, iScans);
    
    % Get all decision values
    allDesireds = D(:);
    allGuesses = G(:);
    allDecisionValues = DV(:);
    
    % Construct ROC curve
    input('Compute ROC curve?');
    [x,y] = computeRocCurve(allDecisionValues, allGuesses==allDesireds);
    
    % Plot ROC curve
    subplot(2,1,2); hold on;
    plot(x,y,'.-');
    plot([0 0], [0 max(y)], '-k');
    falses=sum(allGuesses~=allDesireds);
    plot([min(x), max(x)], [0.5 0.5], '-k');
    axis tight;
    set(gca, 'Box', 'on');
    xlabel('decision value');
    ylabel('cumulative number of false guesses');
    title(['ROC (subjects', tmpSubjects, ')']);
    
end
