% P value of the Null hypothesis that the accuracy is not significantly
% above chance (i.e., the area under the pdf below 0.5). This P value could
% then be compared to 0.05 or 0.025.
%
% Usage:
%     a_p = acc_p(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_p.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function a_p = acc_p(C)
    
    % Get alpha and beta
    A = C(1,1) + C(2,2) + 1;
    B = C(1,2) + C(2,1) + 1;
    
    % Compute area under pdf below 0.5
    a_p = betacdf(0.5,A,B);
    
end
