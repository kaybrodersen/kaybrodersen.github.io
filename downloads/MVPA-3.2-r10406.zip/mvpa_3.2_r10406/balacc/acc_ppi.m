% Posterior probability interval of the accuracy.
% 
% Usage:
%     [a_lower,a_upper] = acc_ppi(C,alpha)
% 
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes
%     alpha - The posterior probability interval will cover 1-alpha of
%         probability mass such that (1-alpha)/2 remains on either end of
%         the distribution.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_ppi.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [a_lower,a_upper] = acc_ppi(C,alpha)
    
    A = C(1,1)+C(2,2) + 1;
    B = C(1,2)+C(2,1) + 1;
    
    a_lower = betainv(alpha/2,A,B);
    a_upper = betainv(1-alpha/2,A,B);
    
end
