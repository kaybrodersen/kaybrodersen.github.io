% Inverse CDF of the sum of two independent random variables which are
% distributed according to Beta distributions.
%
% If the optimization fails, function returns NaN.
% 
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: betaavginv.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function x = betaavginv(y, alpha1, beta1, alpha2, beta2)
    
    try
        x = fzero(@(z) betaavgcdf(z,alpha1,beta1,alpha2,beta2)-y, 0.5);
    catch
        disp(['Error occurred in BETAAVGINV']);
        x = NaN;
    end
    
end
