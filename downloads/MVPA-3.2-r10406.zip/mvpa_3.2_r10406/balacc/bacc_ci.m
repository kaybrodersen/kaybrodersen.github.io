% Deprecated - use bacc_ppi instead.

% $Id: bacc_ci.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [b_lower,b_upper] = bacc_ci(C,alpha)
    
    warning('The use of bacc_ci is deprecated - use bacc_ppi instead');
    [b_lower,b_upper] = bacc_ppi(C,alpha);
    
end
