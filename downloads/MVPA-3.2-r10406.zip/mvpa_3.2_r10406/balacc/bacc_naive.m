% Naive balanced accuracy (simply the mean of the individual accuracies,
% i.e., the mean of the accuracy modes).
%
% Usage:
%     b = bacc_naive(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes. This matrix
%         needs to be of the form C = [a b; c d] where
%         <a> is the number of true positives
%         <b> is the number of false negatives
%         <c> is the number of false positives
%         <d> is the number of true negatives
%         In other words: rows are true classes, columns are estimated
%         classes.
% 
% If C is all zero, the returned accuracy will be NaN.
% 
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: bacc_naive.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function b = bacc_naive(C)
    
    assert(all(size(C)==2), 'confusion matrix must be 2 x 2');
    b = nansum([C(1,1)/sum(C(1,:)), C(2,2)/sum(C(2,:))]) / ((sum(C(1,:))~=0) + (sum(C(2,:))~=0));
    
end
