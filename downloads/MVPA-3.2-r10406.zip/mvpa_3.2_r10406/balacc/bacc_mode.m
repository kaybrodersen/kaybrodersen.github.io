% Most likely balanced accuracy (i.e., the mode of the average of
% two random variables that are independently distributed according to Beta
% distributions.)
%
% Note that this is NOT simply the mean of the modes of the individual
% accuracies as I thought earlier! See bacc_naive.m for this measure.
%
% Usage:
%     b = bacc_mode(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes. This matrix
%         needs to be of the form C = [a b; c d] where
%         <a> is the number of true positives
%         <b> is the number of false negatives
%         <c> is the number of false positives
%         <d> is the number of true negatives
%         In other words: rows are true classes, columns are estimated
%         classes.
%
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: bacc_mode.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function b = bacc_mode(C)
    
    A1 = C(1,1) + 1;
    B1 = C(1,2) + 1;
    A2 = C(2,2) + 1;
    B2 = C(2,1) + 1;
    
    b0 = bacc_mean(C); % start search at mean
    b = fminsearch(@(x) -betaavgpdf(x,A1,B1,A2,B2), b0);
    
end
