% Naive standard-error-of-the-mean of the across-test-cases mean accuracy.
% To plot an interval, plot [a - 2*a_sem, a + 2*a_sem].
%
% It is 'naive' because it can include values above 1. The function acc_ppi
% should be used instead.
%
% Usage:
%     a_sem = acc_sem(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_sem.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function a_sem = acc_sem(C)
    
    % Assume l-o-o cross-validation
    corrects = [ones(1,C(1,1)+C(2,2)), zeros(1,C(1,2)+C(2,1))];
    assert(sum(corrects)==C(1,1)+C(2,2));
    assert(length(corrects)==sum(sum(C)));
    
    % Compute sem
    a_sem = std(corrects) / sqrt(length(corrects));
    
end
