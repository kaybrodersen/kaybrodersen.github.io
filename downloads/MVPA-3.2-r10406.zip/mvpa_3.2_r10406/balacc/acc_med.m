% Median of the accuracy (i.e., the median of a Beta distribution).
%
% Usage:
%     a_med = acc_med(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: acc_med.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function a_med = acc_med(C)
    
    % Get alpha and beta
    A = C(1,1) + C(2,2) + 1;
    B = C(1,2) + C(2,1) + 1;
    
    % Compute median
    a_med = betainv(0.5, A, B);
    
end
