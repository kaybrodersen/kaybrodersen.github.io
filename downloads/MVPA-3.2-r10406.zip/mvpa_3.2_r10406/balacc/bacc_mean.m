% Expected value of the balanced accuracy (i.e., the mean of the average of
% two random variables that are independently distributed according to Beta
% distributions.)
%
% Usage:
%     b = bacc_mean(C)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes. This matrix
%         needs to be of the form C = [a b; c d] where
%         <a> is the number of true positives
%         <b> is the number of false negatives
%         <c> is the number of false positives
%         <d> is the number of true negatives
%         In other words: rows are true classes, columns are estimated
%         classes.
% 
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: bacc_mean.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function b = bacc_mean(C)
    
    A1 = C(1,1) + 1;
    B1 = C(1,2) + 1;
    A2 = C(2,2) + 1;
    B2 = C(2,1) + 1;
    
    res = 0.001;
    x = 0:res:2;
    c = betaconv(res, A1, B1, A2, B2);
    b = sum(x.*c/2) * res;
    
end
