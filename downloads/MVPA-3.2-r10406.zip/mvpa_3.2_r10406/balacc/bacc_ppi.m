% Posterior probability interval of the balanced accuracy.
%
% Usage:
%     [b_lower,b_upper] = bacc_ppi(C,alpha)
%
% Arguments:
%     C - 2x2 confusion matrix of classification outcomes. This matrix
%         needs to be of the form C = [a b; c d] where
%         <a> is the number of true positives
%         <b> is the number of false negatives
%         <c> is the number of false positives
%         <d> is the number of true negatives
%         In other words: rows are true classes, columns are estimated
%         classes.
%     alpha - The posterior probability interval will cover 1-alpha of
%         probability mass such that (1-alpha)/2 remains on either end of
%         the distribution.
% 
% Example:
%     C = [90, 10; 5 95];
%     alpha = 0.05;
%     [b_lower,b_upper] = bacc_ci(C,alpha);
% 
% Literature:
%     K.H. Brodersen, C.S. Ong, K.E. Stephan, J.M. Buhmann (2010).
%     The balanced accuracy and its posterior distribution. In: Proceedings
%     of the 20th International Conference on Pattern Recognition.

% Kay H. Brodersen, ETH Zurich, Switzerland
% http://people.inf.ethz.ch/bkay/
% $Id: bacc_ppi.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [b_lower,b_upper] = bacc_ppi(C,alpha)
    
    A1 = C(1,1) + 1;
    B1 = C(1,2) + 1;
    A2 = C(2,2) + 1;
    B2 = C(2,1) + 1;
    
    b_lower = betaavginv(alpha/2,A1,B1,A2,B2);
    b_upper = betaavginv(1-alpha/2,A1,B1,A2,B2);
    
end
