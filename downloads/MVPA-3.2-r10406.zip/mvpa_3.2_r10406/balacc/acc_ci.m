% Deprected - use acc_ppi instead.

% $Id: acc_ci.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [a_lower,a_upper] = acc_ci(C,alpha)
    
    warning('The use of acc_ci is deprecated - use acc_ppi instead');
    [a_lower,a_upper] = acc_ppi(C,alpha);
    
end
