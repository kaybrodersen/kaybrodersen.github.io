% Generates a 'NTRIALS x H trials-phases' design matrix, estimates beta
% values, z values, and BF values (basis functions) per voxel, and stores
% them for each subject. Depending on options, these files are called:
%     {B|z|BF}_{filtered|cleaned}[_orth][_mc][_nr].nii.gz
%
% Usage:
%     makeParameterVolumes(fileSettings)
%
% Arguments:
%     fileSettings - settings filename
%     idxScans (optional) - vector of scan indices to process; if omitted,
%         will process all scans

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: createParameterVolume.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function createParameterVolume(fileSettings, idxScans)
    
    % Load settings
    settings = loadSettings(fileSettings, false, true, true);
    conf = settings.parvol;
    
    % Set up FSL
    global FSL_COMMAND_PREFIX;
    try FSL_COMMAND_PREFIX = settings.fslCommandPrefix;
    catch; FSL_COMMAND_PREFIX = 'LD_LIBRARY_PATH=/usr/lib/fsl; '; end
    
    % Check settings
    if ~exist('idxScans', 'var')
        idxScans = [];
    end
    
    % Set output suffix
    if ~iscell(conf.filesAdditionalRegressors)
        conf.filesAdditionalRegressors = {conf.filesAdditionalRegresors};
    end
    for i=1:length(conf.filesAdditionalRegressors)
        conf.outSuffix = [conf.outSuffix, '_', conf.suffixesAdditionalRegressors{i}];
    end
    
    % Go through all scans
    scans = dir(fullfile(conf.dirScans, conf.dirScansFilter));
    if isempty(idxScans)
        idxScans = 1:length(scans);
    end
    disp(['Found ', num2str(length(idxScans)), ' scans']);
    for s = idxScans
        scan = scans(s).name;
        
        % Get scan-specific variables
        dirScan = fullfile(conf.dirScans, scan);
        dirOut = getScanDir(conf.dirOut, scan);
        fileFuncData = getScanDir(conf.fileFuncData, scan);
        fileWholeBrainMask = getScanDir(conf.fileWholeBrainMask, scan);
        
        disp('-------------------------------------------------------------');
	    disp(['Scan ', num2str(s), '/', num2str(length(scans)), ': ', dirScan]);
        
        % Check presence of files
        if ~exist(dirScan, 'dir'), error([dirScan, ' not found']), end;
        if ~exist(dirOut, 'dir')
            disp(['Creating output directory: ', dirOut]);
            mkdir(dirOut);
        end
        if ~exist(fileFuncData, 'file'), error([fileFuncData, ' not found']), end;
        if ~exist(fileWholeBrainMask, 'file'), error([fileWholeBrainMask, ' not found']), end;
        if ~exist(conf.fileHrfBasisFunctions, 'file'), error([conf.fileHrfBasisFunctions, ' not found']), end;
        
        % Generate raw design matrix
        [X, X_BF, conf.rawDesignMatrixCols] = generateDesignMatrix(conf, scan); % ~VOLUMES x 360 (X)  and x 1080 (X_BF)
        
        % Orthognoalize? (monitor w.r.t. decide)
        if false
            disp('    Orthogonalization: assigning shared variance to ''mon''...');
            if size(X,2) ~= 361
                error('not implemented yet for design matrices with more than 361 EVs');
            end
            for dec = [1:2:360]
                mon = dec + 1;
                X(:,dec) = X(:,dec) - ( (X(:,dec)'*X(:,mon)) / (X(:,mon)'*X(:,mon)) ) * X(:,mon);
            end
        end
        
        % Add additional regressors?
        for a = 1:length(conf.filesAdditionalRegressors)
            thisFile = getScanDir(conf.filesAdditionalRegressors{a}, scan);
            thisSuffix = conf.suffixesAdditionalRegressors{a};
            disp(['    Loading additional regressor: ', thisFile]);
            thisReg = load(thisFile);
            disp(['        has ', num2str(size(thisReg,2)), ' columns']);
            %demean(thisReg,1);
            X = addToX(X, thisReg);
            X_BF = addToX(X_BF, thisReg);
            disp(['        successfully added with suffix ''', thisSuffix, '''']);
        end
        
        % Visualize design matrix
        figure;
        imagesc(X);
        title('Convolved design matrix');
        
        % Estimate betas
        [B, z, BF] = estimateParameters(fileFuncData, fileWholeBrainMask, ...
            X, X_BF, conf);
        
        % Save as NIFTI files and remove NaN values
        dims = NaN(4,1);
        for d=1:4
            dims(d) = str2num(tryFsl(['fslinfo ', fileFuncData, ...
                ' | grep pixdim', num2str(d), ...
                ' | awk ''{ print $2 }''']));
        end
        disp(['    Output header dims will be: ', mat2str(dims)]);
        disp(['    Output suffix: ', conf.outSuffix]);
        saveOutputVolume(B, dirOut, ['B_', conf.outSuffix], dims);
        saveOutputVolume(z, dirOut, ['z_', conf.outSuffix], dims);
        saveOutputVolume(BF, dirOut, ['BF_', conf.outSuffix], dims);
        
        % Subject completed
        disp(['    Subject completed']);
        disp(' ');
        
    end % subject s
    
    % Go back to old directory
    disp(['Exiting MATLAB script']);
    
return;

% -------------------------------------------------------------------------
% Generates
%     X - a design matrix with 2 EVs per trial
%     X_BF - a design matrix with 6 EVs per trial
% based on a particular subject's timing data.
function [X, X_BF, rawDesignMatrixCols] = generateDesignMatrix(conf, scan)
    
    % Load main EVs
    evs = struct;
    % (as generated by makeEVs.m)
    disp(['    Loading main EVs...']);
    for e = 1:length(conf.evs)
        thisEvFile = getScanDir(conf.evs{e},scan);
        disp(['        ', thisEvFile]);
        evs(e).threecol = sortrows(load(thisEvFile),1);
    end
    disp(['    Checking main EVs...']);
    size1 = size(evs(1).threecol,1);
    size2 = size(evs(1).threecol,2);
    for e = 2:length(conf.evs)
        if size(evs(e).threecol,1) ~= size1 || size(evs(e).threecol,2) ~= size2
            error([conf.evs{e}, ' has different dimensions than ', conf.evs{1}]);
        end
    end
    
    % Remember how many main columns we will later need
    rawDesignMatrixCols = size1 * length(evs);
    disp(['    Final output will contain ', num2str(rawDesignMatrixCols), ' cols']);
    
    % Load additional EVs
    aevs = struct;
    disp(['    Loading additional EVs...']);
    if isempty(conf.aevs)
        disp('        (no additional EVs specified)');
    else
        for ae = 1:length(conf.aevs)
            thisAevFile = getScanDir(conf.aevs{ae},scan);
            disp(['        ', thisAevFile]);
            aevs(ae).threecol = load(thisAevFile);
        end
    end
    
    % Determining total length
    endtime = 0;
    for ev = 1:length(conf.evs)
        if ~isempty(evs(ev).threecol)
            endtime = max(endtime, evs(ev).threecol(end,1) + evs(ev).threecol(end,2));
        end
    end
    for aev = 1:length(conf.aevs)
        if ~isempty(aevs(aev).threecol)
            endtime = max(endtime, aevs(aev).threecol(end,1) + aevs(aev).threecol(end,2));
        end
    end
%     if isempty(conf.aevs)
%         endtime = evs(end).threecol(end,1) + evs(end).threecol(end,2);
%     else
%         endtime = max([evs(end).threecol(end,1) + evs(end).threecol(end,2), ...
%                        aevs(end).threecol(end,1) + aevs(end).threecol(end,2)]);
%     end
    disp(['    Overall end time: ', num2str(endtime/60), ' min']);
    
    % Set temporal resolution
    res = 0.1;
    
    % Create trial-by-trial EV matrix
    disp('    Creating trial-by-trial EV matrix...');
    EV = [];
    warning off;
    
    % - add main EVs
    disp(['        - adding ', num2str(length(conf.evs)), ' main EVs...']);
    for t = 1:size1 % 180
        progress(t,size1);
        for e = 1:length(conf.evs)
            % Convert 3col format into EV format
            evs(e).ev = threecol2ev(evs(e).threecol(t,1:3), res, endtime);
            % Add to overall EV matrix
            EV = [EV, evs(e).ev]; % will be e.g. 26147 x 360
        end % ev
    end % trial t
    
    % - add additional EVs
    disp(['        - adding ', num2str(length(conf.aevs)), ' additional EVs...']);
    for ae = 1:length(conf.aevs)
        if isempty(aevs(ae).threecol)
            disp(['            WARNING: ''', conf.aevs{ae}, ''' is empty and will be ignored']);
        else
            aevs(ae).aev = threecol2ev(aevs(ae).threecol(:,1:3), res, endtime);
            EV = [EV, aevs(ae).aev];
        end
    end % aev
    warning on;
    
    % Add 60sec of zero at the end
    disp('    Adding 60 s of zero at the end...');
    EV = [EV; repmat(0, 60/res, size(EV,2))];
    
    % Visualize
    figure;
    imagesc(EV);
    title('Raw design matrix');
    drawnow;
    
    % Create EV_BF matrix (6 EVs per trial)
    disp('    Preparing EV_BF matrix...');
    cols = 1:size(EV,2);
    cols = repmat(cols,1,3);
    cols = sort(cols);
    EV_BF = EV(:,cols);
    
    % Specify TR
    tmpTR = getScanDir(conf.fileTR, scan);
    disp(['    Loading TR from ', tmpTR]);
    tr = load(tmpTR);
    if tr < 1 || tr > 5
        error('invalid TR');
    end
    disp(['    Loaded TR = ', num2str(tr)]);
    
    % EV: Convolve each column with hdr function, and downsample
    disp('    Convolving each column in EV matrix with hrf...');
    X = [];
    for col = 1:size(EV,2) % eg 180 x 2 = 360
        progress(col,size(EV,2));
        % Compute convolution
        % !! NOTE: hrf_convolve seems to wrap around if convolution longer
        % than end of EV. Therefore we have made sure that EV has 60sec
        % extra at the end !!
        [x, x_highres, hrf, tmp, xtd] = hrf_convolve(EV(:,col), res, tr);
        
        % Copy into X matrix
        X(1:size(x,2),col) = x';
    end
    disp(['    Created raw design matrix X: ', mat2str(size(X))]);
    
    % EV_BF: Convolve each column with hdr function, and downsample
    disp('    Convolving each column in EV_BF matrix with hrf...');
    X_BF = [];
    basisFunctions = load(conf.fileHrfBasisFunctions, ...
        '-ascii'); % 560 sampling points x 3 basis functions
    if res~=0.1
        error('not implemented yet');
    end
    for ev = 1:size(EV_BF,2)/3  % 180 x 6 / 3 = 1080 / 3 = 360
        progress(ev,size(EV_BF,2)/3);
        % Compute convolution for each basis function
        for bf = 1:3
            % Which column are we in?
            col = (ev-1)*3 + bf;
            
            % Compute convolution
            x = EV_BF(:,col); % is in 0.1s resolution
            hrf = basisFunctions(:,bf); % is in 0.05s resolution (560 values)
            hrf = hrf(1:2:end); % is now in 0.1s resolution as well (280 values)
            hrf = [hrf; zeros(size(x,1)-size(hrf,1),1)];
            x_highres = fftconv(x,hrf);
            %x = demean(x_highres(tr/res:tr/res:end));
            x = demean(x_highres(round(tr/res):round(tr/res):end));
            
            % Copy into X_BF matrix
            X_BF(1:size(x,1),col) = x;
        end % bf
    end % col
    disp(['    Created raw design matrix X_BF: ', mat2str(size(X_BF))]);
    
return;

% -------------------------------------------------------------------------
% Estimates the parameters for two design matrices:
%    X is a design matrix with <H> EVs per trial, e.g. 361 EVs in total
%    X_BF is a design matrix with <3*H> EVs per trial, e.g. 1081 EVs in total
% Outputs:
%    B is the estimated beta values for X, one value per voxel and EV
%    z is the estimated z scores for X, one value per voxel and EV
%    BF is the estimated beta values for X_BF, one value per voxel and EV
function [B, z, BF] = estimateParameters(fileFuncData, fileWholeBrainMask, X, X_BF, conf)
    
    % Initialize parameter volumes
    B = [];
    z = [];
    BF = [];
    
    % Load volume (~ 1.3 GB)
    if ~exist(fileFuncData, 'file')
        error(['Functional data not found: ', fileFuncData]);
    end
    disp(['    Loading functional volume ''', fileFuncData, '''...']);
    Y = read_avw(fileFuncData);
    dim1 = size(Y,1); dim2 = size(Y,2); dim3 = size(Y,3); dim4 = size(Y,4);
    
    % Make Y and X have the same length
    nVols = size(X,1); % e.g., 873
    disp(['    We now have a design matrix X ', mat2str(size(X))]);
    disp(['    And a functional volume ', mat2str(size(Y))]);
    if dim4 > nVols % e.g., 878 > 873
        disp('    [yes] Cropping volume');
        disp('    [no ] Cropping X and X_BF');
        Y(:,:,:,nVols+1:end) = [];
    elseif dim4 < nVols
        disp('    [no ] Cropping volume');
        disp('    [yes] Cropping X and X_BF');
        X(dim4+1:end,:) = [];
        X_BF(dim4+1:end,:) = [];
        nVols = size(X,1);
    end
    if (size(Y,4) ~= nVols); error('invariant violated'); end;
    
    % Add a 'ones' column?
    if conf.addOnes
        disp(['    Adding a ''ones'' column to X and X_BF...']);
        X = [X, ones(size(Y,4),1)];
        X_BF = [X_BF, ones(size(Y,4),1)];
    else
        disp(['    (Not adding a ''ones'' column)']);
    end
    
    % Visualize design matrix
    figure;
    imagesc(X);
    title('Convolved design matrix');
    drawnow;
    
    % Load brain mask
    disp('    Loading whole-brain mask...');
    brain = read_avw(fileWholeBrainMask);
    disp('    Masking and reshaping functional volume...');
    Y = vols2matrix(Y, brain); % brainvoxels x 873
    Y = Y'; % 873 x brainvoxels
    
    % Estimate parameters of X
    disp('    Estimating parameters of X...');
    [cope, varcope] = ols(Y, X, [eye(size(X,2)-1), zeros(size(X,2)-1,1)]);
    disp(['    Raw cope matrix after estimation is: ', mat2str(size(cope))]);
    
    % Throw away superfluous regressors
    nThrowAway = size(cope,1) - conf.rawDesignMatrixCols;
    disp(['    Throwing away ', num2str(nThrowAway), ' superfluous regressors...']);
    cope(end-nThrowAway+1:end,:) = [];
    varcope(end-nThrowAway+1:end,:) = [];
    disp(['    The resulting cope matrix is: ', mat2str(size(cope))]);
    
    %beta = pinv(X) * Y;
    if false
        disp('    Computing correlations...');
        bmat = cope'; % brainvoxels x 360 EVs
        ccb=corrcoef(bmat);
        close all;
        f = figure;
        imagesc(ccb);
        colorbar;
        saveas(f, [dirScan, '/fig1.fig']);
        disp('    Saved figure 1');
        ccbd=corrcoef(bmat(1:2:end,1:2:end));
        ccbm=corrcoef(bmat(2:2:end,2:2:end));    
        f = figure;
        imagesc(ccbd);
        saveas(f, [dirScan, '/fig2.fig']);
        disp('    Saved figure 2');
        f = figure;
        imagesc(ccbm)
        saveas(f, [dirScan, '/fig3.fig']);
        disp('    Saved figure 3');
        %keyboard;
    end
    
    % Estimate parameters of X_BF
    disp('    Estimating parameters of X_BF...');
    [cope_BF, varcope_BF] = ols(Y, X_BF, [eye(size(X_BF,2)-1), zeros(size(X_BF,2)-1,1)]);
    
    % Throw away superfluous regressors
    nThrowAway = size(X_BF,2) - 1 - conf.rawDesignMatrixCols*3;
    disp(['    Throwing away ', num2str(nThrowAway), ' superfluous regressors...']);
    cope_BF(end-nThrowAway+1:end,:) = [];
    varcope_BF(end-nThrowAway+1:end,:) = [];
    disp(['    The resulting cope_BF matrix is: ', mat2str(size(cope_BF))]);
    
    % Make B, z, and BF
    disp('    Making B, z, and BF...');
    B = matrix2vols(cope', brain); % 64 x 64 x 45 x 360
    z = cope ./ varcope;
    z = matrix2vols(z', brain);
    BF = matrix2vols(cope_BF', brain); % 64 x 64 x 45 x 1080
    
return;

% -------------------------------------------------------------------------
% Adds additional columns to a given design matrix X
% where X is NVOLS x NREGS
% 
% Optional argument:
%     doNotTouchX [default: false]: if true, the design matrix will not be
%     changed in length; in case of a discprenacy it will always be the
%     regressor that is padded or cropped.
function X = addToX(X, NEW, doNotTouchX)

    if ~exist('doNotTouchX', 'var')
        doNotTouchX =false;
    end
    
    if size(NEW,1) < size(X,1)
        if ~doNotTouchX
            % Cut off X
            disp(['        NOTE! Cutting off ', num2str(size(X,1)-size(NEW,1)), ' zero rows from design matrix...']);
            X(size(NEW,1)+1:end,:) = [];
        else
            % Pad regressor
            disp(['        Padding regressor with ', num2str(size(X,1)-size(NEW,1)), ' zero rows...']);
            NEW = [NEW; zeros(size(X,1)-size(NEW,1),size(NEW,2))];
        end
    elseif size(NEW,1) > size(X,1)
        if ~doNotTouchX
            % Pad X
            disp(['        WARNING! Padding design matrix with ', num2str(size(NEW,1)-size(X,1)), ' zero rows...']);
            X = [X; repmat(0, size(NEW,1)-size(X,1), size(X,2))];
        else
            % Cut off regressor
            disp(['        WARNING! Cutting off ', num2str(size(NEW,1)-size(X,1)), ' rows from regressor...']);
            NEW(size(X,1)+1:end,:) = [];
        end
    end
    
    % Add
    X = [X, NEW];

return;

% -------------------------------------------------------------------------
% dims: e.g., [3 3 3 3]
function saveOutputVolume(Vol, dirOut, strFile, dims)
    
    % Check input
    dims = dims(:)';
    if length(dims) ~= 4
        error('dims must be a vector length 4');
    end
    
    % Set full filename
    tmpFilename = fullfile(dirOut, strFile);
    
    % Save volume
    disp(['    Saving parameter volume ', strFile, ...
        ' ', mat2str(size(Vol)), ...
        ' in ', dirOut, ' ...']);
    save_avw(Vol, tmpFilename, 'f', dims);
    
    % Use fslmaths to remove NaNs
    disp('    Removing NaNs...');
    tryFsl(['fslmaths ', tmpFilename, ' -nan ', tmpFilename]);

return;
