% Reorders trials, to overcome problems when classes are too orderly.
%
% Implements the 'processFeatures_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [data, labels] = reorderTrials(data, labels, args)
    
    nTrials = size(data,2);
    newOrder = shuffle(1:nTrials);
    data = data(:,newOrder);
    labels = labels(newOrder);
    
end
