% Wrapper function for feature preprocessing that can be used when SUBJ
% contains one 'mat_train' and optionally also one 'mat_test' matrix.
% Alternatively, SUBJ can be a Princeton struct.
% 
% Allows for several preprocessing functions to be invoked in series.
% Preprocessing functions...
% 
% - ARE GIVEN 'data' and 'labels'
% - MAY modify the data
% - MAY modify the number of features
% - MAY increase (but not decrease) the number of examples
% - MAY set a label to NaN (i.e., if an example in train or test or both is
%   considered bad, its label can be set to NaN to be ignored overall)
% - MUST ensure that data and labels contain the same number of labels upon
%   exit
% 
% The struct processFeatures_args will simply be passed to all functions.
% Make sure that preprocessing functions do not use the same argument
% names.
%
% Callee interface:
%     [mat, labels] = processFeatures_func(mat, labels, processFeatures_args)
% 
%     mat: FEATURES x EXAMPLES
%     labels: 1 x EXAMPLES
% 
% Additional named arguments processed by processFeatures_wrapper:
%     'paired_data' (default: true) When given two dataets (data_train
%         and data_test), this option specifies whether the two should be
%         treated as paired (i.e., the same number of trials, just
%         different data) or not paired (i.e., the two datasets may have
%         different numbers of trials). Note that the number of features
%         should be the same in all cases.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function subj = processFeatures_wrapper(subj, ...
    processFeatures_func, processFeatures_args, varargin)
	
    % Set defaults
    defaults.paired_data = true;
    args = propval(varargin, defaults);
    
    % Check input
    out(' ');
    if ~isempty(processFeatures_func)
        if ~iscell(processFeatures_func)
            processFeatures_func = {processFeatures_func};
        end
    else
        out('(No feature processing)');
        return;
    end
    
    % Get data
    mat_train = [];
    mat_test = [];
    try mat_train = subj.mat_train; end
    try mat_test = subj.mat_test; end
    if isempty(mat_train) && isempty(mat_test)
        try
            mat_train = get_mat(subj, 'pattern', 'data_train');
            mat_test = get_mat(subj, 'pattern', 'data_test');
        end
    end
    if isempty(mat_train) && isempty(mat_test)
        out(['WARNING: in order to use processFeatures_wrapper, your data must either contain ', ...
            'mat_train and mat_test fields or it must be a Princeton SUBJ struct']);
        out(['Feature processing aborted without any changes']);
        return;
    end
    
    % Get labels
    try labels_train = subj.labels; catch; labels_train = subj.labels_train; end
    try labels_test = subj.labels_test; catch; labels_test = labels_train; end
    
    % Cut out data_active and labels_active: containing not-filtered-out
    % examples only
    if ~args.paired_data
        activeExamples_train = find(~isnan(labels_train));
        activeExamples_test = find(~isnan(labels_test));
    else
        activeExamples_train = find(~isnan(labels_train) & ~isnan(labels_test));
        activeExamples_test = activeExamples_train;
    end
    
    mat_train_active = mat_train(:,activeExamples_train);
    mat_test_active = mat_test(:,activeExamples_test);
    labels_train_active = labels_train(activeExamples_train);
    labels_test_active = labels_test(activeExamples_test);
    
    % Initialize versions that will be modified by the sequence of
    % preprocessing functions
    mat_train_active_modified = mat_train_active;
    mat_test_active_modified = mat_test_active;
    labels_train_active_modified = labels_train_active;
    labels_test_active_modified = labels_test_active;
    
    % Go through all feature processing functions in order
    for f = 1:length(processFeatures_func)
        
        func = processFeatures_func{f};
        func_actual = str2func(func2str(func));
        out(['Feature-preprocessing function ', ...
            num2str(f), '/', num2str(length(processFeatures_func)), ': ', ...
            func2str(func_actual)]);
        increaseIndent;
        
        % Invoke function on mat_train
        out(['mat_train: ', func2str(func_actual)]);
        [mat_train_active_modified, labels_train_active_modified] = func_actual(...
            mat_train_active_modified, labels_train_active_modified, processFeatures_args);
        labels_train_active_modified = labels_train_active_modified(:)';
        
        % Invoke function on mat_test
        out(['mat_test: ', func2str(func_actual)]);
        [mat_test_active_modified, labels_test_active_modified] = func_actual(...
            mat_test_active_modified, labels_test_active_modified, processFeatures_args);
        labels_test_active_modified = labels_test_active_modified(:)';
        
        % Check returned data and labels
        if size(mat_train_active_modified,1)~=size(mat_test_active_modified,1)
            error('after preprocessing, train and test matrices have different numbers of features');
        end
        if args.paired_data && ...
            size(mat_train_active_modified,2)~=size(mat_test_active_modified,2)
            error('given paired data, preprocessing functions must not return differential numbers of examples');
        end
        if args.paired_data && ...
            length(labels_train_active_modified)~=length(labels_test_active_modified)
            error('given paired data, preprocessing functions must not return differential numbers of labels');
        end
        if size(mat_train_active_modified,2)~=size(labels_train_active_modified,2)
            error('after preprocessing, the train matrix contains a different number of examples than the train labels vector');
        end
        if size(mat_test_active_modified,2)~=size(labels_test_active_modified,2)
            error('after preprocessing, the test matrix contains a different number of examples than the test labels vector');
        end
        
        % When data is paired, combine the returned labels by setting all
        % labels to NaN that are NaN in at least one of them
        if args.paired_data
            labels_train_active_modified(isnan(labels_train_active_modified) | isnan(labels_test_active_modified)) = NaN;
            labels_test_active_modified(isnan(labels_train_active_modified) | isnan(labels_test_active_modified)) = NaN;
        end
        
        decreaseIndent;
    end
    
    
    % SHOW WHAT HAS CHANGED
    % Get changes in features
    dimChange = size(mat_train_active_modified)-size(mat_train_active);
    if dimChange(1) > 0
        tmp1 = [num2str(dimChange(1)), ' feature(s) have been added.'];
    elseif dimChange(1) < 0
        tmp1 = [num2str(-dimChange(1)), ' feature(s) have been removed.'];
    else
        tmp1 = 'No features have been added or removed.';
    end
    
    % Get changes in features
    if dimChange(2) > 0
        tmp2 = [num2str(dimChange(2)), ' example(s) have been added.'];
    elseif dimChange(2) < 0
        tmp2 = [num2str(-dimChange(2)), ' example(s) have been removed.'];
    else
        tmp2 = 'No examples have been added or removed.';
    end
    
    % Print changes
    out('Preprocessing has led to the following dimensionality changes:');
    increaseIndent;
    out(tmp1);
    out(tmp2);
    decreaseIndent;
    
    
    % REINSERT LABELS
    % If the number of examples has changed during preprocessing,
    % adapt 'activeExamples' and 'labels' before reinsertion
    dimChange = length(labels_train_active_modified)-length(labels_train_active);
    if dimChange > 0
        % Examples have been added --> fill up
        activeExamples_train = [activeExamples_train, length(labels_train)+1:length(labels_train)+dimChange];
        labels = [labels, NaN(1,dimChange)];
    end
    dimChange = length(labels_test_active_modified)-length(labels_test_active);
    if dimChange > 0
        % Examples have been added --> fill up
        activeExamples_test = [activeExamples_test, length(labels_test)+1:length(labels_test)+dimChange];
        labels = [labels, NaN(1,dimChange)];
    end
    
    % Reinsert modified labels into full labels
    labels_train(activeExamples_train) = labels_train_active_modified;
    labels_test(activeExamples_test) = labels_test_active_modified;
    
    % Write back labels
    subj.labels_train = labels_train;
    subj.labels_test = labels_test;
    
    
    % REINSERT DATA
    % If the dimensionality of the data matrices has been modified in any
    % way during preprocessing, adapt existing data matrix before
    % reinsertion
    mat_train = adaptData(mat_train, size(mat_train_active_modified)-size(mat_train_active));
    mat_test = adaptData(mat_test, size(mat_test_active_modified)-size(mat_test_active));
    
    % Reinsert modified data_*_active into full data_*
    mat_train(:,activeExamples_train) = mat_train_active_modified;
    mat_test(:,activeExamples_test) = mat_test_active_modified;
    
	% Write back data
    if isfield(subj, 'mat_train')
        subj.mat_train = mat_train;
    end
    if isfield(subj, 'mat_test')
        subj.mat_test = mat_test;
    end
    if ~isfield(subj, 'mat_train') && ~isfield(subj, 'mat_test')
        subj = set_mat(subj, 'pattern', 'data_train', mat_train, 'ignore_diff_size', true);
        subj = set_mat(subj, 'pattern', 'data_test', mat_test, 'ignore_diff_size', true);
    end
    
end

% -------------------------------------------------------------------------
function data = adaptData(data, dimChange)
    if dimChange(1) > 0
        % Features have been added --> prepare room with NaNs
        data = [data; NaN(dimChange(1),size(data,2))];
    elseif dimChange(1) < 0
        % Features have been removed --> crop data
        data = data(1:size(data,1)-(-dimChange),:);
    end
    
    if dimChange(2) > 0
        % Examples have been added --> prepare room with NaNs
        data = [data, NaN(size(data,1),dimChange(2))];
    end
end
