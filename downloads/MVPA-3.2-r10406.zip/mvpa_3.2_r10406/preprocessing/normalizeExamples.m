% Normalizes examples, i.e., scales each example to unit length.
%
% Implements the 'processFeatures_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [data, labels] = normalizeExamples(data, labels, args)
	
    for e = 1:size(data,2)
        %progress(e,size(data,2));
        data(:,e) = data(:,e) / norm(data(:,e));
    end
    
end
