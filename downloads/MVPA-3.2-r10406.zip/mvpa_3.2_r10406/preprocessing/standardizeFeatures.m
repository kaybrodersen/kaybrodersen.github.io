% Standardizes every feature so that it has mean 0 and SD 1 across all
% examples.
%
% Implements the 'processFeatures_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [data, labels] = standardizeFeatures(data, labels, args)
	
    data = std_cols(data')';
    
end

% -------------------------------------------------------------------------
function x = std_cols(x)
    n = size(x,1);
    m = nanmean(x,1);
    s = nanstd(x,0,1);
    
    % Standardize
    warning('off', 'MATLAB:divideByZero');
    x = (x - m(ones(n,1),:)) ./ s(ones(n,1),:);
    warning('on', 'MATLAB:divideByZero');
    
    % Replace NaNs by zeros
    x(isnan(x)) = 0;
    %x(x==inf) = 0;
end
