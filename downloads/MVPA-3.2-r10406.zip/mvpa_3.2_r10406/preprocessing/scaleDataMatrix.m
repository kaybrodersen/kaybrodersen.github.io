% Scales the entire data matrix so that its range is [0, 1].
%
% Implements the 'processFeatures_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [data, labels] = scaleDataMatrix(data, labels, args)
	
    out('Scaling ''features x examples'' matrix...');
    data = scale_matrix(data);
    out(['--> new range: ', mat2str([min(min(data)), max(max(data))])]);
    
end

% -------------------------------------------------------------------------
function m = scale_matrix(m)
    minimum = min(min(m));
    m = m - minimum;
    
    maximum = max(max(m));
    if (maximum ~= 0)
        m = m / maximum;
    end
    
    % Test result
    newMinimum = min(min(m));
    newMaximum = max(max(m));
    if ~(isnan(newMinimum) || newMinimum==0)
        error('invariant about new min violated');
    end
    if ~(isnan(newMaximum) || newMaximum==1 || (newMinimum==0 && newMaximum==0))
        error('invariant about new max violated');
    end
end
