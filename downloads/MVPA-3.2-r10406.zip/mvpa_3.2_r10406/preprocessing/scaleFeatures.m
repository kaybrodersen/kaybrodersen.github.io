% Scale features so that each feature's range is [0 1].
%
% Implements the 'processFeatures_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [data, labels] = scaleFeatures(data, labels, args)
	
    out('Scaling every feature...');
    data = scale_cols(data')';
    
end

% -------------------------------------------------------------------------
% Scales all columns of a matrix. There are two ways of using this
% function.
% 
% (a) Scaling a matrix and remembering what was done
%     [x, model] = scaleColumns(x);
% 
% (b) Scaling a matrix using a previously devised model
%     y = scaleColumns(y, model);
%
% where:
%     x - matrix
%     model - 2xN matrix (where N = size(x,2)). It contains the
%         prescription of how each column was turned into its new version:
%         subtract model(1,c), then divide by model(2,c), for each column
%         c. In this way, the same scaling can be applied to unseesn test
%         data.
function [x, model] = scale_cols(x, model)
    
    % Fresh scaling, develop a model?
    if ~exist('model', 'var')
        for c = 1:size(x,2)
            a = min(x(:,c));
            x(:,c) = x(:,c) - a;
            model(1,c) = a;
            b = max(x(:,c));
            if b~=0
                x(:,c) = x(:,c) / b;
            end
            model(2,c) = b;
        end
        
    % Use existing model?
    else
        for c = 1:size(x,2)
            a = model(1,c);
            x(:,c) = x(:,c) - a;
            b = model(2,c);
            if b~=0
                x(:,c) = x(:,c) / b;
            end
        end
    end
    
end
