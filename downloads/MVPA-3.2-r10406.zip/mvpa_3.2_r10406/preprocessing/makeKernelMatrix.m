% Turns a FEATURES x EXAMPLES matrix into an EXAMPLES x EXAMPLES kernel
% matrix.
% 
% Usage:
%     K = makeKernelMatirx(data)
%     K = makeKernelMatirx(data, args)
%
% Arguments:
%     data: FEATURES x EXAMPLES matrix
%     args: optional struct with further arguments:
%         .libsvm (true/false): whether to include serial example numbers
%         in the first row (default: false). Required for LIBSVM.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function K = makeKernelMatrix(data, args)
	
    % Check input
    defaults.libsvm = false;
    args = propval(args, defaults);
    
    % Linear kernel
    K = data'*data;
    
    % Add serial numbers?
    if args.libsvm
        K = [1:size(data,2); K];
    end
    
end
