% Reduces the dimensionality of the feature space by means of a lossy PCA.
%
% Additional named arguments:
%     'nComponents' (default: all) - how many components to keep
% 
% Implements the 'processFeatures_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: compressByPCA.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [data, labels] = compressByPCA(data, labels, args)
	
    % Check input
    defaults.nComponents = size(data,2)-1;
    args = propval(args, defaults, 'strict', false);
    args.nComponents = min([size(data,2)-1, args.nComponents]);
    
    % Do the PCA
    out(['Applying PCA (dimensionality reduction ', ...
        num2str(size(data,1)), ' -> ', num2str(args.nComponents), ')...']);
    
    [pccoeff, pcvec] = pca(data, args.nComponents);
    data = pcvec';
    
end
