% Simple scoring wrapper that creates a searchlight score for each voxel,
% using the specified objective function (e.g., Hotellings T-test). There
% is no cross-validation.
% 
% This function is intended to be passed as statmap_func to createStatmaps.
% 
% This function operates in LEGACY mode.
% 
% Usage:
%     statmap_searchlight_simple(subj, fold, new_mapname, statmap_args)
% 
% Arguments:
%     subj: Princeton subj struct that contains a Princeton pattern called
%         'data_train', and a field subj.adj_list.
%     outerFold: a single object from a subj.folds() struct array containing a
%         .train and a .test field
%     new_mapname: name of the map to be created
%     statmap_args: additional custom arguments
% 
% Custom fields in statmap_args:
%     'searchlightRadius'
%     'add_center_voxel'
%     'ignore_empty_adj_list'
%     'obj_func' (required) The objective function (e.g., statmap_hotelling)
%     'obj_args' (optional) Additional arguments for the objective function
%     'processFeatures_func'
%     'processFeatures_args'

% Kay H. Brodersen, ETHZ/UZH
% $Id: statmap_searchlight_simple.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = statmap_searchlight_simple(subj, outerFold, new_mapname, statmap_args)
    
    % Check input
    defaults.searchlightRadius = 2;
    defaults.add_center_voxel = true;
    defaults.ignore_empty_adj_list = false;
    defaults.obj_func = [];
    defaults.obj_args = [];
    defaults.processFeatures_func = [];
    defaults.processFeatures_args = [];
    args = propval(statmap_args, defaults, 'strict', false);
    if isempty(args.obj_func)
        error('objective function (obj_func) required');
    end
    try subj.labels_train; catch; subj.labels_train = subj.labels; end
    
    
    % ---------------------------------------------------------------------
    % Create adjacency matrix (unless already created)
    subj.adj_list = create_adj_list(subj, 'the_mask', ...
        'radius', args.searchlightRadius);
    
    
    % -------------------------------------------------------------
    % Get data and labels (outer training set)
    mat_train = get_mat(subj, 'pattern', 'data_train');
    mat_train = mat_train(:, outerFold.train);
    labels_train = subj.labels_train(outerFold.train);
    assert(size(mat_train,2)==length(labels_train));
    
    % Initialize map accumulator
    nVox = subj.nFeatures;
    map = NaN(nVox,1);
    
    % Prepare objective function and args
    obj_func_actual = str2func(func2str(args.obj_func));
    try obj_args = args.obj_args; catch; obj_args = []; end
    
    
    % -------------------------------------------------------------
    % Loop over spheres (or whatever adjacency neighborhood we're using)
    out(['Looping over ', num2str(nVox), ' spheres...']);
    for v = 1:nVox
        %out(['Voxel ', num2str(v), ' / ', num2str(nVox)]);
        progress(v,nVox);
        
        % Get adjacency list for current voxel
        cur_adj_list = subj.adj_list(v,:);
        
        % Throw away all zero-values from adjacency list
        cur_adj_list = cur_adj_list(cur_adj_list~=0);
        
        % Add the current (center) voxel to its own sphere? (Usually, this is
        % 'false' because the center voxel is already contained in its sphere
        % by construction of the sphere.)
        if args.add_center_voxel && ~find(cur_adj_list==v)
            vox_idx = [v cur_adj_list];
        else
            vox_idx = cur_adj_list;
        end
        
        % Set actual data
        % This is a VOXELS x TRIALS matrix which only contains those voxels
        % which are contained in the spherical searchlight defined for the
        % current voxel.
        sphere_train = mat_train(vox_idx,:);
        
        % Process this sphere only if it contains at least two voxels
        % (unless searchlight radius = 0)
        if length(vox_idx)<2 && args.searchlightRadius>0
            map(v) = 0;
            out(['NOTE: voxel ', num2str(v), ' score set to ', num2str(map(v)), ' because no other voxels in its sphere']);
            continue;
        end
        
        % Process this sphere only if at least one of the contained voxels
        % has some data in it (rather than just all zero)
        if all(sum(sphere_train,2)==0)
            map(v) = 0;
            out(['NOTE: voxel ', num2str(v), ' score set to ', num2str(map(v)), ' because no nonzero data in its sphere']);
            continue;
        end
        
        % Process features (new)
        warning(['Haven''t tested this bit of code yet']);
        try args.processFeatures_func; args.processFeatures_func = {}; end
        try args.processFeatures_args; catch; args.processFeatures_args = []; end
        if ~isempty(args.processFeatures_func) && ~iscell(args.processFeatures_func)
            args.processFeatures_func = {args.processFeatures_func};
        end
        if ~isempty(args.processFeatures_func) && ~iscell(args.processFeatures_func)
            args.processFeatures_func = {args.processFeatures_func};
        end
        for pf = 1:length(args.processFeatures_func)
            pf_actual = str2func(func2str(args.processFeatures_func{pf}));
            if v==1
                out(' ');
                out(['Feature preprocessing:']);
                out(['    ', func2str(pf_actual)]);
                sphere_train = pf_actual(sphere_train, labels_train, args.processFeatures_args);
            end
        end
        
        % Invoke objective function (e.g., statmap_mahalanobis)
        thisResult = obj_func_actual(sphere_train, labels_train, obj_args);
            
        % Assign result to current voxel
        map(v) = thisResult;
        
    end % voxel v        
    
    
    % ---------------------------------------------------------------------
    % Add map to the SUBJ structure as a new pattern
    masked_by = get_objfield(subj, 'pattern', 'data_train', 'masked_by');
    subj = initset_object(subj, 'pattern', new_mapname, map, 'masked_by', masked_by);
    
end
