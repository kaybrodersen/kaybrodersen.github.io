% Wrapper function for performance evaluation.
%
% Callee interface:
%     score = perf_func(targs, preds, perf_args)
%
% Arguments:
%     targs: true labels
%     preds: predicted labels
%     perf_args: further arguments

% Kay H. Brodersen, ETHZ/UZH
% $Id: perf_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function score = perf_wrapper(targs, preds, perf_func, perf_args)
    
    % Check input
    assert(~isempty(perf_func), 'Must specify a perf_func function');
    
    % Call performance function
    perf_func_actual = str2func(func2str(perf_func));
    score = perf_func_actual(targs, preds, perf_args);

end
