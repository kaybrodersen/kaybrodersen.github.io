% Training function for the GMM classifier.
%
% See 'train_wrapper' interface.
%
% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function scratch = train_gmm(trainpats, labels, nClasses, train_args)
    
    % Train the GMM and obtain parameter estimates
    y = trainpats;
    options = [];
    K = nClasses;
    n = size(trainpats,2);
    Z = zeros(n,K);
    for i=1:K
        Z(labels==i,i) = 1;
    end
    options.priors.Z = Z;
    [xi,eta,F,theta,K_opt] = VBEM_GM(y,K,options);
    
    % Store parameter estimates in scratch
    % ...
    scratch.Z = xi;
    scratch.etaHat = eta;
    scratch.V = theta.varEta;
    scratch.a_gamma = theta.a_gamma;
    scratch.b_gamma = theta.b_gamma;
    
end
