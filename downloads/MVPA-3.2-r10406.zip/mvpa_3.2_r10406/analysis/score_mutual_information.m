% Estimates the mutual information for the current searchlight environment.
% 
% Usage:
%     mi = statmap_mutual_information(mat, labels, args)
% 
% Return values:
%     mi: mutual information

% Amanda Strong, Mario Frank, ETHZ
% $Id: score_mutual_information.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function mi = statmap_mutual_information(mat, labels, args)
    
    % Estimate mutual information
    mi = jointMI(mat, labels, args);
    
end
