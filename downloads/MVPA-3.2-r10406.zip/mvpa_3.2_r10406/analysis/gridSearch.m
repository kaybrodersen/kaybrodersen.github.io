% Grid search for classifier configuration.
% 
% Usage:
%     [x_opt, results] = gridSearch(mat, indices, labels, folds, nClasses, pars, conf_args)
% 
% Arguments:
%     mat: full data matrix or kernel matrix
%     indices: indices that we are allowed to use, to index into 'mat'
%         (these are usually training indices from a cross-validation fold,
%         which may or may not contain duplicates which we should remove)
%     labels: complete labels vector
%     pars: a struct containing parameters and their ranges, e.g.:
%         pars(1).name = 'parameter 1';
%         pars(1).range = 1:0.1:5;
%     conf_args: additional arguments
%         nFolds OR cv
%         eval_func
%         eval_args
% 
% Return values:
%     x_opt: vector of optimal parameters
%     results: all grid results (for debug purposes)

% Kay H. Brodersen, ETHZ / UZH
% $Id: gridSearch.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [x_opt, results] = gridSearch(mat, indices, labels, nClasses, conf_args)
    
    % Settings needed when calling the evaluation function
    conf.mat = mat;
    conf.indices = indices;
    conf.labels = labels;
    conf.nClasses = nClasses;
    try conf.eval_func = conf_args.eval_func; catch; conf.eval_func = @eval_libsvm; end
    try conf.eval_args = conf_args.eval_args; catch; conf.eval_args = []; end
    try; conf_args.verbose; conf.verbose = conf_args.verbose; catch; conf.verbose = false; end
    
    % Custom checks for libsvm (HACK)
    pars = conf_args.pars;
    if strcmp(func2str(conf.eval_func),'eval_libsvm')
        conf.prune_libsvm = true;
        assert(length(pars)~=6 || ...
            strcmp([pars.name],'tcgrd'), ...
            'pars not in right order');
    else
        conf.prune_libsvm = false;
    end
    
    % SIMPLE XVAL MODE
    if ~isfield(conf_args,'cv')
        % Use libsvm's internal cross-validation
        assert(~isfield(conf_args,'cv'),'do not use conf_args.cv when using conf_args.nFolds');
        conf.folds = [];
        
    % EXTENDED XVAL MODE
    else
        % Design manual cross-validation
        assert(~isfield(conf_args,'nFolds'),'do not use conf_args.nFolds when using conf_args.cv');
        try, cv_args = conf_args.cv; end
        cv_args.pool = conf.indices;
        cv_args.nClasses = nClasses;
        cv_args.verbose = 0;
        [conf.folds, cancel] = createCvFolds(conf.labels(conf.indices), cv_args);
        assert(~cancel);
    end
    
    % Ensure parallel computation is initialized
    %ensureMatlabpool;
    
    % Start loop
    results.xs = [];
    results.vs = [];
    results = loop(nan(1,length(pars)), pars, conf, results, 1);
    
    % Process results
    [~,i_opt] = max(results.vs);
    x_opt = results.xs(i_opt,:);
    assert(~isempty(x_opt));
    
    % Visualize (debug)
    if false
        if length(pars) == 2
            figure; hold on;
            plot(log(pars(2).range)./log(2),results.vs,'.');
            
        elseif length(pars) == 3
            figure; hold on;
            r1 = pars(2).range';
            r2 = pars(3).range';
            z = reshape(results.vs, length(r2), length(r1));
            surf(r1,r2,z);
            plot3(results.xs(:,2), results.xs(:,3), results.vs, '.');
            plot3(x_opt(2), x_opt(3), v_opt, 'r.');
        end
    end
    
    % Present results (debug)
    if false
        if all(results.vs == results.vs(1))
            out('WARNING: objective values all identical: landscape flat!!!');
        end
        disp(['Computed ', num2str(length(results.xs)), ' grid points']);
        disp(['Optimum:']);
        disp(['    x_opt = ', mat2str(x_opt), ' = ', mat2str(log(x_opt)/log(2))]);
        disp(['    v_opt = ', num2str(v_opt)]);
    end
    
end

% -------------------------------------------------------------------------
% Loops over the parameter p and calls itself within the loop to loop over
% the next parameter as well. Stops recursion when the current parameter is
% the last parameter (i.e., p == length(pars)).
% 
% Input arguments:
%   x: full parameter vector, to be passed on until the base case is
%      reached
%   pars: parameter ranges struct
%   p: current parameter index (= recursion index)
function results = loop(x, pars, conf, results, p)
    
    % Loop over current parameter
    for i = 1:length(pars(p).range)
        value = pars(p).range(i);
        
        % Set parameter vector
        x(p) = value;
        
        % Define end of parameters
        lim = length(pars);
        
        % In case of SVM, some kernels make some parameters superfluous
        % (HACK)
        if conf.prune_libsvm
            switch x(1) % kernel type
                case 0, lim = 2;
                case 1, lim = 5;
                case 2, lim = 3;
                case 3, lim = 4;
                case 4, lim = 2;
                otherwise, error('unexpected kernel');
            end
            %assert(lim <= length(pars))
            lim = min([lim, length(pars)]);
        end
        
        % If limit reached, evaluate parameter vector
        if p == lim
            
            % Show progress (optional)
            if conf.verbose>1, out(['Evaluating x=',mat2str(x)]); end
            
            % Evaluate
            eval_func_actual = str2func(func2str(conf.eval_func));
            v = eval_func_actual(conf.mat, conf.indices, conf.labels, conf.folds, ...
                conf.nClasses, pars, x, conf.eval_args);
            results.xs = [results.xs; x];
            results.vs = [results.vs; v];
            
        % Otherwise, recurse
        else
            results = loop(x, pars, conf, results, p+1);
        end
    end
    
end
