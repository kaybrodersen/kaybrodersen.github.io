% Classification by cross-validation without any feature selection.
% 
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaClassifyOne.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaClassifyOne(subj, settings, ana_args)
    warning('This function is deprecated. Use anaPredictOne instead.');
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Designate output file
    filestem = ['clf', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels (positive integers for normal trials; zero labels for
    % trials that are to be ignored).
    try ana_args.loadLabels_func; catch; ana_args.loadLabels_func = settings.loadLabels_func; end
    try ana_args.loadLabels_args; catch; ana_args.loadLabels_args = settings.loadLabels_args; end
    subj.labels = loadLabels_wrapper(subj, ...
        ana_args.loadLabels_func, ana_args.loadLabels_args);
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj.dirScan, ana_args.invertFilter, ...
        length(subj.labels), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels(~tmpFilter) = 0;
    
    
    % ---------------------------------------------------------------------
    % Load data
    % into subj.data_train (any dimensionality)
    % into subj.data_test  (any dimensionality)
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    try ana_args.loadTestData_func; catch; ana_args.loadTestData_func = settings.loadTestData_func; end
    try ana_args.loadTestData_args; catch; ana_args.loadTestData_args = settings.loadTestData_args; end
    
    loadData_scratch = [];
    [subj.data_train, loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj.data_test, loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    
    assert(ndims(subj.data_train)==ndims(subj.data_test));
    assert(all(size(subj.data_train)==size(subj.data_test)));
    
    
    % ---------------------------------------------------------------------
    % Load mask (optional)
    try; try ana_args.loadMask_func; catch; ana_args.loadMask_func = settings.loadMask_func; end;
    catch; ana_args.loadMask_func = []; end
    try; try ana_args.loadMask_args; catch; ana_args.loadMask_args = settings.loadMask_args; end;
    catch; ana_args.loadMask_args = []; end
    
    if ~isempty(ana_args.loadMask_func)
        subj.mask = loadMask_wrapper(subj, ...
            ana_args.loadMask_func, ana_args.loadMask_args);
    else
        subj.mask = [];
    end
    
    
    % ---------------------------------------------------------------------
    % Flatten data to FEATURES x EXAMPLES
    subj.mat_train = vol2mat(subj.data_train, subj.mask);
    subj.mat_test = vol2mat(subj.data_test, subj.mask);
    subj = rmfield(subj, 'data_train');
    subj = rmfield(subj, 'data_test');
    
    
    % ---------------------------------------------------------------------
    % Check dimensionality
    if ~all(size(subj.mat_train)==size(subj.mat_test))
        out(['ABORT: training and test data have a different dimensionality']);
        out(['    mat_train: ', mat2str(size(subj.mat_train))]);
        out(['    mat_test:  ', mat2str(size(subj.mat_test))]);
        return;
    end
    
    % Remove all features with a NaN in some trial
    badFeatures = any(isnan(subj.mat_train),2) | any(isnan(subj.mat_test),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value and will be removed']);
        subj.mat_train(badFeatures,:) = [];
        subj.mat_test(badFeatures,:) = [];
        assert(all(size(subj.mat_train)==size(subj.mat_test)));
    end
    
    % Exclude all trials with a NaN in some feature (set their labels to 0)
    badTrials = any(isnan(subj.mat_train),1) | any(isnan(subj.mat_test),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' trials have at least one NaN feature and will be ignored']);
        subj.labels(badTrials) = 0;
    end
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args);
    
    
    % ---------------------------------------------------------------------
    % Last preparations
    subj.nFeatures = size(subj.mat_train,1);
    subj.nExamples = size(subj.mat_train,2);
    subj.nClasses = length(zerounique(subj.labels));
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create (outer) cross-validation folds
    cv = ana_args.cv;
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    cv.verbose = 0;
    [subj.folds, cancel] = createCvFolds(subj.labels, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Classification by (outer) cross-validation
    results = runCrossValidation(subj, ana_args.class_args);
    
    
    % ---------------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
