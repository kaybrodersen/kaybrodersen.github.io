% Creates a performance map for every outer fold specified in subj.folds.
% Optionally also thresholds the resulting maps to create binary masks.
% 
% This function operates in LEGACY mode (requiring a Princeton SUBJ struct).
% 
% Usage:
%     subj = runStatmapsLegacy(subj, statmap_func, statmap_args, varargin)
% 
% Named arguments:
%     'new_mapname' - name of the new statmap to be created
%         (default: 'statmap')
%     'new_maskname' - name of the new mask to be created (if enabled)
%         (default: 'statmap_mask')
% 
% In order to create a mask for each map that is created, specify either of
% the following arguments as part of statmap_args:
%     'nTopFeatures' - creates a group of masks that include a certain
%         number of top features (e.g., voxels)
%     'threshTopFeatures' - creates a group of masks that all features
%         (e.g., voxels) whose score is equal or greater than this
%         threshold.

% Adapted from the MVPA toolbox.
% Kay H. Brodersen, ETHZ/UZH
% $Id: runStatmapsLegacy.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = runStatmapsLegacy(subj, statmap_func, statmap_args)
    
    % Process inputs
    defaults.new_mapname = 'statmap';
    defaults.new_maskname = 'statmap_mask';
    defaults.nTopFeatures = [];
    defaults.threshTopFeatures = [];
    args = propval(statmap_args, defaults, 'strict', false);
    
    % Go through all outer folds
    nFolds = length(subj.folds); 
    assert(nFolds>0);
    for f = 1:nFolds
        out([' ']);
        out(['GENERATING STATMAP FOR OUTER FOLD ', num2str(f), '/', num2str(nFolds)]);
        out(['using ''', func2str(statmap_func), '''']);
        out(' ');
        increaseIndent;
        
        % Name the new statmap and thresholded mask that will be created
        fold_mapname = sprintf('%s_%i', args.new_mapname, f);
        fold_maskname = sprintf('%s_%i', args.new_maskname, f);
        
        % Invoke statmap function to generate statmap for this fold
        % (e.g., classifier, Hotelling's)
        statmap_func_actual = str2func(func2str(statmap_func));
        subj = statmap_func_actual(subj, subj.folds(f), fold_mapname, statmap_args);
        subj = set_objfield(subj, 'pattern', fold_mapname, 'group_name', args.new_mapname);
        
        % Invoke deriveMasksLegacy, which invokes a custom
        % select_features_func, to create a mask from the new statmap
        % (optional)
        try, statmap_args.select_func; catch; statmap_args.select_func = []; end
        try, statmap_args.select_args; catch; statmap_args.select_args = []; end
        if ~isempty(statmap_args.select_func)
            subj = deriveMasksLegacy(subj, fold_mapname, fold_maskname, args.new_maskname, ...
                statmap_args.select_func, statmap_args.select_args);
        else
            out(['(No feature selection requested)']);
        end        
        
        decreaseIndent;
    end % outer fold
    
end
