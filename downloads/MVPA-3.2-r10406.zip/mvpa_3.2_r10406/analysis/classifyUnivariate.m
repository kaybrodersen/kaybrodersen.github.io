% Classifies with simple univariate feature selection
% ! OLD, CURRENTLY NOT MAINTAINED !

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [results, cancelThisSubject] = classifyUnivariate(subj, settings)
    
    % ---------------------------------------------------------------------
    % Create selectors
    subj = init_object(subj, 'selector', 'runs');
    runs = [1:120]; % l-o-o cross validation
    subj = set_mat(subj, 'selector', 'runs', runs);
    
    % ---------------------------------------------------------------------
    % Balance classes/rewards
    if settings.clf.balanceClasses
        [subj, settings.clf.nFolds] = balanceClasses(subj);
    else
        % Create selector indices for each iteration of the
        % cross-validation
        subj = create_xvalid_indices(subj, 'runs');
        nFolds = size(get_group_as_matrix(subj, 'selector', 'runs_xval'),1);
        if (nFolds ~= settings.clf.nSamples)
            error('invariant violated');
        end
    end
    
    % ---------------------------------------------------------------------
    % ANOVA: z-scoring the data, individually on each iteration (using
    % the selectors we created earlier)
    subj = zscore_runs(subj, 'data', 'runs');
    
    % Feature selection
    subj = feature_select(subj, 'data_z', 'classes', 'runs_xval');
    
    % How many voxels were selected?
    nVoxelsAll = get_objfield(subj, 'mask', 'mask-ofc', 'nvox');
    nVoxelsSelected = [];
    for i=1:subj.nSamples
        tmp = get_objfield(subj, 'mask', 'data_z_thresh0.05_1', 'nvox');
        nVoxelsSelected = [nVoxelsSelected, tmp];
    end
    out(['Average number of selected voxels: ', num2str(mean(nVoxelsSelected)), ...
        ' out of ', num2str(nVoxelsAll), ...
        ' (= ', num2str(fix(100*mean(nVoxelsSelected)/nVoxelsAll)), '%)']);
    
    % ---------------------------------------------------------------------
    % Initialize classifier
    settings.cuv.class_args = initializeClassifier(settings.cuv.class_args);
    %.........
    
    % Configure classifier
    %class_args.train_funct_name = 'train_gnb';
    %class_args.test_funct_name = 'test_gnb';
    class_args.train_funct_name = 'train_bp';
    class_args.test_funct_name = 'test_bp';
    class_args.nHidden = 0;
    class_args.uniform_prior = true;
    
    % ---------------------------------------------------------------------
    % Run classifier
    [subj, results] = cross_validation(subj, ...
        'data_z', 'classes', 'runs_xval', 'data_z_thresh0.05', class_args);
end
