% Prediction by cross-validation. No feature selection.
% 
% Supports the use of separate data features or labels for training and
% testing.
% 
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaPredictOne.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaPredictOne(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && any(settings.legacy)), 'non-legacy settings expected');
    
    % Designate output filename
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try loadTrainLabels_func = settings.loadTrainLabels_func; catch; loadTrainLabels_func = settings.loadLabels_func; end
    try loadTrainLabels_args = settings.loadTrainLabels_args; catch; loadTrainLabels_args = settings.loadLabels_args; end
    try loadTestLabels_func = settings.loadTestLabels_func; catch; loadTestLabels_func = settings.loadLabels_func; end
    try loadTestLabels_args = settings.loadTestLabels_args; catch; loadTestLabels_args = settings.loadLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(loadTrainLabels_func));
    loadTestLabels_func_actual = str2func(func2str(loadTestLabels_func));
    subj.nClasses = max([loadTrainLabels_func_actual(), loadTestLabels_func_actual()]);
    
    % Load labels (positive integers for normal trials; NaN labels for
    % trials that are to be ignored).
    subj.labels_train = loadLabels_wrapper(subj, loadTrainLabels_func, loadTrainLabels_args);
    subj.labels_test = loadLabels_wrapper(subj, loadTestLabels_func, loadTestLabels_args);
    if ~nanequals(subj.labels_train, subj.labels_test)
        out(['WARNING: Note that training labels and test labels are not identical!']);
    end
    
    % Ignore trials where train or test label is NaN
    subj.labels_train(isnan(subj.labels_train) | isnan(subj.labels_test)) = NaN;
    subj.labels_test(isnan(subj.labels_train) | isnan(subj.labels_test)) = NaN;
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj.dirScan, ana_args.invertFilter, ...
        length(subj.labels_train), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels_train(~tmpFilter) = NaN;
    subj.labels_test(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    if ana_args.randomizeLabels>0
        subj.labels_test = subj.labels_train;
    end
    
    
    % ---------------------------------------------------------------------
    % Load data
    % into subj.data_train (any dimensionality)
    % into subj.data_test  (any dimensionality)
    try loadTrainData_func = settings.loadTrainData_func; catch; loadTrainData_func = settings.loadData_func; end
    try loadTrainData_args = settings.loadTrainData_args; catch; loadTrainData_args = settings.loadData_args; end
    try loadTestData_func = settings.loadTestData_func; catch; loadTestData_func = settings.loadData_func; end
    try loadTestData_args = settings.loadTestData_args; catch; loadTestData_args = settings.loadData_args; end
    
    loadData_scratch = [];
    [subj.data_train, loadData_scratch] = loadData_wrapper(subj, ...
        loadTrainData_func, loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj.data_test, loadData_scratch] = loadData_wrapper(subj, ...
        loadTestData_func, loadTestData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    
    assert(ndims(subj.data_train)==ndims(subj.data_test));
    assert(all(size(subj.data_train)==size(subj.data_test)));
    
    
    % ---------------------------------------------------------------------
    % Load mask (optional)
    try loadMask_func = settings.loadMask_func; catch; loadMask_func = []; end;
    try loadMask_args = settings.loadMask_args; catch; loadMask_args = []; end;
    
    if ~isempty(loadMask_func)
        subj.mask = loadMask_wrapper(subj, loadMask_func, loadMask_args);
    else
        subj.mask = [];
    end
    
    
    % ---------------------------------------------------------------------
    % Flatten data to FEATURES x EXAMPLES
    subj.mat_train = vol2mat(subj.data_train, subj.mask);
    subj.mat_test = vol2mat(subj.data_test, subj.mask);
    subj = rmfield(subj, 'data_train');
    subj = rmfield(subj, 'data_test');
    
    
    % ---------------------------------------------------------------------
    % Check dimensionality
    if ~all(size(subj.mat_train)==size(subj.mat_test))
        out(['ABORT: training and test data have a different dimensionality']);
        out(['    mat_train: ', mat2str(size(subj.mat_train))]);
        out(['    mat_test:  ', mat2str(size(subj.mat_test))]);
        cancel = true;
        return;
    end
    if size(subj.mat_train,2)~=length(subj.labels_train) || ...
       size(subj.mat_test,2)~=length(subj.labels_test)
        out(['ABORT: labels and data have different number of examples']);
        cancel = true;
        return;
    end
    
    % Remove all features with a NaN in some trial
    badFeatures = any(isnan(subj.mat_train),2) | any(isnan(subj.mat_test),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value and will be removed']);
        subj.mat_train(badFeatures,:) = [];
        subj.mat_test(badFeatures,:) = [];
        assert(all(size(subj.mat_train)==size(subj.mat_test)));
    end
    
    % Exclude all trials with a NaN in some feature (set their labels to NaN)
    badTrials = any(isnan(subj.mat_train),1) | any(isnan(subj.mat_test),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' trials have at least one NaN feature and will be ignored']);
        subj.labels_train(badTrials) = NaN;
        subj.labels_test(badTrials) = NaN;
    end
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args, ...
        'paired_data', true);
    
    
    % ---------------------------------------------------------------------
    % Last preparations
    subj.nFeatures = size(subj.mat_train,1);
    subj.nExamples = size(subj.mat_train,2);
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create (outer) cross-validation folds
    cv = ana_args.cv;
    
    % Set balancing criteria
    try; try cv.loadBalancingCriteria_func; catch; cv.loadBalancingCriteria_func = settings.loadBalancingCriteria_func; end;
    catch; cv.loadBalancingCriteria_func = []; end
    try; try cv.loadBalancingCriteria_args; catch; cv.loadBalancingCriteria_args = settings.loadBalancingCriteria_args; end;
    catch; cv.loadBalancingCriteria_args = []; end
    cv.balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
        cv.loadBalancingCriteria_func, cv.loadBalancingCriteria_args);
    
    % Load block filter
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    
    % Create CV folds
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Prediction by (outer) cross-validation
    results = runCrossValidation(subj, ana_args.class_args);
    
    
    % ---------------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
