% Wrapper for a classifier train function.
%
% Callee interface:
%     scratch = train_func(data_train, labels_train, train_args)
%
% Arguments:
%     data_train: training data
%     labels_train: training labels
%     train_func: training function
%     train_args: further args to be passed on to the training function
% 
% Return values:
%     scratch: contains the model that the classifier has learned

% Kay H. Brodersen, ETHZ/UZH
% $Id: train_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scratch = train_wrapper(data_train, labels_train, ...
    train_func, train_args)
    
    % Check input
    if isempty(train_args)
        train_args = struct;
    end
    if size(data_train,2) ~= size(labels_train,2)
        % (This test works for both data matrices and kernel matrices)
        error('different number of training examples and labels');
    end
    
    % Call train function
    train_func_actual = str2func(func2str(train_func));
    scratch = train_func_actual(data_train, labels_train, train_args);
    
end
