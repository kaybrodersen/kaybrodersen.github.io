% Classification accuracy.
%
% Implements the 'perf_wrapper' interface.
% 
% Usage:
%     score = perf_acc(targs, preds, perf_args)

% Kay H. Brodersen, ETHZ/UZH
% $Id: perf_acc.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function score = perf_acc(targs, preds, perf_args)
    
    % Define worst score as 0
    if isempty(targs) && isempty(preds)
        score = 0;
        return;
    end
    
    c = confusionmat(targs, preds, 'order', [1 2]);
    score = acc_mode(c);
    
end
