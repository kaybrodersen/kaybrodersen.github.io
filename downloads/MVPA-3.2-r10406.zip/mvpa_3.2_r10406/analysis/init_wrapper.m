% Wrapper function for initializing a classifier.
%
% Is called at the beginning of the analysis. Allows for setting up the
% classifier if things need to be done that need not be done during each
% call of the train or test function, to speed things up.

% Callee interface:
%     class_args = init_func(class_args)

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% -------------------------------------------------------------------------
function class_args = init_wrapper(init_func, class_args)
	
    if isempty(init_func)
        out(' ');
        out('(No classifier initialization specified)');
    else
        out(' ');
        out(['Initializing classifier...']);
        increaseIndent;
        
        init_func_actual = func2str(str2func(init_func));
        class_args = init_func_actual(class_args);
        decreaseIndent;
    end
end
