% Learns a prediction model based on the entire dataset. Testing is done on
% the same dataset as learning, to get the empirical training error.
% 
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaLearnModel.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaLearnModel(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && any(settings.legacy)), 'non-legacy settings expected');
    
    % Designate output file
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try ana_args.loadTrainLabels_func; catch; ana_args.loadTrainLabels_func = settings.loadTrainLabels_func; end
    try ana_args.loadTrainLabels_args; catch; ana_args.loadTrainLabels_args = settings.loadTrainLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(ana_args.loadTrainLabels_func));
    subj.nClasses = loadTrainLabels_func_actual();
    
    % Load labels (NaN for trials to be ignored)
    subj.labels_train = loadLabels_wrapper(subj, ...
        ana_args.loadTrainLabels_func, ana_args.loadTrainLabels_args);
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj, ana_args.invertFilter, ...
        length(subj.labels_train), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels_train(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    
    
    % ---------------------------------------------------------------------
    % Load mask (optional)
    try; try ana_args.loadMask_func; catch; ana_args.loadMask_func = settings.loadMask_func; end;
    catch; ana_args.loadMask_func = []; end
    try; try ana_args.loadMask_args; catch; ana_args.loadMask_args = settings.loadMask_args; end;
    catch; ana_args.loadMask_args = []; end
    
    if ~isempty(ana_args.loadMask_func)
        subj.mask = loadMask_wrapper(subj, ana_args.loadMask_func, ana_args.loadMask_args);
    else
        subj.mask = [];
    end
    
    
    % ---------------------------------------------------------------------
    % Load data
    % into subj.data_train (any dimensionality)
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    
    loadData_scratch = [];
    [subj.data_train, loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    
    
    % ---------------------------------------------------------------------
    % Flatten data to FEATURES x EXAMPLES
    subj.mat_train = vol2mat(subj.data_train, subj.mask);
    subj = rmfield(subj, 'data_train');
    
    
    % ---------------------------------------------------------------------
    % Remove all features with a NaN in some trial
    badFeatures = any(isnan(subj.mat_train),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value and will be removed']);
        subj.mat_train(badFeatures,:) = [];
    end
    
    % Exclude all examples with a NaN in some feature (set their labels to NaN)
    badTrials = any(isnan(subj.mat_train),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' examples have at least one NaN feature and will be ignored']);
        subj.labels_train(badTrials) = NaN;
    end
    
    % For compatibility reasons, set test labels and data
    subj.labels_test = subj.labels_train;
    subj.mat_test = subj.mat_train;
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args, ...
        'paired_data', true);
    
    
    % ---------------------------------------------------------------------
    % Last preparations
    subj.nFeatures = size(subj.mat_train,1);
    subj.nExamples = size(subj.mat_train,2);
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Debug
    try ana_args.debug_func; catch; ana_args.debug_func = []; end
    try ana_args.debug_args; catch; ana_args.debug_args = []; end
    [~, args] = debug_wrapper(subj, settings, ana_args.debug_func, ana_args.debug_args, []);
    
    
    % ---------------------------------------------------------------------
    % Create single outer fold (or several if blocks structure) in which
    % all trials are in the training set, and none in the test set.
    cv = ana_args.cv;
    cv.bSinglePeekingFoldOnly = true;
    cv.setSize = 1;
    
    % Set balancing criteria
    try; try cv.loadBalancingCriteria_func; catch; cv.loadBalancingCriteria_func = settings.loadBalancingCriteria_func; end;
    catch; cv.loadBalancingCriteria_func = []; end
    try; try cv.loadBalancingCriteria_args; catch; cv.loadBalancingCriteria_args = settings.loadBalancingCriteria_args; end;
    catch; cv.loadBalancingCriteria_args = []; end
    cv.balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
        cv.loadBalancingCriteria_func, cv.loadBalancingCriteria_args);
    
    % Load block filter
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    
    % Create CV folds
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create statmaps and masks (e.g., searchlight analysis) (optional)
    
    % Set balancing criteria
    try; ana_args.statmap_args.cv.loadBalancingCriteria_func; catch; ...
            ana_args.statmap_args.cv.loadBalancingCriteria_func = cv.loadBalancingCriteria_func; end
    try; ana_args.statmap_args.cv.loadBalancingCriteria_args; catch; ...
            ana_args.statmap_args.cv.loadBalancingCriteria_args = cv.loadBalancingCriteria_args; end
    
    % Create maps and masks
    try; ana_args.statmap_func; catch; ana_args.statmap_func = []; end
    try; ana_args.statmap_args; catch; ana_args.statmap_args = []; end
    if ~isempty(ana_args.statmap_func)
        subj = runStatmapsLegacy(subj, ana_args.statmap_func, ana_args.statmap_args);
    end
    
    
    % ---------------------------------------------------------------------
    % Learn model
    results = runCrossValidation(subj, ana_args.class_args);
    
    
    % ---------------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
