% -------------------------------------------------------------------------
% Using settings.rfe:
% Classifies with recursive feature elimination
function [results, cancelThisSubject] = classifyRFE(subj, settings)
    
end



	% (7) classify with recursive feature elimination (RFE)
    s.fileOut = 'rfe';
		s.ana_func = @classifyRFE
		s.ana_args.overallRepetitions = 1;
		s.ana_args.minPatternsPerClass = 2;
		s.ana_args.pruningFraction = 0.1;
		
		s.ana_args.inner_scoring_args.init_func = @init_svm;
		s.ana_args.inner_scoring_args.train_func = @train_svm;
		
		%s.ana_args.inner_class_args.init_func = 'init_svm';
		s.ana_args.inner_class_args.train_func  = 'train_gnb';
		s.ana_args.inner_class_args.test_func = 'test_gnb';
		s.ana_args.inner_class_args.kernel_type = 0;
		s.ana_args.innerSetSize = 30; % may be large because only for feature selection
		s.ana_args.innerFoldwiseBalancingType = 0;   % 0=none 1=deletion 2=duplication
		s.ana_args.innerFoldwiseExclusion = [1 1];  % default: [0 0]
		
		s.ana_args.nTopVoxels = 300;
		s.ana_args.outer_class_args.init_funct_name = 'init_svm';
		s.ana_args.outer_class_args.train_funct_name = 'train_svm';
		s.ana_args.outer_class_args.test_funct_name = 'test_svm';
		s.ana_args.outer_class_args.kernel_type = 0; % 0=linear, 1=polynomial
		s.ana_args.outer_class_args.coef_lin = 1;
		s.ana_args.outer_class_args.coef_const = 1;
		s.ana_args.outer_class_args.poly_degree = 2;
		s.ana_args.outerSetSize = 10; % should ideally be 1 but computationally expensive
		s.ana_args.outerFoldwiseBalancingType = 0;   % 0=none 1=deletion 2=duplication
		s.ana_args.outerFoldwiseBalancingRepetitions = 1;
		s.ana_args.outerFoldwiseExclusion = [1 1];  % default: [0 0]
		s.ana_args.outerTestFilter = '';  % default: ''
		
		s.postprocessing_func = [];
		s.postprocessing_args = [];
		
