% Training function for the GMM classifier.
%
% See 'train_wrapper' interface.
%

% Jean Daunizeau
% -------------------------------------------------------------------------
function [acts scratch] = test_gmm(testpats, nClasses, scratch, args)

    % Set up parameters
    y = testpats;
    options = [];
    K = nClasses;
    n = size(testpats,2);
    
    if ~isempty(scratch)
        % Normal classification mode
        options.priors.etaHat = scratch.etaHat;
        options.priors.V = scratch.V;
        options.priors.a_gamma = scratch.a_gamma;
        options.priors.b_gamma = scratch.b_gamma;
    else
        % Clustering mode
        options = [];
    end
    
    % Test
    stop = 0;
    it = 1;
    while ~stop
        [xi,eta,F,theta,K_opt] = VBEM_GM(y,K,options);
        
        % Check results
        if size(xi,2) < 2
            if it == 10;
                error('killed components!')
            end
        else
            stop = 1;
        end
        it = it+1;
    end
    acts = xi';
end