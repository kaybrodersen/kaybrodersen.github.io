% Prediction by cross-validation with statmap feature selection.
% 
% This function operates in LEGACY mode (Princeton SUBJ format).
% 
% Implements the 'analysis_wrapper' interface.
% 
% Additional named arguments:
%   ana_args.scoring_func
%   ana_args.scoring_args

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaPredictStatmap.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaPredictStatmap(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && ~any(settings.legacy)), 'legacy settings expected');
    
    % Designate output file
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    % Make subj compatible with Princeton 'subj' structure [legacy format]
    legacy_subj = init_subj('EXP','SUBJ');
    subj = mergestructs(subj, legacy_subj);
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try ana_args.loadTrainLabels_func; catch; ana_args.loadTrainLabels_func = settings.loadTrainLabels_func; end
    try ana_args.loadTrainLabels_args; catch; ana_args.loadTrainLabels_args = settings.loadTrainLabels_args; end
    try ana_args.loadTestLabels_func; catch; ana_args.loadTestLabels_func = settings.loadTestLabels_func; end
    try ana_args.loadTestLabels_args; catch; ana_args.loadTestLabels_args = settings.loadTestLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(ana_args.loadTrainLabels_func));
    loadTestLabels_func_actual = str2func(func2str(ana_args.loadTestLabels_func));
    subj.nClasses = max([loadTrainLabels_func_actual(), loadTestLabels_func_actual()]);
    
    % Load labels (positive integers for normal trials; NaN for trials that
    % are to be ignored).
    subj.labels_train = loadLabels_wrapper(subj, ...
        ana_args.loadTrainLabels_func, ana_args.loadTrainLabels_args);
    subj.labels_test = loadLabels_wrapper(subj, ...
        ana_args.loadTestLabels_func, ana_args.loadTestLabels_args);
    if ~nanequals(subj.labels_train, subj.labels_test)
        out(['WARNING: Note that training labels and test labels are not identical!']);
    end
    
    % Ignore trials where train or test label is NaN
    subj.labels_train(isnan(subj.labels_train) | isnan(subj.labels_test)) = NaN;
    subj.labels_test(isnan(subj.labels_train) | isnan(subj.labels_test)) = NaN;
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj, ana_args.invertFilter, ...
        length(subj.labels_train), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels_train(~tmpFilter) = NaN;
    subj.labels_test(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    if ana_args.randomizeLabels>0
        subj.labels_test = subj.labels_train;
    end
    
    
    % ---------------------------------------------------------------------
    % Load mask [legacy]
    try ana_args.loadMask_func; catch; ana_args.loadMask_func = settings.loadMask_func; end
    try ana_args.loadMask_args; catch; ana_args.loadMask_args = settings.loadMask_args; end
    subj = loadMaskLegacy_wrapper(subj, ana_args.loadMask_func, ana_args.loadMask_args);
    
    
    % ---------------------------------------------------------------------
    % Load data [legacy]
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    try ana_args.loadTestData_func; catch; ana_args.loadTestData_func = settings.loadTestData_func; end
    try ana_args.loadTestData_args; catch; ana_args.loadTestData_args = settings.loadTestData_args; end
    
    loadData_scratch = [];
    [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
        ana_args.loadTestData_func, ana_args.loadTestData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    
    
    % ---------------------------------------------------------------------
    % Check dimensionality
    mat_train = get_mat(subj, 'pattern', 'data_train');
    mat_test = get_mat(subj, 'pattern', 'data_test');
    
    if ~all(size(mat_train)==size(mat_test))
        out(['ABORT: training and test data have a different dimensionality']);
        out(['    mat_train: ', mat2str(size(mat_train))]);
        out(['    mat_test:  ', mat2str(size(mat_test))]);
        return;
    end
    
    % Warn if features have NaN in some trial
    badFeatures = any(isnan(mat_train),2) | any(isnan(mat_test),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value']);
    end
    
    % Exclude all trials with a NaN in some feature (set their labels to 0)
    badTrials = any(isnan(mat_train),1) | any(isnan(mat_test),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' trials have at least one NaN feature and will be ignored']);
        subj.labels_train(badTrials) = NaN;
        subj.labels_test(badTrials) = NaN;
    end
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args, ...
        'paired_data', true);
    
    
    % ---------------------------------------------------------------------
    % Last preparations
    tmpMatSize = get_objfield(subj, 'pattern', 'data_train', 'matsize');
    subj.nFeatures = tmpMatSize(1);
    subj.nExamples = tmpMatSize(2);
    
    % Print some information about the mask
    tmpMask = get_object(subj, 'mask', 'the_mask');
    nVoxelsMask = sum(sum(sum(tmpMask.mat~=0)));
    out(['There are ', num2str(nVoxelsMask), ' voxels in this mask.']);
    
    % Final data check
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create (outer) cross-validation folds
    cv = ana_args.cv;
    
    % Set balancing criteria
    try; try cv.loadBalancingCriteria_func; catch; cv.loadBalancingCriteria_func = settings.loadBalancingCriteria_func; end;
    catch; cv.loadBalancingCriteria_func = []; end
    try; try cv.loadBalancingCriteria_args; catch; cv.loadBalancingCriteria_args = settings.loadBalancingCriteria_args; end;
    catch; cv.loadBalancingCriteria_args = []; end
    cv.balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
        cv.loadBalancingCriteria_func, cv.loadBalancingCriteria_args);
    
    % Load block filter
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    
    % Create CV folds
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create statmaps and masks (e.g., searchlight analysis)
    
    % Set balancing criteria
    try; ana_args.statmap_args.cv.loadBalancingCriteria_func; catch; ...
            ana_args.statmap_args.cv.loadBalancingCriteria_func = cv.loadBalancingCriteria_func; end
    try; ana_args.statmap_args.cv.loadBalancingCriteria_args; catch; ...
            ana_args.statmap_args.cv.loadBalancingCriteria_args = cv.loadBalancingCriteria_args; end
    
    % Create maps and masks
    subj = runStatmapsLegacy(subj, ana_args.statmap_func, ana_args.statmap_args);
    
    
    % -----------------------------------------------------------------
    % Prediction by (outer) cross-validation
    try; ana_args.runcv_func; catch; ana_args.runcv_func = @runCrossValidation; end
    runcv_func_actual = str2func(func2str(ana_args.runcv_func));
    results = runcv_func_actual(subj, ana_args.class_args, ...
        'maskgroup', 'statmap_mask');
    
    
    % -----------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
