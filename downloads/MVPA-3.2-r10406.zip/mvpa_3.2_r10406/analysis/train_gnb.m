% Training function for a GNB classifier.
%
% See 'train_wrapper' interface.
%
% Use a Gaussian Naive Bayes classifier to learn regressors.
%
% [SCRATCH] = TRAIN_GNB(TRAINPATS, TRAINTARGS, IN_ARGS, CV_ARGS)
%
% The Gaussian Naive Bayes classifier makes the assumption that
% each data point is conditionally independent of the others, given
% a class label, and that, furthermore, the likelihood function for
% each class is normal.  The likelihood of a given data point X,
% where Y is one of K labels, is thus:
%
% Pr ( X | Y==K) = Product_N ( Normal(X_N | theta_K) ) 
% 
% The GNB is trained by finding the Normal MLE's for each subset of
% the training set that have the same label.  Each voxel has a
% scalar mean and a scalar variance.
%
% OPTIONAL ARGUMENTS:
%
% UNIFORM_PRIOR (default = true): If uniform_prior is true,
% then the algorithm will assume that no classes are
% inherently more likely than others, and will use 1/K as
% the prior probability for each of K classes.  If
% uniform_prior is false, then train_gnb will estimate the
% priors from the data using laplace smoothing: if N_k is
% the number of times class k is observed in the training
% set and N is the total number of training datapoints, then
% Pr(Y == k) = (N_k + 1) / (N + K).  This way, no cluster is
% ever assigned a 0 prior.

% Adapted from the MVPA toolbox.
% $Id: train_gnb.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scratch = train_gnb(trainpats, labels, nClasses, args)
    
    % Process inputs
    defaults.uniform_prior = true;
    args = mergestructs(args, defaults);
    trainregs = makeRegressorsMatrix(labels, true);
    [nVox nTimepoints] = size(trainpats);
    
    % Check inputs
    args = sanity_check(trainpats, labels, nClasses, args);
    
    % Find a gaussian distribution for each voxel for each category
    scratch.mu = NaN(nVox, nClasses);
    scratch.sigma = NaN(nVox, nClasses);
    
    for k = 1:nClasses
        
        % Grab the subset of the data with a label of category k
        k_idx = find(trainregs(k, :) == 1);
        
        if numel(k_idx) < 1
            error('Condition %g has no data points.', k);
        end
        
        data = trainpats(:, k_idx);
        
        % Calculate the maximum likelihood estimators (mean and variance)
        [mu_hat, sigma_hat] = normfit(data');
        
        scratch.mu(:,k) = mu_hat;
        scratch.sigma(:,k) = sigma_hat;
    end
    
    % Calculate the priors based on occurence in the training set
    scratch.prior = NaN(nClasses, 1);
    if (args.uniform_prior)
        scratch.prior = ones(nClasses,1) / nClasses;
    else
        for k = 1:nClasses  
            scratch.prior(k) = (1 + numel( find(trainregs(k, :) == 1))) / ...
                (nClasses + nTimepoints);    
        end
    end
    scratch.nClasses = nClasses;

end

% -------------------------------------------------------------------------
function args = sanity_check(trainpats, labels, nClasses, args)
    
    if any(isnan(trainpats))
        error('there are NaN values in the data');
    end
end
