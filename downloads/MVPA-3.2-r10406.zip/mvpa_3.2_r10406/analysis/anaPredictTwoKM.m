% Prediction without any feature selection, training on one set of
% trials and testing on another set of trials (no cross-validation).
% This is the kernel-matrix variant of anaPredictTwo. Rather than dealing
% with examples and features, it operates on a big kernel matrix.
% 
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaPredictTwoKM.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaPredictTwoKM(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && any(settings.legacy)), 'non-legacy settings expected');
    
    % Designate output file
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try ana_args.loadTrainLabels_func; catch; ana_args.loadTrainLabels_func = settings.loadTrainLabels_func; end
    try ana_args.loadTrainLabels_args; catch; ana_args.loadTrainLabels_args = settings.loadTrainLabels_args; end
    try ana_args.loadTestLabels_func; catch; ana_args.loadTestLabels_func = settings.loadTestLabels_func; end
    try ana_args.loadTestLabels_args; catch; ana_args.loadTestLabels_args = settings.loadTestLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(ana_args.loadTrainLabels_func));
    loadTestLabels_func_actual = str2func(func2str(ana_args.loadTestLabels_func));
    subj.nClasses = max([loadTrainLabels_func_actual(), loadTestLabels_func_actual()]);
    
    % Load labels (positive integers for normal trials; NaN labels for
    % trials that are to be ignored).
    subj.labels_train = loadLabels_wrapper(subj, ...
        ana_args.loadTrainLabels_func, ana_args.loadTrainLabels_args);
    subj.labels_test = loadLabels_wrapper(subj, ...
        ana_args.loadTestLabels_func, ana_args.loadTestLabels_args);
    
    % Trial filtering not implemented
    assert(~isfield(ana_args,'loadFilter_func') || isempty(ana_args.loadFilter_func), ...
        'trial filtering not implemented');
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    if ana_args.randomizeLabels>0
        subj.labels_test = subj.labels_train;
    end
    
    
    % ---------------------------------------------------------------------
    % Load data
    % First load training data into subj.data_train (e.g. matrix FEATURES x EXAMPLES_TRAIN)
    % Then load test data and produce kernel matrix subj.K (EXAMPLES x EXAMPLES)
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    try ana_args.loadTestData_func; catch; ana_args.loadTestData_func = settings.loadTestData_func; end
    try ana_args.loadTestData_args; catch; ana_args.loadTestData_args = settings.loadTestData_args; end
    
    loadData_scratch.data_train = [];
    [~,loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj.K, loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTestData_func, ana_args.loadTestData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    assert(ndims(subj.K)==2 && size(subj.K,1)==size(subj.K,2), 'invalid kernel matrix');
    assert(size(subj.K,1)==length(subj.labels_train)+length(subj.labels_test), 'kernel matrix dimension mismatch');
    subj.nExamples = size(subj.K,1);
    
    
    % ---------------------------------------------------------------------
    % Remove all trials with a NaN somewhere in the kernel matrix
    badTrials = any(isnan(subj.K),1);
    badTrials_train = badTrials(1:length(subj.labels_train));
    n = sum(badTrials_train);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badTrials_train)), ...
            ') training trials have at least one NaN value in the kernel matrix and will be ignored']);
        subj.labels_train(badTrials_train) = NaN;
    end
    badTrials_test = badTrials(length(subj.labels_train)+1:end);
    n = sum(badTrials_test);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badTrials_test)), ...
            ') test trials have at least one NaN value in the kernel matrix and will be ignored']);
        subj.labels_test(badTrials_test) = NaN;
    end
    
    
    % ---------------------------------------------------------------------
    % Create single outer fold (or several if blocks structure) in which
    % the training set and test set simply contain all respective trials.
    cv = ana_args.cv;
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    cv.bSinglePeekingFoldOnly = true;
    cv.bSinglePeekingFoldOnly_labels_test = subj.labels_test;
    cv.setSize = 1;
    cv.verbose = 0;
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    % Shift test indices in subj.folds
    for f = 1:length(subj.folds)
        subj.folds(f).test = length(subj.labels_train) + subj.folds(f).test;
        assert(~any(subj.folds(f).test>length(subj.labels_train)+length(subj.labels_test)));
    end
    
    % Concatenate train and test trials
    subj.labels = [subj.labels_train, subj.labels_test];
    subj = rmfield(subj, 'labels_train');
    subj = rmfield(subj, 'labels_test');
    
    
    % ---------------------------------------------------------------------
    % Classification by a single train/test run (unless blocks structure)
    % (kernel-matrix version)
    results = runCrossValidationKM(subj, ana_args.class_args);
    
    
    % ---------------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
