% Prepare the command string for libsvm.

% Usage:
%     str = cmdtest_libsvm(pars, values);

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function str = cmdtest_libsvm(pars, values)
    
    str = '';
    
end
