% Simple wrapper that creates a weight for each voxel, using the specified
% weight function (e.g., training an SVM and reconstructing the weights).
% There is no cross-validation and no looping over voxels or searchlights.
% 
% This function is intended to be passed as statmap_func to anaCreateStatmap.
% 
% This function operates in LEGACY mode.
% 
% Usage:
%     statmap_whole(subj, fold, new_mapname, statmap_args)
% 
% Arguments:
%     subj: Princeton subj struct that contains a Princeton pattern called
%         'data_train', and a field subj.adj_list.
%     outerFold: a single object from a subj.folds() struct array
%         containing a .train field
%     new_mapname: name of the map to be created
%     statmap_args: additional custom arguments
% 
% Custom fields in statmap_args:
%     'weight_func' (required) The weight function
%     'weight_args' (optional) Additional arguments for the weight function

% Kay H. Brodersen, ETHZ/UZH
% $Id: statmap_whole.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = statmap_whole(subj, outerFold, new_mapname, statmap_args)
    
    % Check input
    defaults.weight_func = [];
    defaults.weight_args = [];
    args = propval(statmap_args, defaults, 'strict', false);
    if isempty(args.weight_func)
        error('weight function (weight_func) required');
    end
    try subj.labels_train; catch; subj.labels_train = subj.labels; end
    
    
    % -------------------------------------------------------------
    % Get data and labels (outer training set)
    mat_train = get_mat(subj, 'pattern', 'data_train');
    mat_train = mat_train(:, outerFold.train);
    labels_train = subj.labels_train(outerFold.train);
    assert(size(mat_train,2)==length(labels_train));
    
    % Prepare weight function and args
    weight_func_actual = str2func(func2str(args.weight_func));
    try weight_args = args.weight_args; catch; weight_args = []; end
    
    % Create map by invoking the weight function
    map = weight_func_actual(mat_train, labels_train, weight_args);
    assert(all(size(map)==[size(mat_train,1) 1]));
    
    % ---------------------------------------------------------------------
    % Add map to the SUBJ structure as a new pattern
    masked_by = get_objfield(subj, 'pattern', 'data_train', 'masked_by');
    subj = initset_object(subj, 'pattern', new_mapname, map, 'masked_by', masked_by);
    
end
