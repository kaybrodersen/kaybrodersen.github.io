% Creates a boolean mask including some subset of voxels. The actual
% selection of features will be carried out by a custom function
% select_func, equipped with custom arguments select_args.
%
% This function operates in legacy mode.
% 
% Usage:
%     subj = deriveMasksLegacy(subj, mapname, maskname, ...
%         select_func, select_args)
%
% Arguments:
%     subj: Princeton subj struct
%     mapname: name of the Princeton pattern object (i.e., a statmap)
%     maskname: name of the mask to be created
%     maskgroupname: name of the group of masks that the new masks belongs to
%     select_func: custom function for feature selection
%     select_args: custom arguments
% 
% This function is essentially a wrapper for a select_func
% function. The interface is:
% 
% maskvec = select_func(pat.., select_args)
%
% with:
%     pat: vector of feature scores
%     select_args: custom arguments
%     maskvec: returned boolean vector of selected voxels

% Adapted from the MVPA toolbox.
% Kay H. Brodersen, ETHZ/UZH
% $Id: deriveMasksLegacy.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = deriveMasksLegacy(subj, mapname, maskname, maskgroupname, ...
    select_func, select_args)
    
    % Get map
    pat = get_mat(subj, 'pattern', mapname);
    if size(pat,2)~=1
        error('Can''t create a mask from a pat with a time dimension');
    end

    % For reference, get original mask
    mask_for_pat = get_objfield(subj, 'pattern', mapname, 'masked_by');
    oldmask = get_mat(subj, 'mask', mask_for_pat);
    
    % Create a new mask with the same dimensions
    subj = duplicate_object(subj, 'mask', mask_for_pat, maskname);
    
    % Augment custom arguments
    assert(~isfield(select_args, 'adj_list'), ...
        'select_args should not contain a custom field named ''adj_list'' as this is a reserved field');
    if isfield(subj, 'adj_list')
        select_args.adj_list = subj.adj_list;
    end
    
    % Call custom function to get maskvec
    out(['Feature selection deriving ', maskname, ' from ', mapname]);
    out(['using function ''', func2str(select_func), '''']);
    
    if all(isnan(pat))
        out(['WARNING: all voxels have a NaN score - mask will be empty']);
        maskvec = zeros(size(pat));
    else
        select_func_actual = str2func(func2str(select_func));
        maskvec = select_func_actual(pat, select_args);
    end
    
    % Check maskvec
    out(['Selected ', num2str(sum(maskvec)), ' voxels']);
    assert(size(maskvec,1)==size(pat,1) && size(maskvec,2)==size(pat,2), ...
        'returned maskvec has wrong size');
    assert(all(maskvec==1 | maskvec==0), 'returned maskvec must only contain 0s and 1s');
    
    % OLDMASK is a mask volume. We want NEWMASK to be in the same space
    newmask = zeros(size(oldmask));
    
    % Mark 1s in the right places in the NEWMASK boolean volume for each
    % of the suprathreshold voxels active in the boolean MASKVEC vector
    newmask(find(oldmask)) = maskvec;
    
    % Save to the mask
    subj = set_mat(subj, 'mask', maskname, newmask);
    subj = set_objfield(subj, 'mask', maskname, 'group_name', maskgroupname);
    
    % Update the header
    created.function = 'deriveMasksLegacy';
    created.dbstack = dbstack;
    created.map_patname = mapname;
    subj = add_created(subj,'mask', maskname, created);
    
end
