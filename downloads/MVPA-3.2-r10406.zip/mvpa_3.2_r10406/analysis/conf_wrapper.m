% Wrapper function for configuring a classifier.
% 
% Callee interface:
%     [train_args, test_args] = conf_func(train_args, test_args, conf_args, ...)
% 
% Any varargin will be passed on for consumption by conf_func.

% Kay H. Brodersen, ETHZ/UZH
% $Id: conf_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [train_args, test_args] = conf_wrapper(train_args, test_args, ...
    conf_func, conf_args, varargin)
    
    % Run configuration
    if ~isempty(conf_func)
        conf_func_actual = str2func(func2str(conf_func));
        [train_args, test_args] = conf_func_actual(train_args, test_args, ...
            conf_args, varargin{:});
    end
    
end
