% Test function for LIBMSVM.
%
% Usage:
%     [preds, scratch] = test_libsvm(mat_test, scratch)
%
% Input parameters:
%     scratch: scratch as returned by the training function (contains, in
%         particular, the model that the classifier learned during training)
%
% Custom arguments:
%     libsvm_options: options string for svmpredict

% Kay H. Brodersen, ETHZ/UZH
% $Id: test_libsvm.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [preds, scratch] = test_libsvm(mat_test, scratch, args)
    
    % Check input
    defaults.libsvm_options = '';
    args = mergestructs(args, defaults);
    assert(~any(any(isnan(mat_test))), 'there are NaN values in the data');
    
    % Test
    % (svmpredict wants the test labels so it can compute the error, but
    % this is not good programming practice. Here we prefer keeping the
    % interface clean: the test function is not given access to test
    % labels. We will do the comparison later. Thus, we feed in
    % zero-labels.
%     [predicted_labels, accuracies, decision_values] = svmpredict(...
%         ones(size(mat_test, 2),1), ...
%         mat_test',...
%         scratch.model, ...
%         args.libsvm_options);
    [~, preds, corrects, decision_values] = evalc(['svmpredict(', ...
        'ones(size(mat_test, 2),1), mat_test'', scratch.model, args.libsvm_options);']);

    % Transform labels from [1 -1] to [1 2]
    assert(containsOnly(preds, [-1 1]));
    preds(preds==-1) = 2;
    
    % Also return decision_values
    scratch.dvs = decision_values;
    
end
