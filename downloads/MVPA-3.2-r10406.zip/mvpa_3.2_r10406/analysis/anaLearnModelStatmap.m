% Learns a prediction model based on a statmap mask. While the mask is
% created using proper inner cross-validation (or any method), final
% classification is done on the whole set (peeking), to get the empirical
% training error. 
% 
% Unlike anaLearnModel, this function operates in LEGACY mode (Princeton
% SUBJ format).
% 
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaLearnModelStatmap.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaLearnModelStatmap(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && ~any(settings.legacy)), 'legacy settings expected');
    
    % Designate output file
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    % Make subj compatible with Princeton 'subj' structure [legacy format]
    legacy_subj = init_subj('EXP','SUBJ');
    subj = mergestructs(subj, legacy_subj);
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try ana_args.loadTrainLabels_func; catch; ana_args.loadTrainLabels_func = settings.loadTrainLabels_func; end
    try ana_args.loadTrainLabels_args; catch; ana_args.loadTrainLabels_args = settings.loadTrainLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(ana_args.loadTrainLabels_func));
    subj.nClasses = loadTrainLabels_func_actual();
    
    % Load labels (NaN for trials to be ignored)
    subj.labels_train = loadLabels_wrapper(subj, ...
        ana_args.loadTrainLabels_func, ana_args.loadTrainLabels_args);
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj, ana_args.invertFilter, ...
        length(subj.labels_train), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels_train(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    
    
    % ---------------------------------------------------------------------
    % Load mask [legacy]
    try ana_args.loadMask_func; catch; ana_args.loadMask_func = settings.loadMask_func; end
    try ana_args.loadMask_args; catch; ana_args.loadMask_args = settings.loadMask_args; end
    subj = loadMaskLegacy_wrapper(subj, ana_args.loadMask_func, ana_args.loadMask_args);
    
    
    % ---------------------------------------------------------------------
    % Load data [legacy]
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    
    loadData_scratch = [];
    [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    
    
    % ---------------------------------------------------------------------
    % Remove all features with a NaN in some trial
    mat_train = get_mat(subj, 'pattern', 'data_train');
    mat_test = get_mat(subj, 'pattern', 'data_test');
    
    badFeatures = any(isnan(mat_train),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value']);
    end
    
    % Exclude all examples with a NaN in some feature (set their labels to NaN)
    badTrials = any(isnan(mat_train),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' examples have at least one NaN feature and will be ignored']);
        subj.labels_train(badTrials) = NaN;
    end
    
    % For compatibility reasons, set test labels
    subj.labels_test = subj.labels_train;
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args, ...
        'paired_data', true);
    
    
    % ---------------------------------------------------------------------
    % Last preparations
    tmpMatSize = get_objfield(subj, 'pattern', 'data_train', 'matsize');
    subj.nFeatures = tmpMatSize(1);
    subj.nExamples = tmpMatSize(2);
    
    % Print some information about the mask
    tmpMask = get_object(subj, 'mask', 'the_mask');
    nVoxelsMask = sum(sum(sum(tmpMask.mat~=0)));
    out(['There are ', num2str(nVoxelsMask), ' voxels in this mask.']);
    
    % Final data check
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Debug
    try ana_args.debug_func; catch; ana_args.debug_func = []; end
    try ana_args.debug_args; catch; ana_args.debug_args = []; end
    [~, args] = debug_wrapper(subj, settings, ana_args.debug_func, ana_args.debug_args, []);
    
    
    % ---------------------------------------------------------------------
    % Create single outer fold (or several if blocks structure) in which
    % all trials are in the training set, and none in the test set.
    cv = ana_args.cv;
    cv.bSinglePeekingFoldOnly = true;
    cv.setSize = 1;
    
    % Set balancing criteria
    try; try cv.loadBalancingCriteria_func; catch; cv.loadBalancingCriteria_func = settings.loadBalancingCriteria_func; end;
    catch; cv.loadBalancingCriteria_func = []; end
    try; try cv.loadBalancingCriteria_args; catch; cv.loadBalancingCriteria_args = settings.loadBalancingCriteria_args; end;
    catch; cv.loadBalancingCriteria_args = []; end
    cv.balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
        cv.loadBalancingCriteria_func, cv.loadBalancingCriteria_args);
    
    % Load block filter
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    
    % Create CV folds
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create statmaps and masks (e.g., searchlight analysis) (optional)
    
    % Set balancing criteria
    try; ana_args.statmap_args.cv.loadBalancingCriteria_func; catch; ...
            ana_args.statmap_args.cv.loadBalancingCriteria_func = cv.loadBalancingCriteria_func; end
    try; ana_args.statmap_args.cv.loadBalancingCriteria_args; catch; ...
            ana_args.statmap_args.cv.loadBalancingCriteria_args = cv.loadBalancingCriteria_args; end
    
    % Create maps and masks
    try; ana_args.statmap_func; catch; ana_args.statmap_func = []; end
    try; ana_args.statmap_args; catch; ana_args.statmap_args = []; end
    if ~isempty(ana_args.statmap_func)
        subj = runStatmapsLegacy(subj, ana_args.statmap_func, ana_args.statmap_args);
    end
    
    
    % ---------------------------------------------------------------------
    % Learn model
    results = runCrossValidation(subj, ana_args.class_args, ...
        'maskgroup', 'statmap_mask');
    
    
    % ---------------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
