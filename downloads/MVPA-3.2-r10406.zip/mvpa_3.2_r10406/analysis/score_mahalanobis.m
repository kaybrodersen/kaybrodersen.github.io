% Computes the (squared) Mahalanobis distance for the current searchlight,
% based on the data from the current outer fold.
%
% Usage:
%     d2 = statmap_mahalanobis(mat, labels, args)
% 
% Return values:
%     d2: Mahalanobis distance

% Kay H. Brodersen, ETHZ/UZH
% $Id: score_mahalanobis.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function d2 = statmap_mahalanobis(mat, labels, args)
    
    % Compute Mahalanobis distance
    X1 = mat(:,labels==1)';  % EXAMPLES x VARIABLES
    X2 = mat(:,labels==2)';  % EXAMPLES x VARIABLES
    d2 = groupmahal(X1,X2);
    
end
