% Prediction without any feature selection, training on one set of
% trials and testing on another set of trials (no cross-validation).
%
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaPredictTwo.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaPredictTwo(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && any(settings.legacy)), 'non-legacy settings expected');
    
    % Designate output file
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try ana_args.loadTrainLabels_func; catch; ana_args.loadTrainLabels_func = settings.loadTrainLabels_func; end
    try ana_args.loadTrainLabels_args; catch; ana_args.loadTrainLabels_args = settings.loadTrainLabels_args; end
    try ana_args.loadTestLabels_func; catch; ana_args.loadTestLabels_func = settings.loadTestLabels_func; end
    try ana_args.loadTestLabels_args; catch; ana_args.loadTestLabels_args = settings.loadTestLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(ana_args.loadTrainLabels_func));
    loadTestLabels_func_actual = str2func(func2str(ana_args.loadTestLabels_func));
    subj.nClasses = max([loadTrainLabels_func_actual(), loadTestLabels_func_actual()]);
    
    % Load labels (positive integers for normal trials; NaN labels for
    % trials that are to be ignored).
    subj.labels_train = loadLabels_wrapper(subj, ...
        ana_args.loadTrainLabels_func, ana_args.loadTrainLabels_args);
    subj.labels_test = loadLabels_wrapper(subj, ...
        ana_args.loadTestLabels_func, ana_args.loadTestLabels_args);
    if ~nanequals(subj.labels_train(1:min([length(subj.labels_train),length(subj.labels_test)])), ...
            subj.labels_test(1:min([length(subj.labels_train),length(subj.labels_test)])))
        out(['NOTE: Note that training labels and test labels are not identical!']);
    end
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj.dirScan, ana_args.invertFilter, ...
        length(subj.labels_train), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels_train(~tmpFilter) = NaN;
    subj.labels_test(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    if ana_args.randomizeLabels>0
        subj.labels_test = subj.labels_train;
    end
    
    
    % ---------------------------------------------------------------------
    % Load data
    % into subj.data_train (FEATURES x EXAMPLES_TRAIN)
    % into subj.data_test  (FEATURES x EXAMPLES_TEST)
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    try ana_args.loadTestData_func; catch; ana_args.loadTestData_func = settings.loadTestData_func; end
    try ana_args.loadTestData_args; catch; ana_args.loadTestData_args = settings.loadTestData_args; end
    
    loadData_scratch = [];
    [subj.data_train, loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj.data_test, loadData_scratch] = loadData_wrapper(subj, ...
        ana_args.loadTestData_func, ana_args.loadTestData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    
    out(' ');
    out(['Raw data:']);
    out(['    data_train: ', mat2str(size(subj.data_train)), ...
        ' (checksum ', num2str(nansum(nansum(subj.data_train))), ')']);
    out(['    data_test:  ', mat2str(size(subj.data_test)), ...
        ' (checksum ', num2str(nansum(nansum(subj.data_test))), ')']);
    if size(subj.data_train,1) ~= size(subj.data_test,1)
        error(['data_train and data_test must not have different numbers of features']);
    end
    if (ndims(subj.data_train)==ndims(subj.data_test)) && ...
            all(size(subj.data_train)==size(subj.data_test)) && ...
            nanequals(subj.data_train, subj.data_test)
        out(' ');
        out(['WARNING: data_train and data_test are identical - are you sure?']);
    end
    
    
    % ---------------------------------------------------------------------
    % Load masks (optional)
    try; try ana_args.loadTrainMask_func; catch; ana_args.loadTrainMask_func = settings.loadTrainMask_func; end;
    catch; ana_args.loadTrainMask_func = []; end
    try; try ana_args.loadTestMask_func; catch; ana_args.loadTestMask_func = settings.loadTestMask_func; end;
    catch; ana_args.loadTestMask_func = []; end
    if ~isempty(ana_args.loadTrainMask_func)
        subj.mask_train = loadMask_wrapper(subj, ...
            ana_args.loadTrainMask_func, ana_args.loadTrainMask_args);
    else
        subj.mask_train = [];
    end
    if ~isempty(ana_args.loadTestMask_func)
        subj.mask_test = loadTestMask_wrapper(subj, ...
            ana_args.loadTestMask_func, ana_args.loadTestMask_args);
    else
        subj.mask_test = [];
    end
    
    % ---------------------------------------------------------------------
    % Flatten data to FEATURES x EXAMPLES
    subj.mat_train = vol2mat(subj.data_train, subj.mask_train);
    subj.mat_test = vol2mat(subj.data_test, subj.mask_test);
    subj = rmfield(subj, 'data_train');
    subj = rmfield(subj, 'data_test');
    
    
    % ---------------------------------------------------------------------
    % Check dimensionality
    out(' ');
    out(['Masked and flattened data:']);
    out(['    mat_train: ', mat2str(size(subj.mat_train)), ...
        ' (checksum ', num2str(nansum(nansum(subj.mat_train))), ')']);
    out(['    mat_test:  ', mat2str(size(subj.mat_test)), ...
        ' (checksum ', num2str(nansum(nansum(subj.mat_test))), ')']);
    
    % Check for bad features and remove them in both datasets
    badFeatures = any(isnan(subj.mat_train),2) | any(isnan(subj.mat_test),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value and will be ', ...
            'removed in both datasets']);
        subj.mat_train(badFeatures,:) = [];
        subj.mat_test(badFeatures,:) = [];
        assert(size(subj.mat_train,1)==size(subj.mat_test,1));
    end
    
    % Check for bad trials and remove them (set their label to NaN)
    badTrials_train = any(isnan(subj.mat_train),1);
    n = sum(badTrials_train);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' train trials have at least one NaN feature and will be ignored']);
        subj.labels_train(badTrials_train) = NaN;
    end
    %
    badTrials_test = any(isnan(subj.mat_test),1);
    n = sum(badTrials_test);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' test trials have at least one NaN feature and will be ignored']);
        subj.labels_test(badTrials_test) = NaN;
    end
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args, ...
        'paired_data', false);
    
    
    % ---------------------------------------------------------------------
    % Final preparations
    subj.nFeatures_train = size(subj.mat_train,1);
    subj.nExamples_train = size(subj.mat_train,2);
    subj.nFeatures_test = size(subj.mat_test,1);
    subj.nExamples_test = size(subj.mat_test,2);
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create single outer fold (or several if blocks structure) in which
    % the training set and test set simply contain all respective trials.
    cv = ana_args.cv;
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    cv.bSinglePeekingFoldOnly = true;
    cv.bSinglePeekingFoldOnly_labels_test = subj.labels_test;
    cv.setSize = 1;
    cv.verbose = 0;
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Classification by a single train/test run (unless blocks structure)
    results = runCrossValidation(subj, ana_args.class_args);
    
    
    % ---------------------------------------------------------------------
    % Save results
    filestem = ['pred', num2str(settings.analysisId)];
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
