% Training function for logistic regression.
%
% See 'train_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: train_logreg.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scratch = train_logreg(mat_train, labels_train, nClasses, args)
    
%     % Check input
%     defaults.libsvm_options = '';
%     args = mergestructs(args, defaults);
    assert(~any(any(isnan(mat_train))), 'there are NaN values in the data');
    assert(nClasses==2, 'libsvm cannot deal with anything but 2 classes');
    assert(containsOnly(labels_train, [1 2]), 'labels must be 1s and 2s');
    
    % Transform labels from [1 2] to [1 0]
    labels_train(labels_train==2) = 0;
    
    % Train
    model.B = glmfit(mat_train', [labels_train', ones(length(labels_train),1)], 'binomial', 'link', 'logit');
    
    % Return model (needed for test)
    assert(~isempty(model), 'returned model is empty');
    scratch.model = model;
    
    % Return other interesting things (for recollection)
    scratch.args = args;
    
end
