% Test function for GP
%
% Usage:
%     [preds scratch] = test_gp(mat_test, nClasses, scratch)
%
% Input parameters:
%     scratch: scratch as returned by the training function (contains, in
%         particular, the model that the classifier learned during training)
%
% Custom arguments:
%     par1

% Kay H. Brodersen, ETHZ/UZH
% $Id: test_gp.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [preds, scratch] = test_gp(mat_test, nClasses, scratch, args)
    
    % Check input
    defaults.par1 = 'default...';
    args = mergestructs(args, defaults);
    
    if any(isnan(mat_test))
        error('there are NaN values in the data');
    end
    
    % Test
    [predicted_labels, accuracies, decision_values] = svmpredict(...
        ones(size(mat_test, 2),1), ...
        mat_test',...
        scratch.model, ...
        args.libsvm_options);
    
    % Transform labels from [1 -1] to [1 2]
    assert(containsOnly(preds, [-1 1]));
    preds(preds==-1) = 2;
    
    % Return stuff
    %scratch.stuff = 'stuff....';
    
end
