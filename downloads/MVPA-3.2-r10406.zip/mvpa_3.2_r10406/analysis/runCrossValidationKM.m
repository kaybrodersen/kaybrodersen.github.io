% Implements outer cross-validation. Kernel-matrix version.
%
% Supports both normal and legacy mode.
% 
% Usage:
%     results = runCrossValidationKM(subj, class_args)
%
% Arguments:
%     subj: struct with the following fields:
%         .folds: a folds struct array as created by createCvFolds
%         .K: EXAMPLES x EXAMPLES kernel matrix
%         .labels: labels
%     class_args: struct with the following fields:
%         .conf_func
%         .conf_args
%         .train_func
%         .train_args
%         .test_func
%         .test_args
% 
% Return value:
%     results: a struct with the following fields:
%         .folds(): a struct array with the following fields:
%             .targs
%             .preds
%             .scratch

% Kay H. Brodersen, ETHZ/UZH
% $Id: runCrossValidationKM.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function results = runCrossValidationKM(subj, class_args, varargin)
    
    % Check input
    try; class_args.conf_func; catch; class_args.conf_func = []; end
    try; class_args.conf_args; catch; class_args.conf_args = []; end
    try; class_args.train_args; catch; class_args.train_args = []; end
    try; class_args.test_args; catch; class_args.test_args = []; end
    
    % Initialize results
    results = struct;
    results.folds = subj.folds;
    
    
    % ---------------------------------------------------------------------
    % (0) INITIALIZE
    try class_args.init_func; catch; class_args.init_func = []; end
    try class_args.init_args; catch; class_args.init_args = []; end
    class_args = init_wrapper(class_args.init_func, class_args);
    
    
    % ---------------------------------------------------------------------
    % Run (outer) cross-validation
    nFolds = length(subj.folds);
    out(' ');
    out(['Starting cross-validation (kernel-matrix mode) with ', num2str(nFolds), ' fold(s)']);
    for f = 1:nFolds
        fold = subj.folds(f);
        out(' '); out(['FOLD ', num2str(f), ' / ', num2str(nFolds)]);
        increaseIndent;
        
        % Show overall kernel matrix
        out(['K: ', mat2str(size(subj.K))])
        
        % Set fold-specific kernel matrices
        fold_K_train = subj.K(fold.train, fold.train);    % training examples x training examples
        fold_K_test = subj.K(fold.train, fold.test);      % training examples x test examples
        out(['fold_K_train (raw): ', mat2str(size(fold_K_train))])
        out(['fold_K_test (raw):  ', mat2str(size(fold_K_test))])
        
        % Add serial examples numbers to training kernel matrix,
        % and add a fake label to test examples
        fold_K_train = [1:size(fold_K_train,2); fold_K_train];
        out(['fold_K_train (finalized): ', mat2str(size(fold_K_train))])
        fold_K_test = [zeros(1,size(fold_K_test,2)); fold_K_test];
        out(['fold_K_test (finalized):  ', mat2str(size(fold_K_test))])
        
        % Set fold-specific labels
        fold_labels_train = subj.labels(fold.train);
        fold_labels_test = subj.labels(fold.test);
        
        out(['Train indices: ', mat2str(fold.train)]);
        [types,freqs] = analyseCriterion(fold_labels_train);
        out(['    Types: ', mat2str(types)]);
        out(['    Freqs: ', mat2str(freqs)]);
        out(['Test indices: ', mat2str(fold.test)]);
        [types,freqs] = analyseCriterion(fold_labels_test);
        out(['    Types: ', mat2str(types)]);
        out(['    Freqs: ', mat2str(freqs)]);
        
        
        % -------------------------------------------------------------
        % (1) CONFIGURE (e.g., setting hyperparameters)
        [class_args.train_args, class_args.test_args] = ...
            conf_wrapper(class_args.train_args, class_args.test_args, ...
            class_args.conf_func, class_args.conf_args, ...
            'data', subj.K, ...
            'indices', fold.train, ...
            'labels', subj.labels, ...
            'nClasses', subj.nClasses);
        
        % (2) TRAIN
        class_args.train_args.nClasses = subj.nClasses;
        scratch = train_wrapper(fold_K_train, fold_labels_train, ...
            class_args.train_func, class_args.train_args);
        scratch.fold = fold;
        
        % (3) TEST
        class_args.test_args.nClasses = subj.nClasses;
        [fold_preds, scratch] = test_wrapper(fold_K_test, ...
            scratch, class_args.test_func, class_args.test_args);
        out(['Targs: ', mat2str(fold_labels_test)]);
        out(['Preds: ', mat2str(fold_preds)]);
        
        
        % -----------------------------------------------------------------
        % Store results along with indices
        results.folds(f).targs = fold_labels_test;
        results.folds(f).preds = fold_preds;
        results.folds(f).scratch = scratch;
        
        decreaseIndent;
    end % fold f
    
    
    % ---------------------------------------------------------------------
    % Show results
    out(' ');
    printResults(results, subj.nClasses); out(' ');
    
end
