% Test function for nearest-neighbour classification.
%
% Usage:
%     [preds scratch] = test_knn(mat_test, nClasses, scratch, args)
% 
% Input parameters:
%     scratch: scratch as returned by the training function
% 
% Further arguments:
%     mode: 'knn' - take majority class of k nearest neighbours
%           'nearest_class' - take the class with the highest average similarity
%     k: k in 'knn' mode

% Kay H. Brodersen, ETHZ/UZH
% $Id: test_knn.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [preds, scratch] = test_knn(mat_test, nClasses, scratch, args)
    
    % Check input
    defaults.mode = 'knn';
    defaults.k = 1;
    args = mergestructs(args, defaults);
    
    args.mode = lower(args.mode);
    assert(strcmp(args.mode,'knn') || strcmp(args.mode, 'nearest_class'));
    assert(args.k > 0);
    assert(~any(any(isnan(mat_test))), 'there are NaN values in the data');
    
    % Extract model
    mat_train = scratch.m.mat_train;
    labels_train = scratch.m.labels_train;
    
    % Compute distance matrix
    D = mat_test' * mat_train;
    % D_ij = distance between ith test sample and jth training sample
    
    % KNN mode
    if strcmp(args.mode, 'knn')
        % For each test sample, sort training samples descendingly
        [~,I] = sort(D,2,'descend');
        
        % Take k nearest neighbours
        k = min([args.k, length(I)]);
        K = I(:,1:k);
        
        % Get classes
        C = labels_train(K);
        
        % Get mean class of nearest neighbours
        dvs = mean(C,2);
        assert(all(dvs>=1) && all(dvs<=2));
        
        % Save decision_values
        scratch.dvs = dvs;
        
        % Find out and save which neighbour was closest
        if args.k==1
            if isfield(scratch, 'fold')
                for tt = 1:size(mat_test,2)
                    tmp = sort(unique([scratch.fold.train, scratch.fold.test(tt)]));
                    pos1 = find(tmp == scratch.fold.train(K));
                    pos2 = find(tmp == scratch.fold.test(tt));
                    scratch.x(tt,1) = abs(pos1-pos2);
                end
            end
        end
        
        
        % Generate predictions:
        preds = dvs;
        % 
        % - resolve ties
        preds(preds==1.5) = fix((rand(sum(preds==1.5),1)*2)+1);
        % 
        % - otherwise majority vote
        preds = round(preds);
       
    % Nearest-class mode
    elseif strcmp(args.mode, 'nearest_class')
        d1 = sum(D(:,labels_train==1),2);
        d2 = sum(D(:,labels_train==2),2);
        preds = NaN(size(d1));
        preds(d1 > d2) = 1;
        preds(d2 > d1) = 2;
        preds(isnan(preds)) = fix((rand(sum(isnan(preds)),1)*2)+1);
    end
    
    % Check return value
    assert(containsOnly(preds, [1 2]));
end
