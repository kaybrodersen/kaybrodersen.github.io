% Saves prediction results from a single subject, single cycle, to disk.
% 
% Usage:
%     file = savePredResults(subj, filestem, results, varargin)
% 
% Optional named arguments:
%     'preview' (default: false) If set to true, no results will be saved
%         (in fact, 'results' will be ignored and does not even need to be
%         passed), and the function will simply return the filename of the
%         file that would have been written. This can be used before an
%         analysis to check whether the result has already been computed
%         during an earlier analysis.
%
% Return values:
%     file: name of the file that was written / would have been written

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function file = savePredResults(subj, filestem, results, varargin)
    
    % Check input
    defaults.preview = false;
    args = propval(varargin, defaults);
    
    % Set filename
    file = [filestem, '_cy', num2str(subj.cy)];
    
    if args.preview
        file = fullfile(subj.dirOut, [file, '.mat']);
        
    else
        % Also store nClasses
        try results.nClasses = subj.nClasses; end
        
        % Store results on disk
        out('Storing results on disk...');
        memorizeData(subj.dirOut, file, results);
    end
    
end
