% Computes the 1-p value of a Hotelling's t test for the current
% searchlight, based on the data from the current outer fold. The reason
% why 1-p is returned rather than p is so that higher values are better.
%
% Usage:
%     oneMinusP = score_hotelling(mat, labels)
%     [oneMinusP, T] = score_hotelling(mat, labels, args)
% 
% Input parameters:
%     mat: FEATURES x EXAMPLES matrix
%     labels: class labels
%     args: optional additional arguments
% 
% Return values:
%     oneMinusP: 1-p value of the Hotelling's T^2 test statistic

% Kay H. Brodersen, ETHZ/UZH
% $Id: score_hotelling.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [oneMinusP T] = score_hotelling(mat, labels, args)
    
    % Compute p value of Hotelling's T^2 test
    X1 = mat(:,labels==1)';  % --> EXAMPLES x VARIABLES for class 1
    X2 = mat(:,labels==2)';  % --> EXAMPLES x VARIABLES for class 2
    [T,P] = grouphotelling(X1,X2);
    
    % Return 1 - p
    oneMinusP = 1-P;
    
end
