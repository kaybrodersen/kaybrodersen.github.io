% Balanced accuracy of classification.
%
% Implements the 'perf_wrapper' interface.
% 
% Usage:
%     score = perf_bacc(targs, preds, perf_args)

% Kay H. Brodersen, ETHZ/UZH
% $Id: perf_bacc.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function score = perf_bacc(targs, preds, perf_args)
    
    % Define worst score as 0
    if isempty(targs) && isempty(preds)
        score = 0;
        return;
    end
    
    c = confusionmat(targs, preds, 'order', [1 2]);
    score = bacc_naive(c);
%     if isnan(score)
%         warning('WARNING: bacc is NaN')
%     end

end
