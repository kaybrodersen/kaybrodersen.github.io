% Wrapper for a classifier test function.
%
% Callee interface:
%     [preds, scratch] = test_func(data_test, scratch, test_args)
%
% Parameters:
%     data_test: test data
%     test_args: custom arguments of the test function
% 
% Return values:
%     preds: predictions
%     scratch: same as input variable scratch, but may be augmented by
%         additional output

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [preds, scratch] = test_wrapper(data_test, scratch, test_func, test_args)

    % Check args
    if isempty(test_args)
        test_args = struct;
    end
    
    % Call test function
    test_func_actual = str2func(func2str(test_func));
    [preds, scratch] = test_func_actual(data_test, scratch, test_args);
    
    % Return predictions as row vector
    preds = preds(:)';
end
