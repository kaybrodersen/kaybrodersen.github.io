% Training function for GP.
%
% See 'train_wrapper' interface.

% Kate Lomakina, ETHZ/UZH
% $Id: train_gp.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scratch = train_gp(mat_train, labels_train, nClasses, args)
    
    scratch.mat_train = mat_train;
    scratch.labels_train = labels_train;

end
