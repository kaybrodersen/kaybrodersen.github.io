% Prepare the command string for libsvm.

% Usage:
%     str = cmdtrain_libsvm(config_args, pars, values);

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function str = cmdtrain_libsvm(pars, values)
    
    % Set parameters
    str = '';
    for p=1:length(pars)
        
        % Ignore pars flagged as not belonging to LIBSVM
        try
            if ~pars(p).libsvm
                continue;
            end
        end
        
        % Otherwise add to string
        str = [str, ' -', pars(p).name, ' ', num2str(values(p))];
    end
    
    % Default cache for kernel evaluations: 1000 MB
    if isempty(strfind(str, '-m'))
        str = [str, ' -m 1000'];
    end
    
    % Quiet mode
    str = [str, ' -q']; % -h shrinking
    
end
