% Wrapper function for the analysis.
%
% Callee interface:
%     cancel = ana_func(subj, settings, ana_args);
% 
% Arguments:
%     subj: subj struct
%     settings: general settings struct
%     ana_args: analysis args struct
% 
% The function analysis_wrapper processes the following settings:
%     settings.errorHandling: 0 = no error handling
%                             1 = catch errors and continue with next subject

% Kay H. Brodersen, ETHZ/UZH
% $Id: analysis_wrapper.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = analysis_wrapper(subj, settings, ana_func, ana_args)
    
    % Set default error-handling behaviour
    if ~isfield(settings, 'errorHandling') || isempty(settings.errorHandling)
        settings.errorHandling = 1;
    end
    
    % Check analysis function
    if isempty(which(func2str(ana_func)))
        error(['Analysis function ''', func2str(ana_func), ''' not found']);
    end
    
    % Invoke analysis function
    out(' ');
    out(['Invoking ''', which(func2str(ana_func)), '''']);
    
    % No handling?
    if settings.errorHandling == 0
        ana_func_actual = str2func(func2str(ana_func));
        cancel = ana_func_actual(subj, settings, ana_args);
        
    % Catch errors?
    elseif settings.errorHandling == 1
        try
            ana_func_actual = str2func(func2str(ana_func));
            cancel = ana_func_actual(subj, settings, ana_args);
        catch e
            out(' ');
            out('-------------------------------------------------------');
            out(e.getReport);
            out('-------------------------------------------------------');
            out(' ');
            cancel = true;
        end
    end
    
end
