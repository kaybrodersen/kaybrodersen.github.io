% Implements outer cross-validation.
%
% Supports both normal and legacy mode. Supports the use of separate data
% features or separate labels for training and testing.
% 
% Usage:
%     results = runCrossValidation(subj, class_args)
%
% Arguments:
%     subj: struct with the following fields:
%         .folds: a folds struct array as created by createCvFolds
%         .mat_train: FEATURES x EXAMPLES data matrix for training
%         .mat_test: FEATURES x EXAMPLES data matrix for testing
%         .labels OR (labels_train AND labels_test): labels
%     class_args: struct with the following fields:
%         .conf_func
%         .conf_args
%         .train_func
%         .train_args
%         .test_func
%         .test_args
% 
% Additional named arguments:
%     'maskgroup' - name of the group of statmap masks to use
% 
% Return value:
%     results: a struct with the following fields:
%         .folds(): a struct array with the following fields:
%             .targs
%             .preds
%             .scratch

% Kay H. Brodersen, ETHZ/UZH
% $Id: runCrossValidation.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function results = runCrossValidation(subj, class_args, varargin)
    
    % Check input
    defaults.maskgroup = '';
    args = propval(varargin, defaults);
    if ~isfield(subj, 'labels_train')
        subj.labels_train = subj.labels;
        subj.labels_test = subj.labels;
    end
    try; class_args.conf_func; catch; class_args.conf_func = []; end
    try; class_args.conf_args; catch; class_args.conf_args = []; end
    try; class_args.train_args; catch; class_args.train_args = []; end
    try; class_args.test_args; catch; class_args.test_args = []; end
    
    % Initialize results
    results = struct;
    results.folds = subj.folds;
    
    % Are we in LEGACY mode?
    try; get_object(subj, 'pattern', 'data_train'); legacy=true; catch; legacy=false; end
    
    % Get masks group (if present)
    if legacy
        try
            [masknames ismaskgroup] = find_group_single(subj, 'mask', args.maskgroup, ...
                'repmat_times', length(subj.folds));
            if ~ismaskgroup
                out(sprintf('WARNING: using the same ''%s'' mask each time',maskgroup));
            end
        catch
            out(['(No mask group present, will not use a mask)']);
            masknames = [];
        end
    end
    
    % ---------------------------------------------------------------------
    % (0) INITIALIZE
    try class_args.init_func; catch; class_args.init_func = []; end
    try class_args.init_args; catch; class_args.init_args = []; end
    class_args = init_wrapper(class_args.init_func, class_args);
    
    
    % ---------------------------------------------------------------------
    % Run (outer) cross-validation
    nFolds = length(subj.folds);
    out(' ');
    out(['Starting cross-validation with ', num2str(nFolds), ' fold(s)']);
    for f = 1:nFolds
        fold = subj.folds(f);
        out(' '); out(['FOLD ', num2str(f), ' / ', num2str(nFolds)]);
        increaseIndent;
        
        % Get data
        if legacy
            if ~isempty(masknames)
                mat_train = get_masked_pattern(subj, 'data_train', masknames{f});
                mat_test =  get_masked_pattern(subj, 'data_test', masknames{f});
                out(['Masked legacy mat_train: ', mat2str(size(mat_train))])
                out(['Masked legacy mat_test:  ', mat2str(size(mat_test))])
            else
                fold_mat_train = get_object(subj, 'pattern', 'data_train');
                fold_mat_test = get_object(subj, 'pattern', 'data_test');
                out(['(Non-masked) legacy mat_train: ', mat2str(size(mat_train))])
                out(['(Non-masked) legacy mat_test:  ', mat2str(size(mat_test))])
            end
        else
            mat_train = subj.mat_train;
            mat_test = subj.mat_test;
            out(['mat_train: ', mat2str(size(mat_train))])
            out(['mat_test:  ', mat2str(size(mat_test))])
        end
        
        % Note: when wishing to display the kernel matrix, this is a good
        % point to do this.
        
        % Set fold-specific data
        fold_mat_train = mat_train(:, fold.train);
        fold_mat_test = mat_test(:, fold.test);
        out(['fold_mat_train: ', mat2str(size(fold_mat_train))])
        out(['fold_mat_test:  ', mat2str(size(fold_mat_test))])
        
        % Set fold-specific labels
        fold_labels_train = subj.labels_train(fold.train);
        fold_labels_test = subj.labels_test(fold.test);
        
        out(['Train indices: ', mat2str(fold.train)]);
        [types,freqs] = analyseCriterion(fold_labels_train);
        out(['    Types: ', mat2str(types)]);
        out(['    Freqs: ', mat2str(freqs)]);
        out(['Test indices: ', mat2str(fold.test)]);
        [types,freqs] = analyseCriterion(fold_labels_test);
        out(['    Types: ', mat2str(types)]);
        out(['    Freqs: ', mat2str(freqs)]);
        
        % Do the (masked) patterns contain at least one voxel?
        if size(fold_mat_train,1)==0 || size(fold_mat_test,1)==0
            out(['WARNING: fold_mat_train or fold_mat_test contain no voxels.']);
            out(['Will ignore this fold.']);
            fold_labels_test = [];
            fold_preds = [];
            scratch = [];
            
        else
            
            
            % -------------------------------------------------------------
            % (1) CONFIGURE (e.g., setting hyperparameters)
            [class_args.train_args, class_args.test_args] = ...
                conf_wrapper(class_args.train_args, class_args.test_args, ...
                class_args.conf_func, class_args.conf_args, ...
                'data', mat_train, ...
                'indices', fold.train, ...
                'labels', subj.labels_train, ...
                'nClasses', subj.nClasses);
                
%             % PCA?
%             try
%                 pars = class_args.train_args.conf.pars;
%                 opt = class_args.train_args.conf.opt;
%                 for p=1:length(pars)
%                     if isfield(pars(p), 'libsvm') && ~isempty(pars(p).libsvm) && ~pars(p).libsvm && strcmp(pars(p).name, 'pca')
%                         nComponents = min([size(mat_train,2), opt(p)]);
%                         out(['Applying NCV-optimized PCA with ', num2str(nComponents), ' components...']);
%                         [~, mat_train] = pca(mat_train, nComponents); mat_train = mat_train';
%                         [~, mat_test] = pca(mat_test, nComponents); mat_test = mat_test';
%                         fold_mat_train = mat_train(:, fold.train);
%                         fold_mat_test = mat_test(:, fold.test);
%                         out(['fold_mat_train: ', mat2str(size(fold_mat_train))])
%                         out(['fold_mat_test:  ', mat2str(size(fold_mat_test))])
%                         break;
%                     end
%                 end
%             end
            
            % (2) TRAIN
            scratch = train_wrapper(fold_mat_train, fold_labels_train, ...
                class_args.train_func, class_args.train_args);
            scratch.fold = fold;
            
            % (3) TEST
            [fold_preds, scratch] = test_wrapper(fold_mat_test, scratch, ...
                class_args.test_func, class_args.test_args);
            out(['Targs: ', mat2str(fold_labels_test)]);
            out(['Preds: ', mat2str(fold_preds)]);
        end
        
        
        % -----------------------------------------------------------------
        % Store results along with indices
        results.folds(f).targs = fold_labels_test;
        results.folds(f).preds = fold_preds;
        results.folds(f).scratch = scratch;
        
        decreaseIndent;
    end % fold f
    
    
    % ---------------------------------------------------------------------
    % Show results
    out(' ');
    printResults(results, subj.nClasses); out(' ');
    
end
