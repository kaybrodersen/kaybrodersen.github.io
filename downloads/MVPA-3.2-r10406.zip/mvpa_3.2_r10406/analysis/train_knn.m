% Training function for nearest-neighbour classification.
%
% See 'train_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: train_knn.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scratch = train_knn(mat_train, labels_train, nClasses, args)
    
    % Check data
    assert(~any(any(isnan(mat_train))), 'there are NaN values in the data');
    assert(containsOnly(labels_train, [1 2]), 'labels must be 1s and 2s');
    
    % Learn model
    scratch.m.mat_train = mat_train;
    scratch.m.labels_train = labels_train;
    
end
