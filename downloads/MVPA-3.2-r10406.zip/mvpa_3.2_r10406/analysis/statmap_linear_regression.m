% Computes the 1-p value of a multiple linear regression F-test for the
% current searchlight, based on the data from the current outer fold. The
% reason why 1-p is returned rather than p is so that higher values are
% better.
%
% Usage:
%     val = statmap_linear_regression(mat, labels)
%     val = statmap_linear_regression(mat, labels, args)
% 
% Input parameters:
%     mat: FEATURES x EXAMPLES matrix
%     labels: class labels
%     args: optional additional arguments
% 
% Return value: depending on args.return, this can be:
%     oneMinusP: 1-p value of the F-test statistic
%     R2: R squared statistic of the regression

% Kay H. Brodersen, ETHZ/UZH
% $Id: statmap_linear_regression.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function val = statmap_linear_regression(mat, labels, args)
    
    % Check input
    defaults.return = 'oneMinusP';
    args = propval(args, defaults);
    
    % Set up multiple linear regression
    y = labels';
    X = [mat', ones(size(mat,2),1)];
    [B,BINT,R,RINT,STATS] = regress(y, X);
    
    % Return
    if strcmpi(args.return, 'oneMinusP')
        val = 1 - STATS(3);
    elseif strcmpi(args.return, 'R2')
        val = STATS(1);
    else
        error('illegal args.return');
    end
    
end
