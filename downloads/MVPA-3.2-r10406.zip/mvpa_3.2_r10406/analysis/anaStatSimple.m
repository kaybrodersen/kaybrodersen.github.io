% Computes a simple overall statistic, based on a given mask (i.e., no
% further feature selection). There is no cross-validation.
%
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaStatSimple.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [results, cancel] = anaStatSimple(subj, settings, cy, ana_args)

error('not fully implemented yet');


    % Get data, labels, and regressors (so that everything is available)
    data = get_mat(subj, 'pattern', 'data_train');
    regs = get_mat(subj, 'regressors', 'labels');
    labels = subj.labels;
    
    % Split up data into both groups
    X1 = data(:,labels==1)';
    X2 = data(:,labels==2)';
    % now: EXAMPLES x VARIABLES
    
    % Initialize results
    results = [];
    cancel = false;
    
    % Compute simple overall statistics
    % - Mahalanobis distance
    results.mahal = groupmahal(X1,X2);
    % - Hotelling's T test
    [results.hotT, results.hotP] = grouphotelling(X1,X2);
    
    % Print results
    out(' ');
    out('STATSIMPLE RESULTS FOR THIS SUBJECT AND CYCLE');
    out(['Mahalanobis distance ..: ', num2str(results.mahal)]);
    out(['Hotelling''s T ........: ', num2str(results.hotT)]);
    out(['Hotelling''S P ........: ', num2str(results.hotP)]);
    out(' ');
	
    % Save results
    out('Storing results on disk...');
    dir = subj.dirOut;
    file = [settings.main.fileOut, '_cy', num2str(cy)];
        memorizeData(dir, file, results);
    
end
