% Evaluates a given parameter vector.
%
% Usage:
%     v = eval_libsvm(mat, indices, labels, folds, nClasses, pars, x, eval_args)
%
% Input arguments:
%     mat: full data matrix or kernel matrix
%     indices: indices to use
%     labels: labels vector (positive integers)
%     folds: folds struct
%     nClasses: number of classes in the data (typically 2)
%     pars: parameter description
%     x: parameter values
%     eval_args: further args
%
% Return values:
%     v: performance (number correct or balanced accuracy)
% 
% The idea is to:
% - either pass in 'mat', 'indices', and 'labels', and use these to call
%   libsvm with the -v option to run its internal cross-validation;
% - or pass in 'mat' and 'folds', and use specific training and test
%   sets of indices.

% Kay H. Brodersen, ETHZ / UZH
% $Id: eval_libsvm.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function v = eval_libsvm(mat, indices, labels, folds, nClasses, pars, x, eval_args)
   
    % Check input
    defaults.nFolds = 5;
    defaults.randomSubsetSize = [];
    eval_args = propval(eval_args, defaults, 'strict', false);
    assert(eval_args.nFolds>=2);
    
    % Prepare SVM args
    train_args.libsvm_options = cmdtrain_libsvm(pars, x);
    test_args.libsvm_options = '';
    
    % ---------------------------------------------------------------------
    % SIMPLE XVAL MODE
    if isempty(folds)
        % Configure libsvm's internal cross-validation
        train_args.libsvm_options = [train_args.libsvm_options, ' -v ', num2str(eval_args.nFolds)];
           % ! Note: -v 5   means there are 5 folds (not: set size 5)
           % -v 5 seems to be good
           
        % Data matrix?
        if isempty(strfind(train_args.libsvm_options,'-t 4'))
            mat = mat(:,unique(indices));
            labels = labels(unique(indices));
            
        % Kernel matrix?
        else
            mat = mat(unique(indices),unique(indices));
            mat = [1:size(mat,2); mat];
            labels = labels(unique(indices));
        end
        
        % Invoke libsvm's internal cross-validation
        scratch = train_libsvm(mat, labels, train_args);
        
        % When called with the cross-validation option '-v', the function does
        % not return a model but the number of correct labels (e.g., 82 out of
        % 100).
        v = scratch.model;
        
    % ---------------------------------------------------------------------
    % EXTENDED XVAL MODE
    else
        nFolds = length(folds);
        targs = [];
        preds = [];
        for f = 1:nFolds
            fold = folds(f);
            
            % Data matrix?
            if isempty(strfind(train_args.libsvm_options,'-t 4'))
                fold_mat_train = mat(:, fold.train);
                fold_mat_test = mat(:, fold.test);
                fold_labels_train = labels(fold.train);
                fold_labels_test = labels(fold.test);
            
            % Kernel matrix?
            else
                fold_mat_train = mat(fold.train, fold.train);    % training examples x training examples
                fold_mat_test = mat(fold.train, fold.test);      % training examples x test examples
                fold_mat_train = [1:size(fold_mat_train,2); fold_mat_train];
                fold_mat_test = [zeros(1,size(fold_mat_test,2)); fold_mat_test];
                fold_labels_train = labels(fold.train);
                fold_labels_test = labels(fold.test);
            end
            
            % Train and test
            scratch = train_libsvm(fold_mat_train, fold_labels_train, train_args);
            [fold_preds, scratch] = test_libsvm(fold_mat_test, scratch, test_args);
            targs = [targs,fold_labels_test];
            preds = [preds,fold_preds(:)'];
            scratch.fold = fold;
        end % fold
        
        % Evaluate
        c = confusionmat(targs, preds, 'order', [1 2]);
        v = bacc_naive(c);
    end
    
end


%     % PCA?
%     for p=1:length(pars)
%         if isfield(pars(p), 'libsvm') && ~isempty(pars(p).libsvm) && ~pars(p).libsvm && strcmp(pars(p).name, 'pca')
%             nComponents = min([size(mat,2), x(p)]);
%             [~, mat] = pca(mat, nComponents);
%             mat = mat';
%             break;
%         end
%     end
    
%     % For performance reasons, operate on a subset of overall training
%     % data?
%
%     % randomSubsetSize cannot be greater than number of trials
%     eval_args.randomSubsetSize = min(eval_args.randomSubsetSize, length(labels));
%
%     if ~isempty(eval_args.randomSubsetSize) && eval_args.randomSubsetSize ~= 0
%         indices = 1:length(labels);
%         indices = shuffle(indices);
%         indices = indices(1:eval_args.randomSubsetSize);
%         indices = sort(indices);
%         
%         labels = labels(indices);
%         mat = mat(:,indices);
%     end
