% Test function for logistic regression.
%
% See 'test_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: test_logreg.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [preds, scratch] = test_logreg(mat_test, nClasses, scratch, args)
    
    % Check input
    defaults.libsvm_options = '';
    args = mergestructs(args, defaults);
    assert(~any(any(isnan(mat_test))), 'there are NaN values in the data');
    
    % Predict
    B = scratch.model.B;
    Z = B(1) + mat_test'*B(2:end);
    preds = round(logistic(Z))';
    
    % Transform labels from [1 0] back to [1 2]
    assert(containsOnly(preds, [1 0]));
    preds(preds==0) = 2;
    
    % Also return decision values
    scratch.dvs = Z;
    
    % Also return the feature coefficients
    scratch.beta = B(2:end);
    
end

% -------------------------------------------------------------------------
function y = logistic(x)
    y = 1./(1+exp(-x));
end
