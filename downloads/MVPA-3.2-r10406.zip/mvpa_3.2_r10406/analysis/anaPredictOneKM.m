% Prediction by cross-validation. No feature selection. Kernel-matrix
% version.
% 
% Does not support the use of separate data features or labels for training
% and testing. Does not support any feature processing.
% 
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaPredictOneKM.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaPredictOneKM(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && any(settings.legacy)), 'non-legacy settings expected');
    
    % Designate output file
    filestem = ['pred', num2str(settings.analysisId)];
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = makeAbsolutePath(savePredResults(subj, filestem, [], 'preview', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels
    loadLabels_func = settings.loadLabels_func;
    loadLabels_args = settings.loadLabels_args;
    
    % Get number of classes
    loadLabels_func_actual = str2func(func2str(loadLabels_func));
    subj.nClasses = loadLabels_func_actual();
    
    % Load labels (positive integers for normal trials; NaN labels for
    % trials that are to be ignored).
    subj.labels = loadLabels_wrapper(subj, loadLabels_func, loadLabels_args);
    
    % Ignore trials where label is NaN
    subj.labels(isnan(subj.labels)) = NaN;
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj.dirScan, ana_args.invertFilter, ...
        length(subj.labels), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels = randomizeLabels(subj.labels, ana_args.randomizeLabels);
    
    
    % ---------------------------------------------------------------------
    % Load data
    % into subj.K (EXAMPLES x EXAMPLES)
    loadData_func = settings.loadData_func;
    loadData_args = settings.loadData_args;
    
    loadData_scratch = [];
    [subj.K, loadData_scratch] = loadData_wrapper(subj, ...
        loadData_func, loadData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'K');
    assert(ndims(subj.K)==2 && size(subj.K,1)==size(subj.K,2), 'invalid kernel matrix');
    assert(size(subj.K,1)==length(subj.labels), 'kernel matrix dimension mismatch');
    subj.nExamples = size(subj.K,1);
    
    
    % ---------------------------------------------------------------------
    % Remove all trials with a NaN somewhere in the kernel matrix
    badTrials = any(isnan(subj.K),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badTrials)), ...
            ') trials have at least one NaN value in the kernel matrix and will be ignored']);
        subj.labels(badExamples) = NaN;
    end
    
    
    % ---------------------------------------------------------------------
    % Create (outer) cross-validation folds
    cv = ana_args.cv;
    
    % Set balancing criteria
    try; try cv.loadBalancingCriteria_func; catch; cv.loadBalancingCriteria_func = settings.loadBalancingCriteria_func; end;
    catch; cv.loadBalancingCriteria_func = []; end
    try; try cv.loadBalancingCriteria_args; catch; cv.loadBalancingCriteria_args = settings.loadBalancingCriteria_args; end;
    catch; cv.loadBalancingCriteria_args = []; end
    cv.balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
        cv.loadBalancingCriteria_func, cv.loadBalancingCriteria_args);
    
    % Load block filter
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    
    % Create CV folds
    [subj.folds, cancel] = createCvFolds(subj.labels, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Prediction by (outer) cross-validation (kernel-matrix version)
    results = runCrossValidationKM(subj, ana_args.class_args);
    
    
    % ---------------------------------------------------------------------
    % Save results
    savePredResults(subj, filestem, results);
    
    % Return success
    cancel = false;
end
