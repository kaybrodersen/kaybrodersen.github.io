% Testing function for SVMlight.
%
% Usage:
%     [acts scratch] = test_svm(testdata, scratch)
%
% Input parameters:
%     testdata: a FEATURES x EXAMPLES matrix of test data
%     scratch: scratch as returned by the training function (contains, in
%         particular, the model that the classifier learned during training)

% Adapted from the MVPA toolbox.
% -------------------------------------------------------------------------
function [acts scratch] = test_svmlight(testdata, scratch)

    % Check input
    if ~exist('scratch','var')
        scratch = [];
    end
    
    % Test classifier
    % (Svmclassify wants the test labels so it can compute the error, but
    % this is not good programming practice. Here we prefer keeping the
    % interface clean: the test function is not given access to test
    % labels. We will do the comparison later. Thus, we feed in
    % zero-labels.
    clear fun mexsvmclassify;
    clear fun mexsvmlearn;
    [err, decision_variables] = mexsvmclassify(...
        testdata',...
        ones(size(testdata, 2),1), ...
        scratch.model);
    clear fun mexsvmclassify;
    
    % Prepare result
    acts = [decision_variables'; zeros(size(decision_variables'))];
    % Note that this may contain NaNs. For example, when the test data were
    % all zeros, then decision_variables will be [NaN NaN NaN ... NaN], and
    % so acts will be [NaN NaN ... NaN; 0 0 ... 0].
    
end
