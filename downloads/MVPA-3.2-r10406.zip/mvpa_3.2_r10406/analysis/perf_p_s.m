% Performance evaluation for regression. Computes the 1-p value of the
% Spearman rank correlation.
%
% Implements the 'perf_wrapper' interface.
% 
% Usage:
%     score = perf_p_s(targs, preds, scratch, perf_args)

% Kay H. Brodersen, ETHZ/UZH
% $Id: perf_p_s.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function one_minus_p_s = perf_p_s(targs, preds, perf_args)
    
    % Spearman rank correlation
    [rho_s, p_s] = corr(targs(:), preds(:), 'type', 'Spearman');
    
    one_minus_p_s = 1-p_s;
    
end
