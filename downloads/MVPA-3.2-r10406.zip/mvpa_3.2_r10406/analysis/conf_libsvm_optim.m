% Configuration function for libsvm. Implements an optimization of
% hyperparameters.
%   
% See 'conf_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [train_args, test_args] = conf_libsvm_optim(train_args, test_args, ...
    conf_args, varargin)
    
    % Process varargin
    defaults.data = [];
    defaults.indices = [];
    defaults.labels = [];
    defaults.nClasses = 2;
    further_args = propval(varargin, defaults);
    
    % Configure grid search
    try conf_args.eval_func; conf_args.eval_func = @eval_libsvm; end
    try conf_args.eval_args; conf_args.eval_args = []; end
    
    % If any parameter has a range with more than one value, set up a grid
    % search. Otherwise, simply return those parameter values.
    doGridSearch = false;
    pars = conf_args.pars;
    for p=1:length(pars)
        if length(pars(p).range)>1
            doGridSearch = true;
            break;
        end
    end
    
    % Run grid search
    if doGridSearch
        % Run grid search
        [opt, results] = gridSearch(further_args.data, further_args.indices, ...
            further_args.labels, further_args.nClasses, conf_args);
    else
        % Simply take given values
        opt = NaN(1,length(pars));
        for p=1:length(pars)
            opt(p) = pars(p).range;
        end
        results = [];
    end
    
    % Save parameters
    train_args.libsvm_options = cmdtrain_libsvm(pars, opt);
    test_args.libsvm_options = cmdtest_libsvm(pars, opt);
    
    % Show optimum (DEBUG)
    try conf_args.verbose; catch; conf_args.verbose = 0; end
    out(['Train parameters: ',train_args.libsvm_options], conf_args.verbose>0);
    
    % Save other things
    train_args.nClasses = further_args.nClasses;
    test_args.nClasses = further_args.nClasses;
    
    % Save stuff for recollect_libsvm_pars.m
    train_args.conf.pars = pars;
    train_args.conf.opt = opt;
    train_args.conf.results = results;
    
end
