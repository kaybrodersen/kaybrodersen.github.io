% Scoring wrapper that uses a cross-validation scheme to create a
% searchlight score for each voxel, using the specified objective function
% (e.g., libsvm).
% 
% This function is intended to be passed as statmap_func to
% runStatmapsLegacy.
% 
% This function operates in LEGACY mode.
% 
% Usage:
%     statmap_searchlight_xval(subj, fold, new_mapname, statmap_args)
% 
% Arguments:
%     subj: Princeton subj struct that contains a Princeton pattern called
%         'data_train'
%     outerFold: a single object from a subj.folds() struct array containing a
%         .train and a .test field
%     new_mapname: name of the map to be created
%     statmap_args: additional custom arguments, including the full
%         configuration of the classifier to be used
%
% Custom fields in statmap_args:
%     'searchlightRadius'
%     'add_center_voxel'
%     'ignore_empty_adj_list'
%     'cv' - cross-validation settings
%     'class_args' - full classifier configuration
%     'processFeatures_func'
%     'processFeatures_args'

% Kay H. Brodersen, ETHZ/UZH
% $Id: statmap_searchlight_xval.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = statmap_searchlight_xval(subj, outerFold, new_mapname, statmap_args)
    
    % Check input
    defaults.searchlightRadius = 2;
    defaults.add_center_voxel = true;
    defaults.ignore_empty_adj_list = false;
    defaults.cv = [];
    defaults.processFeatures_func = [];
    defaults.processFeatures_args = [];
    defaults.class_args = [];
    args = propval(statmap_args, defaults, 'strict', false);
    if isempty(args.class_args)
        error('classifier configuration (class_args) required');
    end
    try subj.labels_train; catch; subj.labels_train = subj.labels; end
    try subj.labels_test; catch; subj.labels_Test = subj.labels; end
    try args.class_args.perf_func; catch; args.class_args.perf_func = []; end
    try args.class_args.perf_args; catch; args.class_args.perf_args = []; end
    
    
    % ---------------------------------------------------------------------
    % Create adjacency matrix (unless already created)
    subj.adj_list = create_adj_list(subj, 'the_mask', ...
        'radius', args.searchlightRadius);
    
    
    % -------------------------------------------------------------
    % Get data and labels (outer training set)
    mat_train = get_mat(subj, 'pattern', 'data_train');
    mat_test = get_mat(subj, 'pattern', 'data_test');
    labels_train = subj.labels_train;
    labels_test = subj.labels_test;
    assert(size(mat_train,2)==length(labels_train));
    assert(size(mat_test,2)==length(labels_test));
    
    % Show whether patterns are identical or not (purely informative)
    if nanequals(mat_train, mat_test)
        out('Train and test matrices are identical, i.e., the same data will be used for training and testing:');
        usingSameData = true;
    else
        out('Two different matrices will be used for training and testing:');
        usingSameData = false;
    end
    out(['    Training on data_train: ', mat2str(size(mat_train)), ', checksum ', num2str(nansum(nansum(mat_train)))]);
    out(['    Testing on data_test:   ', mat2str(size(mat_test)), ', checksum ', num2str(nansum(nansum(mat_test)))]);
    
    
    % ---------------------------------------------------------------------
    % Create (inner) cross-validation folds
    % (based on current outer training indices)
    cv = args.cv;
    
    % Set balancing criteria
    try; cv.loadBalancingCriteria_func; catch; cv.loadBalancingCriteria_func = []; end
    try; cv.loadBalancingCriteria_args; catch; cv.loadBalancingCriteria_args = []; end
    cv.balancingCriteria = loadBalancingCriteria_wrapper(subj, ...
        cv.loadBalancingCriteria_func, cv.loadBalancingCriteria_args);
    if ~isempty(cv.balancingCriteria)
        cv.balancingCriteria = cv.balancingCriteria(:,outerFold.train);
    end
    
    cv.pool = outerFold.train;
    cv.nClasses = subj.nClasses;
    innerFolds = createCvFolds(labels_train(outerFold.train), cv);
    nInnerFolds = length(innerFolds);
    
    % Initialize map accumulator
    nVox = subj.nFeatures;
    map = NaN(nVox,1);
    
    % If no inner folds were created, leave this map to all NaN
    if nInnerFolds==0
        out(['WARNING: No inner folds created.']);
        out(['This map will be all NaN.']);
    
    % Otherwise create map
    else
    % ---------------------------------------------------------------------
    % Loop over spheres (or whatever adjacency neighborhood we're using)
    out(['Looping over ', num2str(nVox), ' spheres...']);
    increaseIndent;
    for v = 1:nVox
        %out(['Voxel ', num2str(v), ' / ', num2str(nVox)]);
        %progress(v,nVox);
        
        % Get adjacent list for current voxel
        cur_adj_list = subj.adj_list(v,:);
        
        % Throw away all zero-values from adjacency list
        cur_adj_list = cur_adj_list(cur_adj_list~=0);
        
        % Add the current (center) voxel to its own sphere? (Usually,
        % this is 'false' because the center voxel is already contained
        % in its sphere by construction of the sphere.)
        if args.add_center_voxel && ~find(cur_adj_list==v)
            vox_idx = [v cur_adj_list];
        else
            vox_idx = cur_adj_list;
        end
        
        % Process this sphere only if it contains at least two voxels
        % (unless searchlight radius = 0)
        if length(vox_idx)<2 && args.searchlightRadius>0
            map(v) = perf_wrapper([], [], args.class_args.perf_func, args.class_args.perf_args);
            out(['NOTE: voxel ', num2str(v), ' score set to ', num2str(map(v)), ' because no other voxels in its sphere']);
            continue;
        end
        
        % Process this sphere only if at least one of the contained voxels
        % has some data in it (rather than just all zero)
        if all(sum(mat_train(vox_idx,:),2)==0) || all(sum(mat_test(vox_idx,:),2)==0)
            map(v) = perf_wrapper([], [], args.class_args.perf_func, args.class_args.perf_args);
            out(['NOTE: voxel ', num2str(v), ' score set to ', num2str(map(v)), ' because no nonzero data in its sphere']);
            continue;
        end
        
        % Set sphere
        sphere_train = mat_train(vox_idx,:); % all trials, but train data
        sphere_test = mat_test(vox_idx,:);   % all trials, but test data
        
        % Process features (new)
        try args.processFeatures_func; catch; args.processFeatures_func = {}; end
        try args.processFeatures_args; catch; args.processFeatures_args = []; end
        if ~isempty(args.processFeatures_func) && ~iscell(args.processFeatures_func)
            args.processFeatures_func = {args.processFeatures_func};
        end
        for pf = 1:length(args.processFeatures_func)
            pf_actual = str2func(func2str(args.processFeatures_func{pf}));
            if v==1
                out(' ');
                out(['Feature preprocessing:']);
                out(['    sphere_train: ', func2str(pf_actual)]);
                sphere_train = pf_actual(sphere_train, labels_train, args.processFeatures_args);
                out(['    sphere_test: ', func2str(pf_actual)]);
                if usingSameData
                    sphere_test = sphere_train;
                else
                    sphere_test = pf_actual(sphere_test, labels_test, args.processFeatures_args);
                end
            end
        end
        
        % Initialize accumulators for targs and preds
        acc_targs = NaN(1,length([innerFolds.test]));
        acc_preds = acc_targs;
        acc_i = 0;
        
        % -----------------------------------------------------------------
        % Classification by (inner) cross-validation
        out(' ',v==1);
        out(['Starting inner cross-validation with ', num2str(nInnerFolds), ' folds'],v==1);
        if v==1, increaseIndent, end;
        for f = 1:nInnerFolds
            out(' ',v==1);
            out(['Inner fold ', num2str(f), '/', num2str(nInnerFolds)],v==1);
            
            % Set data and labels
            % specific to this fold and voxel
            fold = innerFolds(f);
            fold_labels_train = labels_train(fold.train);
            fold_labels_test = labels_test(fold.test);
            fold_sphere_train = sphere_train(:, fold.train);
            fold_sphere_test = sphere_test(:, fold.test);
            
            % Show indices (DEBUG)
            if v==1
                out(' ');
                out(['Inner training indices: ', mat2str(fold.train)]);
                [types,freqs] = analyseCriterion(fold_labels_train);
                out(['    Types: ', mat2str(types)]);
                out(['    Freqs: ', mat2str(freqs)]);
                out(['Inner test indices: ', mat2str(fold.test)]);
                [types,freqs] = analyseCriterion(fold_labels_test);
                out(['    Types: ', mat2str(types)]);
                out(['    Freqs: ', mat2str(freqs)]);
            end        
            
            % Process this voxel only if its neighbourhood contains at
            % least one other voxel (SVM cannot deal with just one feature?)
            preds = [];
            
            if size(fold_sphere_train,1) > 1
                
                % (1) Configure
                [args.class_args.train_args, args.class_args.test_args] = ...
                    conf_wrapper(args.class_args.train_args, args.class_args.test_args, ...
                    args.class_args.conf_func, args.class_args.conf_args, ...
                    'data', sphere_train, ...
                    'indices', fold.train, ...
                    'labels', labels_train, ...
                    'nClasses', subj.nClasses);
                
                % (2) Train
                scratch = train_wrapper(fold_sphere_train, fold_labels_train, ...
                    args.class_args.train_func, args.class_args.train_args);
            
                % (3) Test
                [preds, scratch] = test_wrapper(fold_sphere_test, scratch, ...
                    args.class_args.test_func, args.class_args.test_args);
            end
            
            % Accumulate targs and preds
            acc_targs(acc_i+1:acc_i+length(fold_labels_test)) = fold_labels_test;
            acc_preds(acc_i+1:acc_i+length(preds)) = preds;
            acc_i = acc_i + length(fold_labels_test);
            assert(length(fold_labels_test)>=length(preds));
            
        end % inner fold f
        
        % Clean up targs and preds
        assert(all(~isnan(acc_targs)));
        acc_targs = acc_targs(~isnan(acc_preds));
        acc_preds = acc_preds(~isnan(acc_preds));
        assert(length(acc_targs)==length(acc_preds));
        
        % Compute score for current voxel
        score = perf_wrapper(acc_targs, acc_preds, ...
            args.class_args.perf_func, args.class_args.perf_args);
        map(v) = score;
        %out(num2str(score));
        
        if v==1, decreaseIndent, end;
        
    end % voxel v
    decreaseIndent;
    end
    
    % ---------------------------------------------------------------------
    % Add the map to the SUBJ structure as a new pattern
    masked_by = get_objfield(subj, 'pattern', 'data_train', 'masked_by');
    subj = initset_object(subj, 'pattern', new_mapname, map, 'masked_by', masked_by);
    
end
