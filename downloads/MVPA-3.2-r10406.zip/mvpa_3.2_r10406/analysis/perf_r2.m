% Performance evaluation for regression.
%
% Implements the 'perf_wrapper' interface.
% 
% Usage:
%     score = perf_r2(targs, preds, perf_args)

% Kay H. Brodersen, ETHZ/UZH
% $Id: perf_r2.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function r2 = perf_r2(targs, preds, perf_args)
    
    % Compute R^2
    r2 = sum((preds - mean(targs)).^2) / sum((targs - mean(targs)).^2);
    
end
