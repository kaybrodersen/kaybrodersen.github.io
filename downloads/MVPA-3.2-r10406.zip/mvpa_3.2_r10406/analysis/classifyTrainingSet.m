% Classifies with simple given mask, training and testing only once,
% without any splitting of the data (peeking). Allows for looking at the
% training error and at the optimal parameters from the classifier
% optimization. Alternatively, if the test set is different from the
% training set, allows for training on the training set and testing on the
% test set (e.g., for across-subjects classification).
%
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: classifyTrainingSet.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [results, cancel] = classifyTrainingSet(subj, settings, cy, ana_args)
    
    % Get some general information
    nVoxels = get_objfield(subj, 'pattern', 'data_train', 'matsize');
    nVoxels = nVoxels(1);
    try
        tmpMask = get_object(subj, 'mask', 'the_mask');
        nVoxelsMask = sum(sum(sum(tmpMask.mat~=0)));
        out(['There are ', num2str(nVoxelsMask), ' voxels in this mask (= ', ...
            num2str(nVoxelsMask/nVoxels*100), '% of all loaded voxels)']);
    catch
        out('(No mask present)');
    end
    
    % ---------------------------------------------------------------------
    % Create 1 outer fold
    
    % Load block filter (if any)
    blockFilter = loadBlockFilter_wrapper(subj.dirScan, length(settings.blockLengths), ...
        settings.loadBlockFilter_func, settings.loadBlockFilter_args);
    
    % Create CV indices
    [subj, cancel] = createCvIndices(subj, ...
        'blockLengths', settings.blockLengths, ...
        'blockFilter', blockFilter, ...
        'bShuffle', false, ... % trial shuffling means left-over trials will be somewhere randomly rather than as a block at the end
        'setSize', 1, ...
        'bSinglePeekingFoldOnly', true, ...
        'balancingCriteria', subj.labels, ...
        'overallRepetitions', 1, ...
        'overallBalancingType', 0, ...
        'minPatternsPerClass', 2, ...
        'outerFoldwiseBalancingType', ana_args.outerFoldwiseBalancingType, ... 
        'outerFoldwiseBalancingRepetitions', 1, ...
        'outerFoldwiseExclusion', [0 0], ...
        'outerTestFilter', [], ...
        'keepSubjectsSeparate', false); % across subjects clf?
    
    % Check that we have created some folds
    if cancel
        % No folds created. This means there was no data left after all
        % filtering and balancing.
        results = [];
        return;
    end
    
    % Display how many test trials we are operating with
    if isfield(ana_args, 'outerTestFilter')
        tmpReps = [subj.indices.folds(:).reps];
        tmpTests = [tmpReps.test];
        nTestTrials = unique(tmpTests);
        out(' ');
        out(['ACROSS ALL OUTER FOLDS, THERE ARE ', num2str(length(nTestTrials)), ' TEST CASES ', ...
            mat2str(nTestTrials)]);
        out(' ');
    end
    
    % ---------------------------------------------------------------------
    % Classification of whole set (no outer cross-validation)
    
    % Initialize classifier
    ana_args.outer_class_args = init_wrapper(...
        ana_args.outer_class_args.init_func, ana_args.outer_class_args);
    
    % Set up (outer) classifier
    patgroup_train = 'data_train';
    patgroup_test = 'data_test';
    regsname = 'labels';
    maskgroup = 'the_mask';
    outer_class_args = ana_args.outer_class_args;
    
    % Run outer classifier
    out('Running outer classifier...');
    [subj, results] = runCrossValidation(subj, ...
        patgroup_train, regsname, maskgroup, outer_class_args, ...
        'patgroup_test', patgroup_test);
    
    % Print results
    out(' ');
    out('OVERALL RESULTS FOR THIS SUBJECT AND CYCLE [TRAINING ACCURACY!]');
    printResults(results);
    out(' ');
	
	% Save results
	saveClfResults(subj, settings, cy, results);
    
end
