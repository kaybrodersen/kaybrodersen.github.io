% Creates an averaged statmap on the basis of a specified set of statmaps.
% This is important in the creation of an overall statmap when there is a
% blocks structure and all block-specific statmaps are to be averaged. (It
% is not used when statmaps are created for feature selection.)
% 
% This function operates in LEGACY mode.
% 
% Usage:
%     subj = averageStatmaps(subj, groupname, new_name)
% 
% Arguments:
%     subj: Princeton subj struct
%     groupname: groupname of the patterns to be averaged
%     new_name: name for the new average map (default: <groupname>_average)
% 
% Example:
%     subj = averageStatmaps(subj, 'statmap');
% 
%     This averages all the patterns called 'statmap_1', 'statmap_2', ...,
%     and creates a new pattern called 'statmap_average'

% Kay H. Brodersen, ETHZ/UZH
% $Id: averageStatmapsLegacy.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function subj = averageStatmapsLegacy(subj, groupname, new_name)
    
    % Check input
    if ~exist('new_name', 'var')
        new_name = [groupname, '_average'];
    end
    
    % Get all map names
    map_names = find_group(subj, 'pattern', groupname);
    nMaps = length(map_names);
    
    % Get all maps
    all_maps = [];
    for i=1:nMaps
        this_map = get_mat(subj, 'pattern', [groupname, '_', num2str(i)]);
        if isempty(all_maps)
            all_maps = NaN(size(this_map,1), nMaps);
        end
        all_maps(:,i) = this_map;
    end
    
    % Create average map
    avg_map = nanmean(all_maps,2);
    
    % Store
    subj = init_object(subj, 'pattern', new_name);
    subj = set_mat(subj, 'pattern', new_name, avg_map);
    maskname = get_objfield(subj, 'pattern', 'data_train', 'masked_by');
    subj = set_objfield(subj, 'pattern', new_name, 'masked_by', maskname);
    
end
