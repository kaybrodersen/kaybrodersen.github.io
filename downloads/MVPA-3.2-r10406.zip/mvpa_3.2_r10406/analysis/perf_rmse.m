% Performance evaluation for regression.
%
% Implements the 'perf_wrapper' interface.
% 
% Usage:
%     score = perf_rmse(targs, preds, perf_args)
%
% Custom arguments:
%     minus (default=false) - if true, returns -RMSE instead of RMSE.
%     inverse (default=false) - if true, returns 1/RMSE

% Kay H. Brodersen, ETHZ/UZH
% $Id: perf_rmse.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function RMSE = perf_rmse(targs, preds, perf_args)
    
    % Check input
    defaults.minus = false;
    defaults.inverse = false;
    args = propval(perf_args, defaults);
    assert(~(args.minus && args.inverse));
    
    % Compute RMSE
    RMSE = sqrt(mean((targs - preds).^2));
    
    if args.minus
        RMSE = -RMSE;
    end
    if args.inverse
        RMSE = 1/RMSE;
    end
    
end
