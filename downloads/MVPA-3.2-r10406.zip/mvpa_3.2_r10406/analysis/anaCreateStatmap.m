% Creates and exports a searchlight volume that is based on a specified
% scoring function (e.g., classification, Hotelling's T-test).
% 
% This function operates in LEGACY mode (Princeton SUBJ format).
% 
% Implements the 'analysis_wrapper' interface.
%
% Additional named arguments:
%   ana_args.scoring_func
%   ana_args.scoring_args

% Kay H. Brodersen, ETHZ/UZH
% $Id: anaCreateStatmap.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = anaCreateStatmap(subj, settings, ana_args)
    
    % ---------------------------------------------------------------------
    % Initialization
    cancel = true;
    
    % Check compatibility
    assert(~(isfield(settings, 'legacy') && ~any(settings.legacy)), 'legacy settings expected');
    
    % Make subj compatible with Princeton 'subj' structure [legacy format]
    legacy_subj = init_subj('EXP','SUBJ');
    subj = mergestructs(subj, legacy_subj);
    
    % Designate output filename
    fileBase = fullfile(subj.dirOut, ['cy', num2str(subj.cy), '_map', num2str(settings.analysisId)]);
    fileBase = makeAbsolutePath(fileBase);
    
    % Skip existing results?
    try settings.skipExistingResults; catch; settings.skipExistingResults = false; end
    if settings.skipExistingResults
        wouldbeFilename = [fileBase,'.nii.gz'];
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            return;
        end
    end
    
    
    % ---------------------------------------------------------------------
    % Load labels
    try ana_args.loadTrainLabels_func; catch; ana_args.loadTrainLabels_func = settings.loadTrainLabels_func; end
    try ana_args.loadTrainLabels_args; catch; ana_args.loadTrainLabels_args = settings.loadTrainLabels_args; end
    try ana_args.loadTestLabels_func; catch; ana_args.loadTestLabels_func = settings.loadTestLabels_func; end
    try ana_args.loadTestLabels_args; catch; ana_args.loadTestLabels_args = settings.loadTestLabels_args; end
    
    % Get number of classes
    loadTrainLabels_func_actual = str2func(func2str(ana_args.loadTrainLabels_func));
    loadTestLabels_func_actual = str2func(func2str(ana_args.loadTestLabels_func));
    subj.nClasses = max([loadTrainLabels_func_actual(), loadTestLabels_func_actual()]);
    
    % Load labels (positive integers for normal trials; NaN for trials that
    % are to be ignored).
    subj.labels_train = loadLabels_wrapper(subj, ...
        ana_args.loadTrainLabels_func, ana_args.loadTrainLabels_args);
    subj.labels_test = loadLabels_wrapper(subj, ...
        ana_args.loadTestLabels_func, ana_args.loadTestLabels_args);
    if ~nanequals(subj.labels_train, subj.labels_test)
        out(['WARNING: Note that training labels and test labels are not identical!']);
    end
    
    % Ignore trials where train or test label is NaN
    subj.labels_train(isnan(subj.labels_train) | isnan(subj.labels_test)) = NaN;
    subj.labels_test(isnan(subj.labels_train) | isnan(subj.labels_test)) = NaN;
    
    % Load and apply custom trial filter?
    try ana_args.invertFilter; catch; ana_args.invertFilter = 0; end
    try ana_args.loadFilter_func; catch; ana_args.loadFilter_func = []; end
    try ana_args.loadFilter_args; catch; ana_args.loadFilter_args = []; end
    tmpFilter = loadFilter_wrapper(subj, ana_args.invertFilter, ...
        length(subj.labels_train), ana_args.loadFilter_func, ana_args.loadFilter_args);
    subj.labels_train(~tmpFilter) = NaN;
    subj.labels_test(~tmpFilter) = NaN;
    
    % Randomize labels?
    try ana_args.randomizeLabels; catch; ana_args.randomizeLabels = 0; end
    subj.labels_train = randomizeLabels(subj.labels_train, ana_args.randomizeLabels);
    if ana_args.randomizeLabels>0
        subj.labels_test = subj.labels_train;
    end
    
    
    % ---------------------------------------------------------------------
    % Load mask [legacy]
    try ana_args.loadMask_func; catch; ana_args.loadMask_func = settings.loadMask_func; end
    try ana_args.loadMask_args; catch; ana_args.loadMask_args = settings.loadMask_args; end
    subj = loadMaskLegacy_wrapper(subj, ana_args.loadMask_func, ana_args.loadMask_args);
    
    
    % ---------------------------------------------------------------------
    % Load data [legacy]
    try ana_args.loadTrainData_func; catch; ana_args.loadTrainData_func = settings.loadTrainData_func; end
    try ana_args.loadTrainData_args; catch; ana_args.loadTrainData_args = settings.loadTrainData_args; end
    try ana_args.loadTestData_func; catch; ana_args.loadTestData_func = settings.loadTestData_func; end
    try ana_args.loadTestData_args; catch; ana_args.loadTestData_args = settings.loadTestData_args; end
    
    loadData_scratch = [];
    [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
        ana_args.loadTrainData_func, ana_args.loadTrainData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_train');
    [subj, loadData_scratch] = loadDataLegacy_wrapper(subj, ...
        ana_args.loadTestData_func, ana_args.loadTestData_args, loadData_scratch, ...
        'useMemory', settings.useMemory, 'name', 'data_test');
    
    
    % ---------------------------------------------------------------------
    % Check dimensionality
    mat_train = get_mat(subj, 'pattern', 'data_train');
    mat_test = get_mat(subj, 'pattern', 'data_test');
    
    if ~all(size(mat_train)==size(mat_test))
        out(['ABORT: training and test data have a different dimensionality']);
        out(['    mat_train: ', mat2str(size(mat_train))]);
        out(['    mat_test:  ', mat2str(size(mat_test))]);
        return;
    end
    
    % Warn if features have NaN in some trial
    badFeatures = any(isnan(mat_train),2) | any(isnan(mat_test),2);
    n = sum(badFeatures);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' (out of ', num2str(length(badFeatures)), ...
            ') features have at least one NaN value']);
    end
    
    % Exclude all trials with a NaN in some feature (set their labels to 0)
    badTrials = any(isnan(mat_train),1) | any(isnan(mat_test),1);
    n = sum(badTrials);
    if n>0
        out(' ');
        out(['NOTE: ', num2str(n), ' trials have at least one NaN feature and will be ignored']);
        subj.labels_train(badTrials) = NaN;
        subj.labels_test(badTrials) = NaN;
    end
    
    % Write back
    subj = set_mat(subj, 'pattern', 'data_train', mat_train);
    subj = set_mat(subj, 'pattern', 'data_test', mat_test);
    
    
    % ---------------------------------------------------------------------
    % Feature processing
    % Note that this may modify the number of features and even the number
    % of examples and labels.
    try ana_args.processFeatures_func; catch; ana_args.processFeatures_func = []; end
    try ana_args.processFeatures_args; catch; ana_args.processFeatures_args = []; end
    subj = processFeatures_wrapper(subj, ana_args.processFeatures_func, ana_args.processFeatures_args, ...
        'paired_data', true);
    
    
    % ---------------------------------------------------------------------
    % Last preparations
    tmpMatSize = get_objfield(subj, 'pattern', 'data_train', 'matsize');
    subj.nFeatures = tmpMatSize(1);
    subj.nExamples = tmpMatSize(2);
    
    % Print some information about the mask
    tmpMask = get_object(subj, 'mask', 'the_mask');
    nVoxelsMask = sum(sum(sum(tmpMask.mat~=0)));
    out(['There are ', num2str(nVoxelsMask), ' voxels in this mask (= ', ...
        num2str(nVoxelsMask/subj.nFeatures*100), '% of all loaded voxels)']);
    
    % Final data check
    cancel = finalDataCheck(subj, settings);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create single outer fold (or several if blocks structure) in which
    % all trials are in the training set, and none in the test set.
    cv = ana_args.cv;
    cv.blockFilter = loadBlockFilter_wrapper(subj.dirScan, cv);
    cv.nClasses = subj.nClasses;
    cv.bSinglePeekingFoldOnly = true;
    cv.setSize = 1;
    
    [subj.folds, cancel] = createCvFolds(subj.labels_train, cv);
    if cancel; return; end
    
    
    % ---------------------------------------------------------------------
    % Create statmap (e.g., inner cross-validation, Hotelling's)
    subj = runStatmapsLegacy(subj, ana_args.statmap_func, ana_args.statmap_args);
    
    % Create the final map by averaging all maps
    % (usually 1 unless blocks structure)
    %
    % Note that, strictly speaking, this is only valid when a linear
    % performance measure is used, such as accuracies. In contrast, p
    % values should not be averaged across blocks. The reason that this
    % done in this way here is that blocks structures are not that
    % frequent, and we are using accuracies most of the time anyway, and
    % the runStatmapsLegacy function is shared between this analysis method
    % and anaPredictStatmap, which requires strict separation of outer
    % folds. A clean approach can be visited in statmap_searchlight_xval,
    % in which inner folds are combined correctly: not by averaging them
    % but by computing a single performance score based on the combination
    % of all predictions across all inner folds.
    %
    subj = averageStatmapsLegacy(subj, 'statmap', 'statmap_average');
    
    
    % -----------------------------------------------------------------
    % Save results as NIFTI file
    
    % Prepare map for export
    header_data_train = get_objfield(subj, 'pattern', 'data_train', 'header');
    header_statmap_average = get_objfield(subj, 'pattern', 'statmap_average', 'header');
    header_statmap_average.vol = header_data_train.vol;
    subj = set_objfield(subj, 'pattern', 'statmap_average', 'header', header_statmap_average);
    
    % Export map
    deleteIfExists([fileBase, '.hdr']);
    deleteIfExists([fileBase, '.img']);
    deleteIfExists([fileBase, '.nii.gz']);
    out(' ');
    out(['Exporting to ', fileBase]);
    write_to_analyze(subj, 'pattern', 'statmap_average', 'output_filename', fileBase);
    tryFsl(['fslchfiletype NIFTI_GZ ', fileBase, '.hdr']);
    if exist([fileBase, '.nii.gz'], 'file')
        out('File successfully written');
    else
        error('File not written?');
    end
    
end
