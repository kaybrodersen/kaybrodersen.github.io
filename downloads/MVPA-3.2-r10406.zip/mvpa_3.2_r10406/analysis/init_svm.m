% Initializes the SVM classifier.
%
% Usage:
%     class_args = init_svm(class_args)
%
% Adapted from the MVPA toolbox.
% -------------------------------------------------------------------------
function class_args = init_svm(class_args)
    
    % Initialize kernel string
    class_args.kernelString = makeKernelString(class_args);
    
end

% -------------------------------------------------------------------------
function kernelString = makeKernelString(in_args)
    verbose = true;
    
    % Initialize kernel string
    kernelString = '';
    
    % General options
    % - verbosity mode
    if isfield(in_args, 'verbosity')
        if ~isint(in_args.verbosity) || (in_args.verbosity < 0) || (in_args.verbosity > 3)
            error('verbosity must be an integer between 0 and 3')
        end
        kernelString = [kernelString, ' -v ', num2str(in_args.verbosity)];
    end
    
    % Learning options
    % - trade-off between training error and margin
    if isfield(in_args, 'c')
        kernelString = [kernelString, ' -c ', num2str(in_args.c)];
    end
    % - remove inconsistent training examples
    if isfield(in_args, 'remove_inconsistent')
        if in_args.remove_inconsistent ~= 0 && in_args.remove_inconsistent ~= 1
            error('remove_inconsistent must be 0 or 1');
        end
        kernelString = [kernelString, ' -i ', num2str(in_args.remove_inconsistent)];
    end
    
    % Kernel options
    if isfield(in_args, 'kernel_type')
        % If no args, simply assume linear kernel
        kernelString = [kernelString, ' ', sprintf('%s%d', '-t ', 0)];
    elseif ~isnumeric(in_args.kernel_type)
        error('Kernel Type has to be a number. Please see HELP');   
    elseif in_args.kernel_type>3
        error('Specify Kernel types between 0 to 3 only, See HELP');
    elseif in_args.kernel_type == 0  
        out('Linear kernel', verbose);
        kernelString = [kernelString, ' ', sprintf('%s%d', '-t ', in_args.kernel_type)];
            
    elseif in_args.kernel_type == 1
        out('Polynomial kernel', verbose);
        kernelString = [kernelString, ' ', sprintf('%s%d', '-t ', in_args.kernel_type)]; 
        if ~isfield(in_args,'coef_lin')
            out('Please specify the linear coefficient or use default');
        else  
            kernelString = [kernelString, ' ', sprintf('%s%f',' -s ',in_args.coef_lin)];
        end     
        if ~isfield(in_args,'coef_const')
            out('Please specify the constant coefficient or use default');
        else  
            kernelString = [kernelString, ' ', sprintf('%s%f' ,' -r ',in_args.coef_const)];
        end     
        if ~isfield(in_args,'poly_degree')
            out('Please specify the degree of the polynomial or use default');
        else  
            kernelString = [kernelString, ' ', sprintf('%s%f',' -d ',in_args.poly_degree)];
        end      

    elseif in_args.kernel_type == 2
        out('RBF kernel', verbose);  
        kernelString  = [kernelString, ' ', sprintf('%s%d','-t ', in_args.kernel_type)];
        if ~isfield(in_args,'rbf_gamma')
            out('Please specify the rbf gamma or use default');
        else  
            kernelString = [kernelString, ' ', sprintf('%s%f',' -g ',in_args.rbf_gamma)];   
        end

    elseif in_args.kernel_type == 3
        out('Sigmoid kernel', verbose);  
        kernelString = [kernelString, ' ', sprintf('%s%d', '-t ', in_args.kernel_type)];
        if ~isfield(in_args,'coef_lin')
            disp('Please specify the linear coefficient or use default');
        else  
            kernelString = [kernelString, ' ', sprintf('%s%f',' -s ',in_args.coef_lin)];
        end
        if ~isfield(in_args,'coef_const')
            out('Please specify the constant coefficient or use default');
        else  
            kernelString = [kernelString, ' ', sprintf('%s%f' ,' -r ',in_args.coef_const)];
        end  
    end

    % Optimization options
    % - cache size for kernel evaluations in MB
    if isfield(in_args, 'cache')
        kernelString = [kernelString, ' -m ', num2str(in_args.cache)];
    end
    % - max_iterations
    if isfield(in_args, 'max_iterations')
        if ~isint(in_args.max_iterations)
            error('max_iterations must be an integer');
        elseif in_args.max_iterations < 10
            error('max_iterations value seems weird');
        end
        kernelString = [kernelString, ' -# ', num2str(in_args.max_iterations)];
    end
    
    % Print result
    out(kernelString, verbose);
    
end
