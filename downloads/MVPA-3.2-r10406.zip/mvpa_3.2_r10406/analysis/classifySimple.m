% Classifies with simple given mask (i.e., no further feature selection)
% (Note that the mask is the same for all folds; therefore, its generation
% must not have dependend on class labels.)
%
% Implements the 'analysis_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: classifySimple.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [results, cancel] = classifySimple(subj, settings, cy, ana_args)
    
    % Get some general information
    nVoxels = get_objfield(subj, 'pattern', 'data_train', 'matsize');
    nVoxels = nVoxels(1);
    try
        tmpMask = get_object(subj, 'mask', 'the_mask');
        nVoxelsMask = sum(sum(sum(tmpMask.mat~=0)));
        out(['There are ', num2str(nVoxelsMask), ' voxels in this mask (= ', ...
            num2str(nVoxelsMask/nVoxels*100), '% of all loaded voxels)']);
    catch % note backwards compatibility
        out('(No mask present)');
    end
    
    % Initialize results
    results = [];
    cancel = false;
    
    % Optionally: check whether results have already been computed during
    % an earlier run of this analysis
    if isfield(ana_args, 'skipExistingResults') && ana_args.skipExistingResults
        wouldbeFilename = makeAbsolutePath(...
            saveClfResults(subj, settings, cy, [], 'previewFilenameOnly', true));
        if exist(wouldbeFilename, 'file')
            out(['Detected existing file ', wouldbeFilename]);
            out(['Skipping this cycle as results already present']);
            cancel = true;
        end
    end
    if cancel
        return;
    end
    
    % ---------------------------------------------------------------------
    % Create outer folds
    
    % Load block filter (if any)
    blockFilter = loadBlockFilter_wrapper(subj.dirScan, length(settings.blockLengths), ...
        settings.loadBlockFilter_func, settings.loadBlockFilter_args);
    
    % Create CV indices
    [subj, cancel] = createCvIndices(subj, ...
        'blockLengths', settings.blockLengths, ...
        'blockFilter', blockFilter, ...
        'bShuffle', false, ... % trial shuffling means left-over trials will be somewhere randomly rather than as a block at the end
        'setSize', ana_args.outerSetSize, ...
        'bSinglePeekingFoldOnly', false, ...
        'balancingCriteria', subj.labels, ... % labels are to be balanced
        'overallRepetitions', ana_args.overallRepetitions, ...
        'overallBalancingType', ana_args.overallBalancingType, ...
        'minPatternsPerClass', ana_args.minPatternsPerClass, ...
        'randomCrossValidation', ana_args.randomCrossValidation, ...
        'outerFoldwiseBalancingType', ana_args.outerFoldwiseBalancingType, ... 
        'outerFoldwiseBalancingRepetitions', ana_args.outerFoldwiseBalancingRepetitions, ...
        'outerFoldwiseExclusion', ana_args.outerFoldwiseExclusion, ...
        'outerTestFilter', ana_args.outerTestFilter, ...
        'keepSubjectsSeparate', false); % across subjects clf?
    
    % Check that we have created some folds
    if cancel
        % No folds created. This means there was no data left after all
        % filtering and balancing.
        return;
    end
    
    % Display how many test trials we are operating with
    if isfield(ana_args, 'outerTestFilter')
        tmpReps = [subj.indices.folds(:).reps];
        tmpTests = [tmpReps.test];
        nTestTrials = unique(tmpTests);
        out(' ');
        out(['ACROSS ALL OUTER FOLDS, THERE ARE ', num2str(length(nTestTrials)), ' TEST CASES ', ...
            mat2str(nTestTrials)]);
        out(' ');
    end
    
    % ---------------------------------------------------------------------
    % Classification by outer cross validation
    
    % Initialize (outer) classifier
    ana_args.outer_class_args = init_wrapper(...
        ana_args.outer_class_args.init_func, ana_args.outer_class_args);
    
    % Set up (outer) classifier
    patgroup_train = 'data_train';
    patgroup_test = 'data_test';
    regsname = 'labels';
    maskgroup = 'the_mask';
    outer_class_args = ana_args.outer_class_args;
    
    % Run (outer) classifier
    out('Running (outer) classifier...');
    [subj, results] = runCrossValidation(subj, ...
        patgroup_train, regsname, maskgroup, outer_class_args, ...
        'patgroup_test', patgroup_test);
    
    % Print results
    out(' ');
    out('OVERALL RESULTS FOR THIS SUBJECT AND CYCLE');
    printResults(results);
    out(' ');
	
    % Save results
    saveClfResults(subj, settings, cy, results);
    
end
