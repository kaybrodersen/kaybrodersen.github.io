% Training function for LIBSVM.
%
% See 'train_wrapper' interface.
%
% Custom arguments:
%     nClasses: number of classes in data (default: 2)
%     libsvm_options: string that will be passed on to LIBSVM
%     duplifyData (experimental): true or false (default)

% Kay H. Brodersen, ETHZ/UZH
% $Id: train_libsvm.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scratch = train_libsvm(mat_train, labels_train, args)
    
    % Check input
    defaults.nClasses = 2;
    defaults.libsvm_options = '';
    defaults.duplifyData = false;
    args = mergestructs(args, defaults);
    
    assert(~any(any(isnan(mat_train))), 'there are NaN values in the data');
    assert(args.nClasses==2, 'libsvm cannot deal with anything but 2 classes?');
    assert(containsOnly(labels_train, [1 2]), 'labels must be 1s and 2s');
    
    % Transform labels from [1 2] to [1 -1]
    labels_train(labels_train==2) = -1;
    
    % Duplify training data?
    if args.duplifyData
        mat_train = duplifyData(mat_train);
        labels_train = [labels_train, labels_train];
    end
    
    % Train (.mex)
    %model = svmtrain(labels_train(:), mat_train', args.libsvm_options);
    [~,model] = evalc(['svmtrain(labels_train(:), mat_train'', args.libsvm_options);']);
    
    % Check for errors
    if isempty(model)
        % Run again, this time with errors being output to the console
        svmtrain(labels_train(:), mat_train', args.libsvm_options)
        error('returned model is empty');
    end
    
    % Return model (needed for test)
    scratch.model = model;
    
    % Return other interesting things (for recollection)
    scratch.args = args;
    
    % Also return the true labels_train of the support vectors. These will be
    % needed to work out the feature weights (see @recollect_conf_libsvm).
    try
    if isstruct(model)
        tr = reshape(mat_train,size(mat_train,1)*size(mat_train,2),1);
        scratch.sv_labels = NaN(1,size(model.SVs,1));
        for a = 1:size(model.SVs,1)
            sv = full(model.SVs(a,:))';
            sv = repmat(sv,size(mat_train,2),1);
            comp = (tr == sv);
            comp = reshape(comp, size(mat_train,1), size(mat_train,2));
            [idx,idx] = find(all(comp,1));
            idx = idx(1);
            scratch.sv_labels(a) = labels_train(idx);
        end
    end
    end
    
end
