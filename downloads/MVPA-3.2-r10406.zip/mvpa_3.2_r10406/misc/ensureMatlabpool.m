% Ensures a 'matlabpool' is opened.
%
% Usage:
%     ensureMatlabpool
%
% Example:
%     ensureMatlabpool
%     parfor ...
%        ...
%     end

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function ensureMatlabpool
    
    % Matlabpool initialized yet?
    n = matlabpool('size');
    
    if n==0
        out('Initializing matlabpool...');
        matlabpool
        out(['Matlabpool initialized with ', num2str(n), ' workers']);
        
        out('Testing matlabpool...');
        increaseIndent;
        testMatlabpool;
        decreaseIndent;

    else
        out(['(Matlabpool already initialized, ', num2str(n), ' workers)']);
    end
    
testMatlabpool;
end

% -------------------------------------------------------------------------
% Simple test of parfor
function testMatlabpool
    
    result = zeros(1,10);
    tic
    parfor x = 1:10
        out(['(', num2str(x),')']);
        pause(1);
        thisResult = x*x;
        result(x) = thisResult;
    end
    t = toc;
    out(['Time elapsed: ', num2str(t)]);
    
end
