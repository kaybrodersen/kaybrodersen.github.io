% Duplicates a data matrix and adds noise to the duplicated examples.
%
% Usage:
%     data = duplifyData(data);
% 
% Input argument:
%     data: m FEATURES x n EXAMPLES matrix
% 
% Return value:
%     data: m FEATURES x 2n EXAMPLES matrix

% Kay H. Brodersen, ETHZ/UZH
% $Id: duplifyData.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function data = duplifyData(data)

% figure;
% scatter(data(:,1),data(:,2));

    s = std(data,0,2);
    r = rand(size(data))-0.5;
    k = 5;
    data_noisy = data + k*r.*repmat(s/10,1,size(data,2));
    data = [data, data_noisy];

% hold on;
% scatter(data_noisy(:,1),data_noisy(:,2),'r');

    
end
