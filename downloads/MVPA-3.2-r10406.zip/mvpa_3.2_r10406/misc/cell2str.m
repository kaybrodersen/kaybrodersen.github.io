% Converts the contents of a cell array into a string.
%
% Example:
%    c = {[1,2,3], [4, 5]};
%    disp(cell2str(c));
% 
% See also:
%    mat2str

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function str = cell2str(c)

    str = '{';
    for i=1:length(c)
        if isstr(c{i})
            str = [str, '''', c{i}, ''', '];
        else
            str = [str, mat2str(c{i}), ', '];
        end
    end
    str = [str(1:end-2), '}'];
    
return;