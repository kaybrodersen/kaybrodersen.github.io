% -------------------------------------------------------------------------
function m = getCombinationMatrix(criteria, verbose)
    [types1, freqs1] = analyseCriterion(criteria(1,:));
    [types2, freqs2] = analyseCriterion(criteria(2,:));
    
    m = zeros(2,2);
    
    for t1=1:2
        for t2=1:2
            try
                m(t1,t2) = sum(criteria(1,:)==types1(t1) & criteria(2,:)==types2(t2));
            end
        end
    end
    out(' ', verbose>1);
    out('Combination matrix:', verbose>1);
    out(mat2str(m(1,:)), verbose>1);
    out(mat2str(m(2,:)), verbose>1);
end
