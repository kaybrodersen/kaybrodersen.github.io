% Tries to obtain a licence for the Statistics Toolbox. Keeps trying until
% it succeeds.
%
% Usage:
%     tryLicence(interval)
%
% Parameters:
%     interval - number of seconds to wait between two attempts
%                   (default: 10)
% -------------------------------------------------------------------------
function tryLicence(interval)
    
    % Check input
    if ~exist('interval', 'var')
        interval = 10;
    end
    if (interval < 1)
        error('interval should be a positive integer');
    end
    
    licenceOk = false;
    while ~licenceOk
        try
            % Try to claim licence (suppressing output)
            evalc('binocdf(8,10,0.5);');
            licenceOk = true;
        catch
            % If failed, wait, then repeat
            fprintf('.');
            pause(interval);
        end
    end

end