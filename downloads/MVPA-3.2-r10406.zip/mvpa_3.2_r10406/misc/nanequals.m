% NANEQUALS - Determines whether two matrices (or scalars or vectors) are
% equal, where two numbers of also considered equal when both NaN. Works
% for up to 3-dimensional matrices.
% 
% Usage:
%     areEqual = nanequals(a, b)
%
% Examples:
%     nanequals([1 2 NaN], [1 2 NaN]) --> 1
%     nanequals([1 NaN 3], [1 2 3]) --> 0

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function areEqual = nanequals(a, b)
    
    %areEqual = sum((a(:) ~= b(:)) & ~((isnan(a(:)) & isnan(b(:))))) == 0;
    if ndims(a)>3 || ndims(b)>3
        error('not implemented for ndims>3');
    end
    areEqual = all(all(all((a==b) | (isnan(a) & isnan(b)))));
    
end