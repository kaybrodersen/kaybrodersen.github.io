% Pulls out the current axis object and displays it in a new figure.
% For example, click on a subplot and then run the function.

% -------------------------------------------------------------------------
function pullout
    ah = gca;
    fh = gcf;
    
    color = get(fh,'color');
    nfh = figure;
    set(nfh,'color',color);
    nah = copyobj(ah,nfh);
    set(nah,'position',[.1 .1 .8 .8]);
    
end
