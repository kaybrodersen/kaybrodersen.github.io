% containsOnly: checks whether the vector or matrix 'x' only contains
% values specified in the vector or matrix 'y'.
%
% Example:
%     x = [1 2 3 3 3 7];
%     y = [1 2 3];
%     containsOnly(x, y) --> false
% 
% If x is empty, returns true.
% NaN is treated as a normal number.

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function bResult = containsOnly(x, y)

    % Transform inputs
    x = x(:); x = unique(x);
    y = y(:); y = unique(y);
    nanOk = logical(sum(isnan(y)));
    
    % Initialize return value
    bResult = true;
    
    % Check each element
    for i=1:length(x)
        if (sum(x(i) == y) == 0) && (~(nanOk && isnan(x(i))))
            bResult = false;
            break;
        end
    end

return;