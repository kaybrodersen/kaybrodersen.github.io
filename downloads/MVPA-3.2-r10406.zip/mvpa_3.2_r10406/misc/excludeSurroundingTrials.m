% Removes the test set and the trials surrounding the test set from the
% training set.

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function set = excludeSurroundingTrials(set, testSet, exclusion)
    
    % Check input
    exclusion = exclusion(:)';
    if length(exclusion)~=2 ...
            || exclusion(1)<0 || exclusion(2)<0 ...
            || isnan(sum(exclusion)) ...
            || fix(exclusion(1))~=exclusion(1) || fix(exclusion(2))~=exclusion(2) ...
            || exclusion(1)==inf || exclusion(2)==inf ...
            || exclusion(1)==-inf || exclusion(2)==-inf
        error('invalid exclusion criteria');
    end
    
    % Remove test set itself
    oldLength = length(set);
    for i=1:length(testSet)
        set(set==testSet(i)) = [];
    end
    newLength = length(set);
    n = newLength - oldLength;
    if n>0
        out(['Removed ', num2str(n), ' test trial(s) from training set'])
    end
    
    % Detect trivial cases
    if isempty(testSet) ...
            || (exclusion(1)==0 && exclusion(2)==0) ...
            || isempty(set)
        return;
    end
    
    % Make exclusion candidates
    ts = sort(testSet);
    cands = [];
    if exclusion(1) > 0
        cands = [cands, ts(1)-exclusion(1):ts-1];
    end
    if exclusion(2) > 0
        cands = [cands, ts(end)+1:ts(end)+exclusion(2)];
    end
    
    % Remove candidates
    oldLength = length(set);
    for i=1:length(cands)
        set(set==cands(i)) = [];
    end
    newLength = length(set);
    n = newLength - oldLength;
    if n>0
        out(['Removed ', num2str(n), ' test-set-surrounding trial(s) from training set'])
    end
    
end