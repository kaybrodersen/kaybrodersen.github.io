% Checks whether a filter is a proper filter. This function is used
% by 'loadFilter_wrapper' and 'loadBlockFilter_wrapper'.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function filter = checkFilter(filter, nElements)
    if (size(filter,1)>1) && (size(filter,2)>1)
        error('filter must be a vector');
    end
    filter = filter(:)';
    if exist('nElements','var') && ~isempty(nElements)
        if ~isempty(filter) && (length(filter) ~= nElements)
            error('''filter'' has incorrect length');
        end
    end
    if ~containsOnly(filter, [0 1])
        error('filter must only contain 0''s and 1''s');
    end
end
