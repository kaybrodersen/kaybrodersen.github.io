% Creates a list of balanced indices.
%
% Returns a vector of trial indices such that (i) criteria are balanced
% according to the given balancing mode, and (ii) the number of indices is
% a multiple of setSize.
% 
% N.B. In the current implementation, condition (ii) is strictly enforced,
% whereas a slight class imbalance may remain.
% N.B. In this variant, only a single criterion is allowed.
% 
% Usage:
%     idx = getBalancedIndices(pool, criteria, balancingType, setSize, verbose)
%
% Arguments:
%     pool: given set of indices, e.g., [1 2 3 4  9 10 11 12]
%     criteria: matrix of criteria, e.g., [0 0 1 1  0 1 1 1; 1 1 1 1 0 0 0 0]
%     balancingType (default = 0): determines the strategy for balancing
%         0: no balancing;  1: by deletion;  2: by duplication
%     setSize (optional, default=1): resulting indices will be a multiple
%         of setSize
%     verbose (optional, default=2): level of output detail (0, 1, 2)
%
% IMPORTANT: the indices in 'pool' will reference elements in 'criteria'.
% Thus, DO NOT call the function in this way: getBalancedIndices(myIndices,
% classes(myIndices)). Instead, call it using:
% getBalancedIndices(myIndices, classes).

% Kay H. Brodersen, University of Oxford
% $Id: getBalancedIndices_old.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function idx = getBalancedIndices(pool, criteria, balancingType, setSize, verbose)

    % Check input
    if isempty(criteria)
        error('not implemented yet; try giving criteria but setting balancingType=0');
    end
    nSamples = length(pool);
    if ~isempty(criteria)
        if size(criteria,1)>1
            error('multiple criteria not implemented in this variant');
        end
        criterion = criteria(1,:);
        if length(criterion) < max(pool)
            error('indices in pool exceed length of criterion');
        end
    else
        criterion = [];
    end
    if ~exist('setSize','var')
        setSize = 1;
    end
    if setSize < 1
        error('invalid setSize');
    end
    if ~exist('verbose','var')
        verbose = 2;
    end
    
    % Initialize return value
    idx = pool;
    clear pool;
    
    % Remove all trials with a NaN criterion
    n = sum(isnan(criteria(idx)));
    if n>0
        out(['Ignoring ', num2str(n), ' trial(s) with a NaN criterion: ', ...
            mat2str(idx(isnan(criteria(idx))))]);
        idx(isnan(criteria(idx))) = [];
    end
    
    % ---------------------------------------------------------------------
    % Step 1: balance indices
    out('Index processing, step 1: balancing indices', verbose>1);
    increaseIndent;
    
    % Get criterion frequencies
    [types, freqs] = analyseCriterion(criterion(idx));
    out(['Criterion types are: ', mat2str(types)], verbose>1);
    out(['Criterion freqs are: ', mat2str(freqs)], verbose>1);
    
    % Balancing at all necessary?
    if sum(freqs == max(freqs)) == length(freqs)
        out('No imbalance, skipping step 1.', verbose>1);
        
    else
        % Prepare new result
        newIdx = [];
        
        % No balancing?
        if (balancingType == 0)
            % No modifications
            out(['No balancing requested, keeping all ', num2str(length(idx)), ' indices'], verbose>1);
            newIdx = idx;
        
        % Balancing by deletion?
        elseif (balancingType == 1)
            % Idea: within each criterion type, delete surplus trials so that
            % all types have the same frequency 'leastFrequentCount'.
            out('Starting balancing by deletion', verbose>1);
            increaseIndent;
            leastFrequentCount = min(freqs);
            
            % Go through all types in criterion 1/1
            for t = types
                type_idx = idx(criterion(idx) == t);
                surplus = sum(criterion(idx) == t) - leastFrequentCount;
                type_idx = shuffle(type_idx);
                type_idx(1:surplus) = [];
                newIdx = [newIdx, type_idx];
                if (surplus > 0)
                    out(['Deleted ', num2str(surplus), ...
                        ' random trials of type ', num2str(t)], verbose>1);
                end
            end
            decreaseIndent;
            
        % Balancing by duplication?
        elseif (balancingType == 2)
            % Idea: within each criterion type, duplicate trials so that all
            % types have the same frequency 'mostFrequentCount'.
            out(['Starting balancing by duplication'], verbose>1);
            increaseIndent;
            mostFrequentCount = max(freqs);
            newIdx = idx;
            
            % Go through all types in criterion 1/1
            for t = types
                type_idx = newIdx(criterion(newIdx) == t);
                originalShortage = mostFrequentCount - sum(criterion(newIdx) == t);
                shortage = originalShortage;
                while (shortage > 0)
                    tmpIdx = [];
                    type_idx = shuffle(type_idx);
                    tmpIdx = [tmpIdx, type_idx(1:min(shortage,length(type_idx)))];
                    newIdx = [newIdx, tmpIdx];
                    shortage = mostFrequentCount - sum(criterion(newIdx) == t);
                end
                if (originalShortage > 0)
                    out(['Duplicated ', ...
                        num2str(mostFrequentCount - sum(criterion(idx) == t)), ...
                        ' random trials of type ', num2str(t)], verbose>1);
                end
            end
            decreaseIndent;
        
        else
            error('invalid balancingType');
        end
        
        % Make intermediary result
        idx = sort(newIdx);
    end
    out(['Left with ', num2str(length(idx)), ' indices: ', mat2str(idx)], verbose>1);
    decreaseIndent;
    
    % ---------------------------------------------------------------------
    % Step 2: make number of indices a multiple of 'setSize'
    out(['Index processing, step 2: making number of indices a multiple of setSize=', num2str(setSize)], verbose>1);
    increaseIndent;
    
    % Get criterion frequencies
    [types, freqs] = analyseCriterion(criterion(idx));
    out(['Criterion types are: ', mat2str(types)], verbose>1);
    out(['Criterion freqs are: ', mat2str(freqs)], verbose>1);
    
    % Come up with a random order of unique classes
    rOrder = shuffle(zerounique(criterion));
    
    % Multiple-assurance is always by deletion, never by duplication
        
    % How much overall surplus?
    surplus = mod(length(idx), setSize);
    if (surplus == 0)
        out('No overall surplus, therefore no modifications necessary', verbose>1);
    else
    % Delete trials, one after another, of a particular class, in this
        % order, until balanced
        increaseIndent;
        for d=0:surplus-1
            % From which type to delete?
            t = rOrder(mod(d,length(rOrder))+1);
            % Find a random index of this class to delete
            class_idx = idx(criterion(idx)==t);
            class_idx = shuffle(class_idx);
            index_to_delete = class_idx(1);
            % Delete this index
            idx(idx==index_to_delete) = [];
        end
        out(['Deleted ', num2str(surplus), ' random trials', ...
            ', left with ', num2str(length(idx)), ...
            ' total indices (', num2str(length(unique(idx))), ' unique)'], verbose>1);
        decreaseIndent;
    end
    out(['Left with ', num2str(length(idx)), ' indices'], verbose>1);
    decreaseIndent;

%     % Multiple-assurance by duplication?
%     elseif (balancingType==2) || (balancingType==0)
%         
%         % How much overall shortage?
%         shortage = mod(setSize - length(idx), setSize);
%         if (shortage==0)
%             out('No overall shortage, therefore no modifications necessary', verbose>1);
%         else
%             % Duplicate trials, one after another, of a particular class,
%             % in this order, until balanced
%             increaseIndent;
%             for d=0:shortage-1
%                 % From which type to duplicate?
%                 t = rOrder(mod(d,length(rOrder))+1);
%                 % Find a random index of this class to duplicate
%                 class_idx = idx(criterion(idx)==t);
%                 class_idx = shuffle(class_idx);
%                 index_to_duplicate = class_idx(1);
%                 % Duplicate this index
%                 idx = sort([idx, index_to_duplicate]);
%             end
%             out(['Duplicated ', num2str(shortage), ' random trials', ...
%                 ', now ', num2str(length(idx)), ...
%                 ' total indices (', num2str(length(unique(idx))), ' unique)'], verbose>1);
%             decreaseIndent;
%         end
%         
%     else
%         error('invalid balancing type');
%     end
%     
    % Does a small class imbalance remain?
    [types, freqs] = analyseCriterion(criterion(idx));
    out(['--> Type frequencies in criterion 1/1 are now: ', mat2str(freqs)], verbose>1);
    if sum(diff(freqs)~=0)>0
        out(['(The remaining imbalance is a result of no balancing being requested or of ensuring multiplicity)'], verbose>1);
    end
    
end
