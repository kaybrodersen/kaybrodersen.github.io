function V = spm_check_filename(V)
% Checks paths are valid and tries to restore path names
% FORMAT V = spm_check_filename(V)
%
% V - struct array of file handles
%__________________________________________________________________________
% Copyright (C) 2008 Wellcome Trust Centre for Neuroimaging

% Karl Friston
% $Id: spm_check_filename.m 3934 2010-06-17 14:58:25Z guillaume $

if isdeployed, return; end

% check filenames
%--------------------------------------------------------------------------
for i = 1:length(V)


    % see if file exists
    %----------------------------------------------------------------------
    if ~spm_existfile(V(i).fname)
        
        % try platform-specific home directory (KHB)
        %------------------------------------------------------------------
        fname = makeAbsolutePath(V(i).fname,'kbroders');
        V(i).fname = fname;
    end

end
