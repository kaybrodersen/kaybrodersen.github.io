% Finds scans.
% 
% Usage:
%     scans = findScans(dirScans)
%     scans = findScans(dirScans,maskScans)
%     [scans,m] = findScans(dirScans)
% 
% Arguments:
%     dirScans - directory, for example '~/studies/decmak/scans'
%     maskScans - mask for actual subjects (default: 'S_*')
% 
% Return values:
%     scans - cell array of subject names
%     m - number of subjects (length(scans))

% Kay H. Brodersen, ETH Zurich
% -------------------------------------------------------------------------
function [scans,m] = findScans(dirScans,maskScans)
    
    try, maskScans; catch; maskScans = 'S_*'; end
    scans = dir(fullfile(dirScans,maskScans));
    scans = {scans.name};
    m = length(scans);
    
end
