function s = diveIntoStruct(s)

    fn = fieldnames(s);
    if length(fn)==1
        s = getfield(s, fn{1});
    end

end
