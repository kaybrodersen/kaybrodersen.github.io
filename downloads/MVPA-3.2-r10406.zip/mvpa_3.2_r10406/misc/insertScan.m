% Replaces '[SCAN]' placeholders in a file or directory by a given subject
% idenfitier.
% 
% Usage:
%     str = insertScan(str, scan)
%
% Arguments:
%     str: a file or directory that may or may not contain a '[SUBJECT]'
%          or '[SCAN]' wildcard.
%     scan: a string to replace the wildcard
%
% Example:
%     str = insertScan('~/study/[SCAN]/mvpa', 'S_AP')

% Kay H. Brodersen, ETHZ/UZH
% $Id: insertScan.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function str = insertScan(str, scan)
    str = strrep(str, '[SUBJECT]', scan);
    str = strrep(str, '[subject]', scan);
    str = strrep(str, '[SCAN]', scan);
    str = strrep(str, '[scan]', scan);
end
