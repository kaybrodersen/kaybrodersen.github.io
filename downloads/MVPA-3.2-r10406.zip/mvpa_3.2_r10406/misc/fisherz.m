% Fisher's z transform. Converts a Pearson correlation coefficient to a
% variable that is normally distributed with standard deviation of
% 1/\sqrt(N-3).
function z = fisherz(r)
    z = .5.*(log(1+r)-log(1-r));
end
