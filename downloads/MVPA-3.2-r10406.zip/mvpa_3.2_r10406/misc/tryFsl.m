% tryFsl - Runs an external FSL command.
%
% Usage:
%     out = tryFsl(cmd);
%
% Examples:
%     disp(tryFsl('fslmaths'));

% Kay H. Brodersen, ETHZ/UZH
% $Id: tryFsl.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function out = tryFsl(cmd)

    % Check input
    if ~exist('cmd', 'var')
        error('no command specified');
    end
    if isempty(cmd)
        error('empty command');
    end
    
    % Modify command?
    % e.g., 'LD_LIBRARY_PATH=; '
    global FSL_COMMAND_PREFIX;
    if ~isempty(FSL_COMMAND_PREFIX)
        cmd = [FSL_COMMAND_PREFIX, cmd];
    end
    
    % Run command (using tryUnix)
    out = tryUnix(cmd);
    
end
