function [x x_highres hrf t_hrf xtd] = hrf_convolve(s, res, tr)

% [x x_highres hrf t xtd] = hrf_convolve(s, res, tr)
% 
% s is the stimulus at high temporal resolution
% res is the high temporal resolution (in seconds) that the convolution will be performed at
% tr is in seconds

 s=s(:)';

 sigma1=2.449; my1=6; % first gamma
 sigma2=4; my2=14;    % second gamma
 
 alpha1=my1^2/sigma1^2;
 beta1=my1/sigma1^2;
 alpha2=my2^2/sigma2^2;
 beta2=my2/sigma2^2;
 
 ratio=6;
 
 num_tr=100;
 t_hrf=[0.1:0.1:num_tr*tr];
 hrf = gammapdf(alpha1,beta1,t_hrf) - gammapdf(alpha2,beta2,t_hrf)/ratio;
 
 % KHB
 hrf = [hrf, zeros(1,size(s,2)-size(hrf,2))];
     
 x_highres = fftconv(s,hrf);
 x = demean(x_highres(tr/res:tr/res:end));

 
 xtd_highres = [0 diff(x_highres)];
 xtd = demean(xtd_highres(tr/res:tr/res:end));
