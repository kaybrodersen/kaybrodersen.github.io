% clearData - clears previously stored data in a memory directory
%
% Usage:
%     clearData(dirMem, file);
%     clearData(dirMem, file, verbose);
%
% Default parameters:
%     verbose = true

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function clearData(dirMem, file)
    
    % Check input
    try
        if strcmpi(file(end-3:end), '.mat')
            file = file(1:end-4);
        end
    end
    if ~exist('verbose', 'var')
        verbose = true;
    end
    
    % Does the file exist?
    completeFile = fullfile(dirMem, [file, '.mat']);
    if exist(completeFile, 'file')
        if verbose
            out(['Clearing previously stored file: ', completeFile]);
        end
        tryUnix(['rm -f ', completeFile]);
    else
        if verbose
            out(['(No previously stored files to be cleared)']);
        end
    end
    
return;