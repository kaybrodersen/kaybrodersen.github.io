% Deprecated - replaced by insertScan.
% -------------------------------------------------------------------------
function str = getScanDir(str, scan)
    str = insertScan(str, scan);
end
