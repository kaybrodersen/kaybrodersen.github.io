% Finalizes settings for a run. To be called by 'batchRun' and by
% 'mvpaAnalysis' (interactive mode).
%
% Usage:
%     settings = finalizeSettings(settings, ...);
%
% Arguments:
%     settings - settings struct
%
% Additional named arguments:
%     caller - 'batchRun' or 'mvpaAnalysis/interactive'
%     quiet - if true, no questions or tips will be shown
%
% The function checks fields, checks configurations, may make minor
% modifications, may ask questions.

% Kay H. Brodersen, ETHZ / UZH
% $Id: finalizeSettings.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function settings = finalizeSettings(settings, varargin)
    
    % Check input
    if ~exist('settings', 'var'), error('no settings struct'); end
    defaults.caller = '';
    defaults.quiet = false;
    args = propval(varargin, defaults);
    if ~stringInSet(args.caller, {'batchRun', 'mvpaAnalysis/interactive'}), error('illegal caller'); end;
    
    % Set directories
    settings.dirAnalysis = fullfile(settings.dirResults, ['analysis', num2str(settings.analysisId)]);
    settings.dirCode = fullfile(settings.dirAnalysis, 'code');
    settings.dirLog = fullfile(settings.dirAnalysis, 'log');
    
    % Set top configuration
    if stringInSet(args.caller, {'batchRun', 'mvpaAnalysis/interactive'})
        if ~isfield(settings, 'conf'), settings.conf = []; end
        if isfield(settings, 'confs')
            if length(settings.confs)==1
                settings.conf = 1;
            end
            while (isempty(settings.conf))
                out(' ');
                out('Choose a top configuration:');
                increaseIndent;
                for c=1:length(settings.confs)
                    thisConfname = '';
                    try
                        thisConfname = settings.confs(c).confname;
                    end
                    if ~isempty(thisConfname)
                        out([num2str(c), ' - ', settings.confs(c).confname]);
                    end
                end
                decreaseIndent;
                settings.conf = inputout('Top configuration: ');
            end
        settings = mergestructs(settings, settings.confs(settings.conf));
        out(['Top configuration: ', settings.confname]);
        settings = rmfield(settings, 'confs');
        end
    end    
    
    % Set analysis configuration
    if stringInSet(args.caller, {'batchRun', 'mvpaAnalysis/interactive'})
        if ~isfield(settings.main, 'conf'), settings.main.conf = []; end
        if isfield(settings.main, 'confs')
            if length(settings.main.confs)==1
                settings.main.conf = 1;
            end
            while isempty(settings.main.conf)
                out(' ');
                out('Choose an analysis configuration:');
                increaseIndent;
                for c=1:length(settings.main.confs)
                    thisConfname = '';
                    try
                        thisConfname = [settings.main.confs(c).confname, ' (', ...
                            func2str(settings.main.confs(c).ana_func), ')'];
                    catch
                    end
                    if ~isempty(thisConfname)
                        out([num2str(c), ' - ', settings.main.confs(c).confname]);
                    end
                end
                decreaseIndent;
                settings.main.conf = inputout('Analysis configuration: ');
            end
            settings.main = settings.main.confs(settings.main.conf);
            out(['Analysis configuration: ', settings.main.confname]);
        end
    end
    
    % Set batch configuration
    if stringInSet(args.caller, {'batchRun'})
        if ~isfield(settings.batch, 'conf'), settings.batch.conf = []; end
        if isfield(settings.batch, 'confs')
            if length(settings.batch.confs)==1
                settings.batch.conf = 1;
            end
            while isempty(settings.batch.conf)
                out(' ');
                out('Choose a batch configuration:');
                increaseIndent;
                for c=1:length(settings.batch.confs)
                    try
                        out([num2str(c), ' - ', settings.batch.confs(c).confname]);
                    catch
                    end
                end
                decreaseIndent;
                settings.batch.conf = inputout('Batch configuration: ');
            end
            settings.batch = mergestructs(settings.batch.confs(settings.batch.conf), settings.batch);
            %settings.batch = settings.batch.confs(settings.batch.conf);
            out(['Batch configuration: ', settings.batch.confname]);
            
            % Check for missing fields
            if ~isfield(settings.batch, 'via'), settings.batch.via=[]; end
            if ~isfield(settings.batch, 'self'), settings.batch.self=[]; end
        end
    end
    
    % Check memory settings
    if ~args.quiet
        if stringInSet(args.caller, {'batchRun'})
            if settings.useMemory
                out(['NOTE: useMemory is current enabled. It is strongly recommended to']);
                out(['disable this in batch mode.']);
                tmpDisable = input('   0=disable  1=keep enabled: ');
                if tmpDisable, settings.useMemory = false; end
                out(' ');
            end
        elseif stringInSet(args.caller, {'mvpaAnalysis/interactive'})
            if (settings.useMemory)
                out(' ');
                tmp = input('   useMemory is currently ACTIVE. 0=deactivate 1=continue [default] ');
                if ~isempty(tmp) && ~tmp
                    out('Setting useMemory = false');
                    settings.useMemory = false;
                end
            end
        end
    end
    
    % Check instance settings
    if stringInSet(args.caller, {'batchRun'})
        if length(settings.cycles) < settings.nInstances
            error(['You have specified ', num2str(length(settings.cycles)), ...
                ' cycles to be distributed across ', num2str(settings.nInstances), ...
                ' instances. Reduce settings.nInstances.']);
        end
    end
    
    % Warn if more than 121284 files will be created in any one directory
    if settings.nInstances + length(settings.cycles) > 120000  % 121284
        out(' ');
        out(['WARNING: Your scan-specific results directories might end up containing']);
        out(['too many files allowed for by the file system. You could reduce the number']);
        out(['of cycles to alleviate this problem. Press Ctrl+C to cancel, or any other']);
        out(['key to continue anyway.']);
        input('');
    end
    
    % If settings file was a .mat file from an earlier analysis, may want
    % to enable 'skipExistingResults'
    if ~args.quiet
        if strcmp(settings.origin, '.mat')
            if strcmp(func2str(settings.main.ana_func),'classifySimple')
                if isfield(settings.main.ana_args, 'skipExistingResults') ...
                    && settings.main.ana_args.skipExistingResults
                    out(' ');
                    out(['NOTE: according to settings, existing results will be skipped']);
                elseif ~isfield(settings.main.ana_args, 'skipExistingResults') ...
                    || ~settings.main.ana_args.skipExistingResults
                    out(' ');
                    out(['Since you are re-running an earlier settings file, you can choose to skip']);
                    out(['those analyses whose results are still present from previous runs.']);
                    increaseIndent;
                        out(['0 - fully rerun everything']);
                        out(['1 - skip existing results']);
                    decreaseIndent;
                    if inputout(['Skip existing results? ']);
                        settings.main.ana_args.skipExistingResults = true;
                    end
                end
            end
        end
    end
    
    % If settings file was a .mat file from an earlier analysis, we may
    % want to make further manual modification to the settings (after all,
    % rerunning without any modifications might lead to the same problems
    % as before).
    if ~args.quiet
        if strcmp(settings.origin, '.mat')
            while true
                out(' ');
                out(['Perhaps you want to make more manual modifications to the settings struct?']);
                increaseIndent;
                    out(['0 - run as is using ''', func2str(settings.batch.submit_func), '''']);
                    out(['1 - change submission function']);
                    out(['2 - make manual modifications']);
                decreaseIndent;
                in = inputout(['Make further modifications? ']);
                if in==0
                    break;
                elseif in==1
                    settings.batch.conf = [];
                    settings.batch.confs = batch_default_confs;
                    settings = prepareSettings(settings, 'batchRun');
                elseif in==2
                    out(' ');
                    out(['You can now modify the ''settings'' struct. Type ''return'' when you are done.']);
                    out(' ');
                    clear fileSettings
                    clear tmp
                    keyboard;
                end
            end
        end
    end
    
    % Check for common specific mistakes
    if ~args.quiet
        try
            if ~settings.main.ana_args.randomCrossValidation && settings.main.ana_args.overallRepetitions>1
                out(' ');
                out(['You have chosen normal cross-validation (as opposed to random).']);
                out(['Are you sure you want ', num2str(settings.main.ana_args.overallRepetitions), ...
                    ' overall repetitions rather than just 1?']);
                inputout(['(Ctrl+C to abort) ']);
            end
        end
    end
    
end
