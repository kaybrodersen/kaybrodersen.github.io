% Returns the unique elements of a vector, ignoring NaN.
% Example: nanunique([1 2 1 NaN])
%     returns [1 2]
function u = nanunique(x)
    u = unique(x);
    u(isnan(u))=[];
end
