% Performs Hotelling's T-test for two groups of points. Returns both the
% test statistic and its p value.
%
% Usage:
%     [T,P] = grouphotelling(X1, X2)
%
% Arguments:
%     X1: n1 EXAMPLES x m VARIABLES matrix
%     X2: n2 EXAMPLES x m VARIABLES matrix

% Kay H. Brodersen, ETZH/UZH
% $Id: grouphotelling.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [T,P] = grouphotelling(X1, X2)

    % Check input
    assert(~isempty(X1) && ~isempty(X2));
    if size(X1,2) ~= size(X2,2)
        error('the two groups must have the same number of variables (columns)');
    end
%     if size(X1,1)<size(X1,2)
%         error('there are more variables than examples in X1 - cannot run Hotellings test');
%     end
%     if size(X2,1)<size(X2,2)
%         error('there are more variables than examples in X2 - cannot run Hotellings test');
%     end
    
    X = [ones(size(X1,1),1), X1; 1+ones(size(X2,1),1), X2];
    [T,P] = T2Hot2ihe(X);

end
