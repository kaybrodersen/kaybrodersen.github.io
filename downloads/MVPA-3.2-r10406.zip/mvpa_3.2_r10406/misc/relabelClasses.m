% Relabel classes so that the most frequent class is now labelled 0, the
% second most frequent class is labelled 1, and so on.
%
% This has nothing to do with class balancing; it is merely done so that
% results can be compared: how good was classification on the frequent
% class, how good was it on less frequent classes?

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function classes = relabelClasses(classes)
    
    % Check input
    if (size(classes,1) >1) && (size(classes,2) > 1)
        error('classes must be a vector');
    end
    
    % How many different classes?
    nClasses = unique(classes);
    if nClasses > 2
        error('not implemented yet for more than 2 classes');
    end
    if isnan(classes)
        error('not implemented for NaN values yet');e
    end
        
    % Relabel
    tmp_choice_imbalance = sum(classes==0) - sum(classes==1);
    out(['Class imbalance = ', num2str(tmp_choice_imbalance)]);
    if (tmp_choice_imbalance ~= 0)
        % Get frequent class
        fc = (1-sign(tmp_choice_imbalance))/2;
        out(['    --> Frequent class was ''', num2str(fc), ''', is now ''0''']);
        
        % Convert classes: fc->0, ifc->1
        classes(classes==fc) = 99;
        classes(classes==(1-fc)) = 1;
        classes(classes==99) = 0;
    end

end