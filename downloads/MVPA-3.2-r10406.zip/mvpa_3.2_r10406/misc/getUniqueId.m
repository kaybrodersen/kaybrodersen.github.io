% Returns a hopefully unique number. This can be used when, for example, a
% temp file needs to be written in concurrent programming. When listing
% files created with this function, the alphabetical order will coincide
% with the temporal order of creation.
% 
% Usage:
%     id = getUniqueId
%
% The number is constructed as follows:
%     YYYYMMDD_HHMMSS_XXXXXX_RRRR
% where
%     YYYYMMDD is the current date
%     HHMMSS is the current time
%     XXXXXX is the current 100,000th second
%     RRRR are four (pseudo)random digits

% Kay H. Brodersen, ETHZ / UZH
% -------------------------------------------------------------------------
function id = getUniqueId

    c = clock; %c = round(c(6)*100);
    c = sprintf('%06d', round((c(6)-fix(c(6)))*1000000));
    id = [datestr(now, 'yyyymmdd_HHMMSS'), '_', num2str(c), '_', sprintf('%04d', round(rand*10000))];

end
