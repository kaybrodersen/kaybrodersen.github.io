% Returns a cell array of scan directories.
%
% Usage:
%     scans = locateScans(dirpattern)
%
% Input arguments:
%     dirpattern - e.g. '~/studies/aphasic_full/scans/S_* or
%         '~/studies/aphasic_full/scans/Z_A'
%
% Return values:
%     scans - cell array of pure directory names (without leading path)

% Kay H. Brodersen, ETZH/UZH
% $Id: locateScans.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function scans = locateScans(dirpattern)
    if exist(dirpattern)
        [~,scans] = fileparts(dirpattern);
        scans = {scans};
    else
        scans = dir(dirpattern);
        scans = {scans.name};
    end
end
