% tryUnix - Runs an external unix command. Throws an error if the command
% returns an error.
%
% Usage:
%     o = tryUnix(cmd);
%
% Examples:
%     disp(tryUnix('ls'));

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function o = tryUnix(cmd)

    % Check input
    if ~exist('cmd', 'var')
        error('no command specified');
    end
    if isempty(cmd)
        error('empty command');
    end
    
    % Run command
    try
        [s,o] = unix(cmd);
    catch e
        disp(['An error occurred while calling ''', cmd, '''']);
        out(e.getReport);
        rethrow(e)
    end
    if exist('s','var') && s~= 0
        disp(['An error occurred while calling ''', cmd, '''']);
        error(o);
    end
        
end