% Prepares a directory for dumping the workspace after an error has
% occurred, and changes into that directory.
%
% Usage:
%     afterError(settings, currentFunction);
%
% Arguments:
%     settings: current analysis settings file
%     currentFunction: name (string) of current m file
%
% Recommended usage:
%     try
%         code_that_could_lead_to_an_error;
%     catch
%         afterError(settings, mfilename);
%         if settings.errorHandling == 2, save workspace; end
%         rethrow(lasterror);
%     end
%
% Note that this usage is backwards-compatible with Matlab 2006a, whereas
% 'catch e ... rethrow (e)' would not be.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function afterError(settings, currentFunction)
    
    % Welcome
    out(' ');
    out('-------------------------------------------------------------------------');
    out('ERROR');
    out(['An exception has been caught by function ''', currentFunction, '''']);
    
    % Create dump directory?
    if settings.errorHandling == 2
        dirDump = fullfile(settings.dirAnalysis, ['dump-', currentFunction, '-', getUniqueId]);
        tryUnix(['mkdir -p ', dirDump]);
        if ~exist(dirDump, 'dir')
            dirDump = settings.dirBase;
            out(dirDump);
        end
        out('Dump directory created in:');
        out(dirDump);
        cd(dirDump);
    else
        out('In order to create a workspace dump, use settings.errorHandling == 2');
    end
    out(' ');
    out('-------------------------------------------------------------------------');
    out(' ');
    
end
