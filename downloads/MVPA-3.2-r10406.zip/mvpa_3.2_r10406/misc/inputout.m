% Like MATLAB's 'input' function, but also writes all output to a logfile,
% and allows for indentation.
% 
% Usage:
%     answer = inputout(str, enabled)
% 
% Arguments:
%     str: the string to print
%     enabled (optional, default=true): if false, no output will be
%         printed; for example, a function may routinely call:
%         out('Debug information...', bVerbose)

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function answer = inputout(str, enabled)
    global LOGFILE;
    global OUTPUT_INDENT;
    
    if ~exist('OUTPUT_INDENT', 'var') || isempty(OUTPUT_INDENT)
        OUTPUT_INDENT = 0;
    end
    OUTPUT_INDENT = round(OUTPUT_INDENT);
    if OUTPUT_INDENT < 0 || OUTPUT_INDENT > 30
        error('invalid value');
    end
    basicIndent = '   ';
    
    answer = [];
    if ~exist('enabled','var') || enabled
        % Prepend indent
        str = [repmat(basicIndent, 1, OUTPUT_INDENT), str];
        
        % Print to display
        answer = input(str);
        
        % Also write to logfile
        if isempty(LOGFILE) || (LOGFILE == -1)
            %error('no logfile id defined');
        else
            % Otherwise, write to logfile
            fprintf(LOGFILE, [str, '\n']);
        end
    end
    
end
