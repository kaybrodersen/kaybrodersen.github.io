function deleteIfExists(filename)

    if exist(filename, 'file')
        unix(['rm ', filename]);
    end

return;