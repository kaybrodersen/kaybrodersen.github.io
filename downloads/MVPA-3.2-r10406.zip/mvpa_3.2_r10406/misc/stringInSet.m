%STRINSET   Checks whether a string is in a set of strings.
%
%   Usage:
%   stringInSet('b', {'a', 'b', 'c'})
%

% Kay Henning Brodersen, created 18/05/2008
% -------------------------------------------------------------------------
function result = stringInSet(str, set)

    result = false;
    for i=1:length(set)
        if strcmp(str, set{i})
            result = true;
            break;
        end
    end

return;