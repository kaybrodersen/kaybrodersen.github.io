% memorizeData - stores data in a memory directory
%
% Can be used for subject-specific, computationally expensive data. File
% will always be made to have '.mat' extension. Use in conjunction with
% 'recallData.m'.
% 
% Usage:
%     memorizeData(dirMem, file, data);
%     memorizeData(dirMem, file, data, verbose);
%
% Default: verbose = true

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function memorizeData(dirMem, file, data, verbose)
    
    % Check input
    try
        if strcmpi(file(end-3:end), '.mat')
            file = file(1:end-4);
        end
    end
    if ~exist('verbose', 'var')
        verbose = true;
    end
    
    % Get path and filename
    [pathstr, name, ext] = fileparts(file);
    strPath = fullfile(dirMem, pathstr);
    completeFile = fullfile(strPath, [name, ext, '.mat']);
    
    % Create directory if necessary
    if ~exist(strPath, 'dir')
        mkdir(strPath);
    end
    
    % Store data
    if verbose
        out(['Memorizing file: ', completeFile]);
    end
    save(completeFile, 'data');

return;
