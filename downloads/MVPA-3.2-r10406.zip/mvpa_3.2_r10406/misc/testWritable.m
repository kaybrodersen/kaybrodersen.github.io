% Tests whether a given output directory is writable. Creates the directory
% if it doesn't exist.

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% -------------------------------------------------------------------------
function testWritable(dir)
    if ~exist(dir, 'dir')
        out(['Creating ''', dir]);
        unix(['mkdir -p ', dir]);
    end
    tmpFile = fullfile(dir, [getUniqueId, '.tmp']);
    try
        tryUnix(['touch ' tmpFile]);
        fid = fopen(tmpFile, 'w');
        fclose(fid);
        tryUnix(['rm ', tmpFile]);
    catch
        % Under Unix sometimes no longer writable if > 121284
        error(['Output directory ''', dir, ''' not writable! No write permissions? Too many files in directory?']);
    end
end
