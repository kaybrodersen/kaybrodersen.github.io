% Creates indices for cross-validation folds.
%
% Usage:
%     folds = createCvFolds(labels)
%     folds = createCvFolds(labels, varargin)
%     [folds, cancel] = createCvFolds(labels, varargin)
% 
% Example:
%     In order to create 100 leave-one-out cross-validation folds, type:
%     folds = createCvFolds([ones(1,50), 2*ones(1,50)])
% 
% Mandatory parameters:
%     labels: vector of true class labels (positive integers); in order to
%         ignore an example, set its label to NaN
% 
% Return values:
%     folds: struct array with the following structure:
%              folds().train
%              folds().test
%              where 'train' and 'test' contain trial numbers.
%     cancel: normally 'false'. If no folds were created because
%        of excessive filtering and balancing, will be set to 'true'
% 
% Parameters that provide useful context:
%     nClasses: number of classes; if not provided, will be estimated from
%        labels (i.e., max(labels))
% 
% Basis of indices:
%     pool: pool of indices to use. Default value is [1:length(labels)].
%         For example, for inner cross-validation you want to set pool to
%         the training indices of the current outer fold. Note that
%         duplicated in a provided pool will be ignored, i.e., any given
%         pool will first be set to unique(pool). IMPORTANT: throughout its
%         operation, createCvFolds will operate on indices into the pool
%         (i.e., indices of indices). Thus, when the output says 'trial 1'
%         it really means 'the first trial in pool'. Only at the very end,
%         when indices are written into the 'folds' struct will the
%         actual pool numbers be used. TIP: when using pool, make sure that
%         the labels that you provide are in relation to pool. Example:
%         createCvFolds(labels(outerTrainIdx), 'pool', outerTrainIdx);
%         And then access data and labels using 'folds' and labels (not
%         labels(pool)).
% 
% Cross-validation parameters:
%     setSize = desired number of samples per cross-validation fold, e.g.,
%         '1' for l-o-o cross-validation.
%     randomCrossValidation (default = false): By default (false), the test
%         set travels across the entire set of indices, from beginning to
%         end. This means that test trials will always be trials close to
%         one another. By contrast, setting randomCrossValidation to true
%         leads to a random subset of trials being chosen as test trials.
%         Thus, there is no such natural number of folds any more as there
%         is when the test set travels along. Specify the number of folds
%         using 'overallRepetitions'.
%     overallRepetitions (default = 1): determines how many times
%         balancing should be repeated. A value >= 2 only makes sense if
%         overallBalancingType is not 0.
%     bSinglePeekingFoldOnly (default = false): Normally, a group of
%         cross-validation folds is created. In contrast, if set to 'true',
%         a single peeking fold will be created instead. Its test indices
%         are the same as its training indices.
% 
% Class-balancing parameters:
%     overallBalancingType (default = 0): determines the strategy for
%         overall balancing (the balancing that is carried out on the
%         entire dataset, at the beginning of each overall repetition,
%         before outer folds are created).
%         0: no balancing;  1: by deletion;  2: by duplication
%     foldwiseBalancingType (default = 0): determines the strategy for
%         fold-wise balancing (the balancing that is carried out on the
%         training set, within each fold, in order to create balance on the
%         training set.)
%     balancingCriterion (default: labels): Instead of balancing class
%         labels, you can choose to balance any other measure.
% 
% Parameters to keep blocks separate:
%     blockLengths (optional, default = []): a vector
%         specifying, if the experiment has a blocks structure and blocks
%         are to be analysed separately, how many trials each block
%         comprises. Eg. [15 15 15 15] if there are 4 blocks of 15 trials
%         each.
%     blockFilter (optional, default = []): a vector specifying which
%         blocks should be considered only. Eg. [0 0 1 1] if only the last
%         two blocks should be considered.
%     bShuffle (optional, default=false): if this is set to 'true', then
%         samples will be shuffled. This means that left-over trials (due
%         to making the number of trials a multiple of setSize) will be
%         randomly distributed rather than collectively located at the
%         end). This has nothing to do with randomCrossValidation.
% 
% Parameters that control the exclusion of trials around the test set
%     foldwiseExclusion: number of trials to be excluded from the
%         outer training set before/after the beginning of the test set;
%         needs to be a vector of 2 elements, e.g. [1 2] to exclude 1
%         trial before and 2 trials after the test set. Default: [0 0]
%         Only has an effect if bSinglePeekingFoldOnly==false.
% 
% Parameters that control when a fold should not be created:
%     minExamplesPerClass (default = 2): determines how
%         many trials must be left per class after fold-wise class
%         balancing in order for a fold not to be excluded. This is also
%         applied at the beginning, to discard a whole block if too
%         unbalanced.
% 
% Parameters for across-subjects classification
%     keepSubjectsSeparate (default = false): Can be set to 'true' if in
%         across-subjects classification mode. Each fold will contain as
%         test set all trials from a particular subject. The parameter
%         'setSize' will be ignored. There will be <nSubjects> outer folds.
%     sids: a vector containing subject IDs for each trial, in analogy to
%         'labels'.
%
% Other parameters:
%     verbose (default: 0): level of output details (0, 1, 2)
% 
% TEMPORARY EXPERIMENTAL PARAMETERS
%     outerTestFilter: '' | 'switch' | 'stay'

% Kay H. Brodersen, University of Oxford
% $Id: createCvFolds_old.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [folds, cancel] = createCvFolds(labels, varargin)
    
    % Welcome
    out(' ');
    out('Creating CV folds...');
    
    % Set defaults
    defaults.nClasses = [];
    defaults.pool = [];
    defaults.setSize = 1;
    defaults.randomCrossValidation = false;
    defaults.overallRepetitions = 1;
    defaults.bSinglePeekingFoldOnly = false;
    defaults.overallBalancingType = 0;
    defaults.foldwiseBalancingType = 0;
    defaults.balancingCriterion = [];
    defaults.blockLengths = [];
    defaults.blockFilter = [];
    defaults.bShuffle = false;
    defaults.foldwiseExclusion = [0 0];
    defaults.minExamplesPerClass = 2;
    defaults.keepSubjectsSeparate = false;
    defaults.sids = [];
    defaults.outerTestFilter = '';
    defaults.verbose = 0;
    args = propval(varargin, defaults, 'strict', false);
    
    % Check verbose
    if ~containsOnly(args.verbose, [0 1 2])
        error('verbose must be 0, 1, or 2');
    end
    verbose = args.verbose;
    
    % Check labels and balancingCriterion
    if ~exist('labels', 'var')
        error('no labels input provided');
    end
    if isempty(labels)
        error('labels must not be empty');
    end
    labels = labels(:)';
    if args.nClasses>0 && ~containsOnly(labels, [NaN, 1:99])
        error('labels must be positive integers or NaN');
    end
    if isempty(args.balancingCriterion)
        out(['NOTE: no balancing criterion specified, will assume labels'], verbose>1);
        args.balancingCriterion = labels;
    else
        assert(length(args.balancingCriterion) == length(labels), ...
            'balancingCriterion must have same length as labels');
    end
    
    % Check pool
    if isempty(args.pool)
        args.pool = 1:length(labels);
    else
        args.pool = args.pool(:)';
        if length(unique(args.pool)) ~= length(args.pool)
            out(['NOTE: duplicate indices in args.pool will be ignored']);
            [args.pool, tmpI] = unique(args.pool);
            labels = labels(tmpI);
            args.balancingCriterion = args.balancingCriterion(tmpI);
        end
        out(['Pool:      ', mat2str(args.pool)], verbose>0);
        out(['Labels:    ', mat2str(labels)], verbose>0);
        out(['Criterion: ', mat2str(args.balancingCriterion)], verbose>0);
    end
    nExamples = length(labels);
    
    % Check nClasses
    nClasses = args.nClasses;
    if isempty(nClasses)
        nClasses = max(labels);
        out(['NOTE: nClasses not provided, inferring from labels: ', num2str(nClasses)]);
    end
    
    % Check other parameters
    if args.setSize < 1
        error('invalid setSize value');
    end
    if (args.setSize > fix(nExamples/2))
        error(['Given ', num2str(nExamples), ' samples, ', ...
            'setSize must not be greater than ', num2str(fix(nExamples/2))]);
    end
    if args.overallRepetitions <= 0
        error('invalid overallRepetitions value');
    end
    if args.minExamplesPerClass <= 0
        error('invalid minExamplesPerClass value');
    end
    if args.bSinglePeekingFoldOnly
        if (args.setSize ~= 1)
            error(['Warning: About to create an entire-dataset selector only, ', ...
                'but setSize=', num2str(args.setSize), ' (rather than 1), so there ', ...
                'will be some unnecessary pruning of trials. You should set ', ...
                'setSize to 1.']);
        end
        if (args.foldwiseExclusion(1)~=0 || args.foldwiseExclusion(2)~=0)
            error(['Warning: foldwiseExclusion has no effect when only creating ', ...
                'a single peeking fold. You should set it to [0 0].']);
        end
        if (args.randomCrossValidation)
            error(['Warning: randomCrossValidation has no effect when only creating ', ...
                'a single peeking fold. You should set it to false.']);
        end
    end
    if ~containsOnly(args.overallBalancingType, [0 1 2])
        error('illegal overallBalancingType');
    end
    if ~containsOnly(args.foldwiseBalancingType, [0 1 2])
        error('illegal outerFoldwiseBalancingType');
    end
    if (args.keepSubjectsSeparate)
        out(['Note: Since in across-subjects clf mode, setSize=', num2str(args.setSize), ' will be ignored.']);
        if isempty(subj.sids)
            error('no sids vector specified in subj.sids');
        end
        if sum(args.outerFoldwiseExclusion) > 0
            out(['Note: Since in across-subjects clf mode, outer foldwise exclusion ', ...
                mat2str(args.outerFoldwiseExclusion), ' will be ignored']);
        end
    else
        if ~isempty(args.sids)
            out('WARNING: sids vector given though not in across-subjects clf mode');
        end
    end
    
    % Initialize result
    folds = struct;
    cancel = true;
    
    % If we have a blocks structure, process all blocks in sequence
    if ~isempty(args.blockLengths)
        if (sum(args.blockLengths) ~= nExamples)
            error('sum of block lengths does not match number of trials');
        end
    else
        args.blockLengths = [nExamples];
        args.blockFilter = [];
    end
    
    % Go through all blocks
    nBlocks = length(args.blockLengths);
    cBlock = 0;
    if isempty(args.blockFilter)
        cnBlocks = nBlocks;
    else
        cnBlocks = sum(args.blockFilter);
    end
    for iBlock = 1:nBlocks
        
        % Process this block?
        if ~isempty(args.blockFilter) && (args.blockFilter(iBlock) ~= 1)
            continue;
        end
        cBlock = cBlock + 1;
        if length(nBlocks)>1 || verbose>0
            out(' ');
            out(['BLOCK ', num2str(cBlock), '/', num2str(cnBlocks), ' (experimental block ', num2str(iBlock), ')']);
        end
        increaseIndent;
        
        % Initialize blockPool via block filter
        iTrialFrom = sum(args.blockLengths(1:(iBlock-1)))+1;
        iTrialTo = iTrialFrom + args.blockLengths(iBlock) - 1;
        blockPool = [iTrialFrom:iTrialTo];
        out(' ', verbose>1);
        out(['Raw blockPool:   ', mat2str(blockPool)], verbose>1);
        out(['Classes are:     ', mat2str(labels(blockPool))], verbose>1);
        
        % Apply filter
        if args.nClasses>0
            out(['Classification mode - ignoring 0 and NaN trials'], verbose>1);
            tmpKeepIndices = find(labels>0 & ~isnan(labels));
        else
            out(['Regression mode - ignoring NaN trials only'], verbose>1);
            tmpKeepIndices = find(~isnan(labels));
        end
        blockPool = intersect(blockPool, tmpKeepIndices);
        out(' ', verbose>1);
        out(['Ready blockPool: ', mat2str(blockPool)], verbose>1);
        out(['Classes are:     ', mat2str(labels(blockPool))], verbose>1);
        
        % Enough trials present?
        [types, freqs] = analyseCriterion(labels(blockPool));
        if (min(freqs) < args.minExamplesPerClass) ...
                || (size(freqs,2) < size(nanunique(labels),2))
            % Not enough, ignore fold
            out(' ', verbose>0);
            out(['Before beginning of overall repetitions, not at least ', num2str(args.minExamplesPerClass), ...
                ' trials left in each class; fold will be ignored.'], verbose>0);
            decreaseIndent;
            continue;
        end
        
        % Go through all overall repetitions
        for r = 1:args.overallRepetitions
            out(' ', verbose>0);
            out(['Overall repetition ', num2str(r), '/', num2str(args.overallRepetitions)], verbose>0);
            increaseIndent;
            
            % Get overall repetition pool
            if ~args.randomCrossValidation
                out('Creating overall repetition pool (overall balancing if requested, and multiplicity)', verbose>1);
                tmpSetSize = args.setSize;
            else
                out('Creating overall repetition pool (overall balancing if requested)', verbose>1);
                tmpSetSize = 1;
            end
            increaseIndent;
            overallRepetitionPool = getBalancedIndices(blockPool, ...
                args.balancingCriterion, args.overallBalancingType, tmpSetSize, verbose);
            decreaseIndent;
            
            % Add CV folds to folds group
            out('Adding CV folds...', verbose>1);
            increaseIndent;
            folds = addCvFolds(folds, overallRepetitionPool, labels, args.sids, args);
            decreaseIndent;
            
            decreaseIndent;
        end % repetition
        
        decreaseIndent;
    end % block
    
    % If no folds left, set to empty
    if ~isfield(folds, 'train')
        folds = [];
    end
    
    % Make sure we have at least one fold left
    if length(folds)==0
        % No data left, must ignore this subject
        out(' ');
        out('WARNING: NO DATA LEFT TO ANALYSE!');
        cancel = true;
    else
        % Return successfully
        out(' ',verbose>0);
        out(['Created ', num2str(length(folds)), ' folds']);
        cancel = false;
    end
end

% -------------------------------------------------------------------------
% Adds new CV folds to the given 'folds' struct.
% - folds: the current struct array
% - idx: a list of trial numbers that represents the pool for cross-validation
% - classes: vector of class labels
% - sids: vector of subject IDs (if in across-subjects clf mode)
function folds = addCvFolds(folds, idx, classes, sids, args)
    verbose = args.verbose;
    
    % Create single peeking fold only?
    if args.bSinglePeekingFoldOnly
        
        % Create a simple fold of training indices (and same test indices)
        newTrain = getBalancedIndices(idx, args.balancingCriterion, ...
                    args.foldwiseBalancingType, 1, verbose);
        newTest = newTrain;            
        
        % Add fold
        if isfield(folds, 'train')
            nFoldsBefore = length(folds);
        else
            nFoldsBefore = 0;
        end
        folds = addFold(folds, newTrain, newTest, classes, args);
        if isfield(folds, 'train')
            nFoldsAfter = length(folds);
        else
            nFoldsAfter = 0;
        end
        if nFoldsAfter > nFoldsBefore
            out(['Created simple peeking fold of ', num2str(length(folds(end).train)), ...
                ' training and test indices.'], verbose>1);
        else
            % Nothing created
        end
        
    % Create normal cross-validation folds?
    else
        
        % NORMAL MODE (single-subject data)
        if ~args.keepSubjectsSeparate
            
            % Create folds
            if length(unique(idx)) ~= length(idx)
                error('invariant violated: idx contains duplicates');
            end
            if ~args.randomCrossValidation
                % normal folding
                if fix(length(idx) / args.setSize) ~= length(idx)/args.setSize
                    error('invariant violated: idx not a multiple of setSize');
                end
                out('Normal cross-validation (as opposed to random-draw)', verbose>1);
                nFolds = length(idx) / args.setSize;
            else
                % single-fold random cross-validation only
                out('Random-draw cross-validation (as opposed to normal)', verbose>1);
                nFolds = 1;
            end
            
            % Go through all folds
            out(['Now attempting to create ', num2str(nFolds), ' new folds, '], verbose>1);
            for f = 1:nFolds
                out(['Fold ', num2str(f), '/', num2str(nFolds)], verbose>1);
                increaseIndent;
                
                % Create test set
                out(['Creating test set...'], verbose>1);
                if ~args.randomCrossValidation
                    % normal
                    newTest = idx((f-1)*args.setSize+1:f*args.setSize);
                else
                    % random
                    idx = shuffle(idx);
                    newTest = idx((f-1)*args.setSize+1:f*args.setSize);
                    idx = sort(idx);
                    newTest = sort(newTest);
                end
                [types, freqs] = analyseCriterion(classes(newTest));
                increaseIndent;
                out(['Test set: criterion types are: ', mat2str(types)], verbose>1);
                out(['Test set: criterion freqs are: ', mat2str(freqs)], verbose>1);
                decreaseIndent;
                
                % Finish test set (temporary experimental feature)
                if isfield(args, 'outerTestFilter')
                    if ~isempty(args.outerTestFilter)
%                         tmpStays = newTest(diff(classes(newTest))==0);
%                         if newTest(1)~=1
%                             tmpStays = [newTest(diff(classes([newTest(1)-1,newTest(1)]))==0), ...
%                                 tmpStays];
%                         end
                        isSwitch = logical([1, diff(classes)~=0]);
                        isSwitch = isSwitch(newTest);
                        if strcmpi(args.outerTestFilter, 'switch')
                            % Keep switch, i.e., get rid of stay
                            if sum(~isSwitch)>0
                                out(['Getting rid of ', num2str(sum(~isSwitch)), ' stay trials'], verbose>1);
                                newTest(~isSwitch) = [];
                            end
                        elseif strcmpi(args.outerTestFilter, 'stay')
                            % Keep stay, i.e., get rid of switch
                            if sum(isSwitch)>0
                                out(['Getting rid of ', num2str(sum(isSwitch)), ' switch trials'], verbose>1);
                                newTest(isSwitch) = [];
                            end
                        else
                            error('illegal outerTestFilter argument');
                        end
                    end
                end
                
                % Create training set
                out(['Creating training pool...'], verbose>1);
                
                % Exclude test set and trials around the training set
                if any(args.foldwiseExclusion~=[0 0]) && args.randomCrossValidation
                    tmpExclusion = [0 0];
                    out(['WARNING: ignoring foldwiseExclusion because in random cross-validation mode'], verbose>1);
                end
                trainingPool = excludeSurroundingTrials(idx, newTest, ...
                    args.foldwiseExclusion);
                
                % Balance training set
                out(['Balancing training set...'], verbose>1);
                increaseIndent;
                newTrain = getBalancedIndices(trainingPool, args.balancingCriterion, ...
                    args.foldwiseBalancingType, 1, verbose);
                decreaseIndent;
                    
                % Add this as a new fold
                folds = addFold(folds, newTrain, newTest, classes, args);
                
                decreaseIndent;
            end % fold
        
        % ACROSS-SUBJECTS CLF MODE (keep subjects separate)
        elseif args.keepSubjectsSeparate
            out('Across-subjects mode (as opposed to normal)', verbose>1);
            
            if args.randomCrossValidation
                error('not implemented yet');
            end
            
            % One outer fold per subject
            uniqueSids = unique(sids);
            out(['Unique subject IDs: ', mat2str(uniqueSids)], verbose>1);
            nFolds = length(uniqueSids);
            if nFolds < 2
                error('need data from at least 2 different subjects');
            end
            
            % Go through all outer folds
            out(['Now attempting to create ', num2str(nFolds), ' new outer folds, each containing ', ...
                num2str(args.outerFoldwiseBalancingRepetitions), ' fold-wise sampling repetitions', ...
                ', that is, ', num2str(nFolds * args.outerFoldwiseBalancingRepetitions), ...
                ' physical folds in total'], verbose>1);
            for f = 1:nFolds
                % Create test set
                newTest = idx(sids(idx)==uniqueSids(f));
                
                % Prepare training set
                trainingPool = excludeSurroundingTrials(idx, newTest, [0 0]);
                % (exclude test set, but don't exclude any surrounding
                % trials)
                
                % Go through all fold-wise repetitions
                for r = 1:args.outerFoldwiseBalancingRepetitions
                    % Finish training set (balancing)
                    thisTrain = getBalancedIndices(trainingPool, args.balancingCriteria, ...
                        args.outerFoldwiseBalancingType, 1); % (args.setSize=1)
                    
                    % Add this as a new fold
                    folds = addFold(folds, thisTrain, newTest, classes, args);
                end % fold-wise repetition
            end % fold
        end
        
    end
end

% -------------------------------------------------------------------------
% Adds a new fold to the 'folds' struct array.
function folds = addFold(folds, newTrain, newTest, classes, args)
    verbose = args.verbose;
    
    % Enough trials present in training set?
    [types, freqs] = analyseCriterion(classes(newTrain));
    if (min(freqs) < args.minExamplesPerClass) ...
            || (size(freqs,2) < size(nanunique(classes),2))
        % Not enough, ignore fold
        out(['After balancing, not at least ', num2str(args.minExamplesPerClass), ...
            ' trials left in each class; fold will be ignored.'], verbose>0);
        
    % At least one test trial present? (unless singlePeekingFoldOnly)
    elseif (args.bSinglePeekingFoldOnly == false) && isempty(newTest)
        out(['Not at least one test trial left; fold will be ignored.'], verbose>0);
        
    else
        % Okay, add to 'folds'
        if ~isfield(folds, 'train')
            folds(1).train = [];
        else
            folds(end+1).train = [];
        end
        folds(end).train = args.pool(newTrain);
        folds(end).test = args.pool(newTest);
        %out(['        Fold added']);
    end
end
