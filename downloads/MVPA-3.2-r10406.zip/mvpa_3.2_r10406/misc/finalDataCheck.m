% Performs a final check of examples and labels before the analysis. There
% are three possible outcomes:
% - everything ok --> returns with cancel=false
% - NaN values in the data --> returns with cancel=true
% - serious error --> throws an error

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: finalDataCheck.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = finalDataCheck(subj, settings)
    
    % Initialize return value
    cancel = false;
    
    % Get data
    mat_train = [];
    mat_test = [];
    if isfield(subj, 'mat_train') && isfield(subj, 'mat_test')
        mat_train = subj.mat_train;
        mat_test = subj.mat_test;
    else
        try
            mat_train = get_mat(subj, 'pattern', 'data_train');
            mat_test = get_mat(subj, 'pattern', 'data_test');
        end
    end
    if isempty(mat_train) || isempty(mat_test)
        out(' ');
        out(['WARNING: in order to use finalDataCheck, your data must either contain ', ...
            'mat_train and mat_test fields or it must be a Princeton SUBJ struct']);
        out(['finalDataCheck aborted']);
        return;
    end
    try; labels_train = subj.labels_train; catch; labels_train = subj.labels; end
    try; labels_test = subj.labels_test; catch; labels_test = labels_train; end
    
    % At least one trial?
    if isempty(mat_train) || isempty(mat_test)
        out(['Empty training or test data']);
        cancel = true;
    end
    
    % Check nSamples
    if isfield(subj, 'nExamples')
        assert(subj.nExamples==size(mat_train,2), 'nExamples does not equal size of mat_train');
        assert(subj.nExamples==size(mat_test,2), 'nExamples does not equal size of mat_test');
        assert(subj.nExamples==size(labels_train,2), 'number of examples and labels must match');
    end
    if isfield(subj, 'nExamples_train')
        assert(subj.nExamples_train==size(mat_train,2), 'nExamples_train does not equal size of mat_train');
    end
    if isfield(subj, 'nExamples_test')
        assert(subj.nExamples_test==size(mat_test,2), 'nExamples_test does not equal size of mat_test');
    end        
    
    % Check whether mat_train and mat_test agree
    assert(size(mat_train,1)==size(mat_test,1), 'mat_train and mat_test have different size');
    if size(mat_train,2)~=size(mat_test,2)
        out(['Final data check warning: mat_train and mat_size have different numbers of examples']);
    end
    
    % Check labels
    if subj.nClasses~=0
        if ~containsOnly(labels_train, [NaN, 1:99]) || ~containsOnly(labels_test, [NaN, 1:99]);
            error('illegal labels were found');
        end
    end
    
    % Check for strange features
    cancel = cancel | checkFeatureSanity(subj, mat_train, labels_train~=0, 'mat_train');
    cancel = cancel | checkFeatureSanity(subj, mat_test, labels_test~=0, 'mat_test');
    
    % Print summary if ok
    if ~cancel
        out(' ');
        out(['Final data:']);
        out(['    mat_train: ', mat2str(size(mat_train))]);
        out(['    mat_test:  ', mat2str(size(mat_test))]);
    end
    
    % Print errors if any
    if cancel
        out(' ');
        out('Final check NOT passed');
        out(['    ', num2str(subj.nExamples), ' samples']);
        out(['    ', num2str(subj.nClasses), ' classes']);
    end
        
end
