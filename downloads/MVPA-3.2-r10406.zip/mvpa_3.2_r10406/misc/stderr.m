function se = stderr(x, dim)

    %disp('WARNING: deprecated');
    
    if ~exist('dim', 'var')
        if size(x,1) == 1
            dim = 2;
        elseif size(x,2) == 1
            dim = 1;
        else
            error('please specify dimension manually');
        end
    end
    se = std(x,0,dim) ./ sqrt(size(x,dim));
    
    
return;