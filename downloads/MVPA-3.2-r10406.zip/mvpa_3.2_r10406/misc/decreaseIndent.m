function decreaseIndent
    global OUTPUT_INDENT;
    OUTPUT_INDENT = max(OUTPUT_INDENT - 1,0);
end
