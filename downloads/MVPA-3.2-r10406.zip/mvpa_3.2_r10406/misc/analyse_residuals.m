% Computes various statistics based on predicted and true continuous labels.
%
% Usage:
%     [r2, rmse, s] = analyse_residuals(targs, preds)

% Kay H. Brodersen, ETHZ/UZH
% $Id: analyse_residuals.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [r2, rmse, rho_s, p_s] = analyse_residuals(targs, preds)
    
    % R squared
    r2 = sum((preds - mean(targs)).^2) / sum((targs - mean(targs)).^2);
    
    % Root mean squared error
    rmse = sqrt(nanmean((targs-preds).^2));
    
    % Spearman rank correlation
    [rho_s, p_s] = corr(targs(:), preds(:), 'type', 'Spearman');
    
end
