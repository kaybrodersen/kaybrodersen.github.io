% Computes the root mean squared error between two vectors.
%
% Usage:
%     e = rmse(x, y)

% Kay H. Brodersen, ETHZ/UZH
% $Id: rmse.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function e = rmse(x, y)
    
    
    e = sqrt(nanmean((x-y).^2));
end
