% ONLYCONTAINS   Checks whether a vector contains only allowed values.
%
% Usage:
%     bResult = onlyContains(vector, allowedValues);
%
% Returns true or false.
%
% Example:
%     onlyContains([1 3 2 3 3 1 4], [1 2 3]) - returns false
%

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function bResult = onlyContains(vector, allowedValues)

    % Check input
    if length(vector) ~= length(vector(:))
        error('input must be a vector, not a matrix');
    end
    
    % Transform inputs
    vector = vector(:);
    unique_vector = unique(vector);
    allowedValues = allowedValues(:);
    unique_allowedValues = unique(allowedValues);
    
    % Carry out function
    bResult = true;
    for i=1:length(unique_vector)
        if ~(isnan(unique_vector(i)) && (sum(isnan(allowedValues)) > 0))
            bResult = bResult & (sum(unique_vector(i)==allowedValues) == 1);
        end
    end

return;