% Computes the explicit feature map for a polynomial kernel.
%
% Usage:
%     phix = feature_map_polynomial(x, d, b, a)
%     [phix, k] = feature_map_polynomial(...)
%     [phix, k, features] = feature_map_polynomial(...)
%
% Given a kernel function
%     K(x,y) = (b * x'*y + a)^d
% and a matrix x with dimensions N x F1, this function returns phi(x) with
% dimensions N x F2. The i-th element of the feature vector is of the form
%     k(i)p_i(x),
% where k(i) is a constant and p_i(x) is some polynomial expression in the
% elements of x (e.g., x_1*x_2*x_3^2).
% 
% Return values:
%     phix - the feature map of x (dimensions N x F2)
%     k - the constants associated with each feature (dimensions 1 x F2)
%     features - a cell array of strings (dimensions 1 x F2) with feature
%         descriptions such as 'x1^3 + x2' (i.e., in terms of x without
%         any further constants)

% Kay H. Brodersen, ETHZ/UZH
% $Id: feature_map_polynomial.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [phix, k, features] = feature_map_polynomial(x, value_d, value_b, value_a)

    % Check input
    out(['Computing polynomial feature map...']);
    increaseIndent;
    if nargin~=4
        error('not enough input arguments');
    end
    N = size(x,1);
    F1 = size(x,2);
    
    % Make list of x and y variables (will be needed in several places)
    xs = ''; ys = ''; sop = '';
    for i=1:F1
        xs = [xs, 'x', num2str(i), ' '];
        ys = [ys, 'y', num2str(i), ' '];
        sop = [sop, 'x', num2str(i), '*y', num2str(i) ' '];
    end
    xs = strtrim(xs); ys = strtrim(ys);
    sop = strtrim(sop); sop = strrep(sop, ' ', '+');
    
    % Declare symbolic variables
    syms b a;
    eval(['syms ', xs, ' ', ys]);
    
    % Define kernel
    out(['Expanding kernel...']);
    eval(['K = (b * (', sop, ') + a) ^ value_d;']);
    K = expand(K);
    
    % Get a column vector of all terms
    out(['Vectorizing kernel...']);
    eval(['H = [', strrep(char(K), '+', ';'), '];']);
    assert(size(H,1) == nchoosek(F1+value_d,value_d));
    out(['Feature space dimensions: ', num2str(size(H,1)), ...
        ' (including ', num2str(size(H,1)-1), ' non-constant features)']);
    
    % Throw away the constant term
    out(['Throwing away the constant feature']);
    double(subs(H(1), a, 1));
    H = H(2:end);
    F2 = size(H,1);
    
    % Make column vector in terms of x, a, b only
    out(['Computing vector in terms of x, a, b...']);
    G = [];
    eval(['G = subs(H, [', ys, '], ', mat2str(ones(1,F1)), ');']);
    
    % Make column vector in terms of x and constants only
    out(['Computing vector in terms of x and constants...']);
    I = [];
    eval(['I = subs(G, [b a], ', mat2str([value_b value_a]), ');']);
    
    % Make row vector of all constants (output value 'k')
    if nargout>=2
        out(['Computing vector in terms of constants...']);
        eval(['k = double(subs(I, [', xs, '], ', mat2str(ones(1,F1)), '));']);
        k = sqrt(k)';
    end
    
    % Make cell array of all feature descriptions (output value 'features')
    if nargout>=3
        out(['Making feature descriptions...']);
        features = cell(1,F2);
        for i = 1:F2
            features{i} = char(I(i));
        end
        % Remove leading factor
        features = regexprep(features, '(?\d*\*', '', 'once');
        % Remove trailing factor
        features = regexprep(features, ')?\*\d*$', '', 'once');
        features = regexprep(features, ')?/\d*$', '', 'once');
        % Turn x1 into x_1
        features = regexprep(features, 'x', 'x_');
    end
    
    % Compute phi(x) for all row vectors in x
    phix = NaN(N, F2);
    out(['Evaluating polynomial feature map...']);
    parfor i = 1:N
        out([num2str(i), '/', num2str(N)]);
        try
            phix(i,:) = getPhixi(I, xs, x, i);
        catch
            out(['ERROR in i==', num2str(i)]);
        end
    end
    assert(all(all(~isnan(phix))));
    
    decreaseIndent;
end

% -------------------------------------------------------------------------
function phixi = getPhixi(G, xs, x, i)
    syms b a;
    eval(['syms ', xs]);
    eval(['phixi = subs(G, [', xs, '], ', mat2str(x(i,:)), ');']);
end
