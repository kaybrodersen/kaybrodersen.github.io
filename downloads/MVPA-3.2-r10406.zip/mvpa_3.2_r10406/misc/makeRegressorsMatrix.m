% Turns a vector of class labels into matrix form, so it can be used as a
% 'regressors' object in MVPA. Labels of active trials have to be positive
% integers. Labels that are 0 (trials to be ignored) will translated into a
% zero column.
%
% Usage:
%     regressors = makeRegressorsMatrix(classes);
%     regressors = makeRegressorsMatrix(classes, quiet);
%
% Example: Consider five examples of which the last example is to be
% ignored. Their class labels are:
%     classes
%     = [1 1 2 2 0];
% Then the resulting regressors matrix will be:
%     makeRegressorsMatrix(classes)
%     = [1 1 0 0 0; 0 0 1 1 0]

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: makeRegressorsMatrix.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function regressors = makeRegressorsMatrix(classes, quiet)
    
    % Check input
    if any(isnan(classes))
        error('classes must only contain positive integers or 0s');
    end
    if (size(classes,1) ~= 1) && (size(classes,2) ~= 1)
        error('''classes'' must be a row vector');
    end
    classes = classes(:)'; % enforce row vector
    if ~exist('quiet', 'var')
        quiet = false;
    end
    
    % How many real classes?
    tmpRegs = zerounique(classes);
    tmpRegs(isnan(tmpRegs)) = [];
    nRegs = length(tmpRegs);
    
    % Initialize regressors matrix
    regressors = zeros(nRegs, length(classes));
    
    % Convert
    for r = 1:nRegs
        regressors(r,:) = (classes == r);
    end
    
    % Make numeric (required by MVPA)
    regressors = fix(regressors);
    
    % Is there a class that was completely irradicated by the filter?
    if sum(sum(regressors,2)==0)>0
        error('WARNING: the trials of at least one class were completely removed by the filter. Are you sure?');
    end
    
    % Display info about result (unles in 'quite' mode)
    if ~quiet
        out(' ');
        out(['Regressors matrix is: ', num2str(size(regressors,1)), ' CLASSES x ', ...
            num2str(size(regressors,2)), ' TRIALS (', ...
            num2str(sum(sum(regressors,1)~=0)), ' ACTIVE TRIALS)']);
    end
    
return;
