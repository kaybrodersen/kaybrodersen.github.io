% Creates a list of balanced indices.
%
% Returns a vector of trial indices such that (i) criteria are balanced
% according to the given balancing mode, and (ii) the number of indices is
% a multiple of setSize.
% 
% N.B. In the current implementation, condition (ii) is strictly enforced,
% whereas a slight class imbalance may remain.
% 
% N.B. Currently, up to two balancing criteria are supported.
% 
% Usage:
%     idx = getBalancedIndices(pool, criteria, balancingType, setSize, verbose)
%
% Arguments:
%     pool: given set of indices, e.g., [1 2 3 4  9 10 11 12]
%     criteria: matrix of criteria, e.g., [0 0 1 1  0 1 1 1; 1 1 1 1 0 0 0 0]
%     balancingType (default = 0): determines the strategy for balancing
%         0: no balancing;  1: by deletion;  2: by duplication
%     setSize (optional, default=1): resulting indices will be a multiple
%         of setSize
%     verbose (optional, default=2): level of output detail (0, 1, 2)
%     tolerableDiscrepancy (optional, default=0): what discrepancy will be
%         tolerated when balancing 2 criteria
%
% IMPORTANT: the indices in 'pool' will reference elements in 'criteria'.
% Thus, DO NOT call the function in this way: getBalancedIndices(myIndices,
% classes(myIndices)). Instead, call it using:
% getBalancedIndices(myIndices, classes), where
% length(classes)>=max(myIndices).

% Kay H. Brodersen, Kate Lomakina, ETHZ/UZH
% $Id: getBalancedIndices.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function idx = getBalancedIndices(pool, criteria, balancingType, setSize, ...
    verbose, tolerableDiscrepancy)
    
    % Check input
    if isempty(criteria)
        error('not implemented; try giving criteria but setting balancingType=0');
    end
    nSamples = length(pool);
    if ~isempty(criteria)
        if size(criteria,1)>2
            error('more than 2 criteria not implemented in this version');
        end
        if size(criteria,2) < max(pool)
            error('indices in pool exceed length of criteria');
        end
    else
        criteria = [];
    end
    try; setSize; catch; setSize = 1; end
    assert(setSize >= 1, 'invalid setSize');
    try; verbose; catch; verbose = 2; end
    try; tolerableDiscrepancy; catch; tolerableDiscrepancy = 0; end
    
    % Initialize return value
    idx = pool;
    clear pool;
    
    % Remove all trials with a NaN criterion
    n = sum(any(isnan(criteria(:,idx))));
    if n>0
        out(['Ignoring ', num2str(n), ' trial(s) with at least one NaN criterion: ', ...
            num2str(idx(any(isnan(criteria(idx)),1)))]);
        idx(any(isnan(criteria(:,idx)),1)) = [];
    end
    
    % ---------------------------------------------------------------------
    % Step 1: balance indices
    out('Index processing, step 1: balancing indices', verbose>1);
    increaseIndent;
    
    % ONE CRITERION?
    if size(criteria,1)==1
        criterion = criteria;
        
        % Get criterion frequencies
        [types, freqs] = analyseCriterion(criteria(idx));
        out(['Criterion types are: ', mat2str(types)], verbose>1);
        out(['Criterion freqs are: ', mat2str(freqs)], verbose>1);
        
        % Balancing at all necessary?
        if sum(freqs == max(freqs)) == length(freqs)
            out('No imbalance, skipping step 1.', verbose>1);
            
        else
            % Prepare new result
            newIdx = [];
            
            % No balancing?
            if (balancingType == 0)
                % No modifications
                out(['No balancing requested, keeping all ', num2str(length(idx)), ' indices'], verbose>1);
                newIdx = idx;
            
            % Balancing by deletion?
            elseif (balancingType == 1)
                % Idea: within each criterion type, delete surplus trials so that
                % all types have the same frequency 'leastFrequentCount'.
                out('Starting balancing by deletion', verbose>1);
                increaseIndent;
                leastFrequentCount = min(freqs);
                
                % Go through all types in criterion 1/1
                for t = types
                    type_idx = idx(criterion(idx) == t);
                    surplus = sum(criterion(idx) == t) - leastFrequentCount;
                    type_idx = shuffle(type_idx);
                    type_idx(1:surplus) = [];
                    newIdx = [newIdx, type_idx];
                    if (surplus > 0)
                        out(['Deleted ', num2str(surplus), ...
                            ' random trials of type ', num2str(t)], verbose>1);
                    end
                end
                decreaseIndent;
                
            % Balancing by duplication?
            elseif (balancingType == 2)
                % Idea: within each criterion type, duplicate trials so that all
                % types have the same frequency 'mostFrequentCount'.
                out(['Starting balancing by duplication'], verbose>1);
                increaseIndent;
                mostFrequentCount = max(freqs);
                newIdx = idx;
                
                % Go through all types in criterion 1/1
                for t = types
                    type_idx = newIdx(criterion(newIdx) == t);
                    originalShortage = mostFrequentCount - sum(criterion(newIdx) == t);
                    shortage = originalShortage;
                    while (shortage > 0)
                        tmpIdx = [];
                        type_idx = shuffle(type_idx);
                        tmpIdx = [tmpIdx, type_idx(1:min(shortage,length(type_idx)))];
                        newIdx = [newIdx, tmpIdx];
                        shortage = mostFrequentCount - sum(criterion(newIdx) == t);
                    end
                    if (originalShortage > 0)
                        out(['Duplicated ', ...
                            num2str(mostFrequentCount - sum(criterion(idx) == t)), ...
                            ' random trials of type ', num2str(t)], verbose>1);
                    end
                end
                decreaseIndent;
                
            else
                error('invalid balancingType');
            end
            
            % Make intermediary result
            idx = sort(newIdx);
        end
        
    % TWO CRITERIA?
    elseif size(criteria,1)==2
        % In this current implementation, the first criterion will be
        % assumed to equal the class labels. Rather than making all fields
        % of the combination-matrix equal, it will only enforce:
        % [ a b ]
        % [ a b ]
        
        % Show criteria
        out(['Criteria of these trials are:']);
        out(['   ', mat2str(criteria(1,idx))]);
        out(['   ', mat2str(criteria(2,idx))]);
        
        % Get criterion frequencies
        [types1, freqs1] = analyseCriterion(criteria(1,idx));
        out(['Criterion 1 types are: ', mat2str(types1)], verbose>1);
        out(['Criterion 1 freqs are: ', mat2str(freqs1)], verbose>1);
        [types2, freqs2] = analyseCriterion(criteria(2,idx));
        out(['Criterion 2 types are: ', mat2str(types2)], verbose>1);
        out(['Criterion 2 freqs are: ', mat2str(freqs2)], verbose>1);
        
        assert(length(types1)<=2);
        assert(length(types2)<=2);
        
        % Get combination-matrix
        m = getCombinationMatrix(criteria(:,idx), verbose);
        
        if (balancingType == 0)
            % No modifications
            out(['No balancing requested, keeping all ', num2str(length(idx)), ' indices'], verbose>1);
            newIdx = idx;
            
        elseif balancingType==1
            error('not implemented yet');
            
        elseif balancingType==2
                % Idea: within each matrix field, duplicate trials so that
                % all fields have the same frequency 'mostFrequentCount'.
                out(['Starting balancing by duplication'], verbose>1);
                increaseIndent;
                newIdx = idx;
                
                % Go through both columns and enforce their rows to have
                % the same number of trials
                for t2=1:2
                    mostFrequentCount = max(m(:,t2));
                    if mostFrequentCount > 0
                        for t1=1:2
                            type_idx = newIdx(criteria(1,newIdx)==types1(t1) & criteria(2,newIdx)==types2(t2));
                            originalShortage = mostFrequentCount - m(t1,t2);
                            shortage = originalShortage;
                            if isempty(type_idx)
                                if shortage > tolerableDiscrepancy
                                    out(['The criterion combination ', num2str(types1(t1)), '/', num2str(types2(t2)), ...
                                        ' is not present at all.']);
                                    out(['The resulting shortage of ', num2str(shortage), ...
                                        ' is intolerable (threshold ', num2str(tolerableDiscrepancy), ')']);
                                    idx = [];
                                    decreaseIndent;
                                    decreaseIndent;
                                    return;
                                else
                                    out(['The criterion combination ', num2str(types1(t1)), '/', num2str(types2(t2)), ...
                                        ' is not present at all,']);
                                    out(['but the resulting shortage of ', num2str(shortage), ...
                                        ' will be tolerated (threshold ', num2str(tolerableDiscrepancy), ')']);
                                end
                            else
                                while (shortage>0)
                                    tmpIdx = [];
                                    type_idx = shuffle(type_idx);
                                    tmpIdx = [tmpIdx, type_idx(1:min(shortage,length(type_idx)))];
                                    newIdx = [newIdx, tmpIdx];
                                    shortage = mostFrequentCount - sum(criteria(1,newIdx)==types1(t1) & criteria(2,newIdx)==types2(t2));
                                end
                                if (originalShortage > 0)
                                    out(['Duplicated ', num2str(originalShortage), ...
                                        ' random trials of type ', num2str(types1(t1)), '/', num2str(types2(t2))], verbose>1);
                                end
                            end
                        end
                    end
                end
                decreaseIndent;
                
        else
            error('invalid balancingType');
        end
        
        % Make intermediary result
        idx = sort(newIdx);
        
        % Get combination-matrix
        m = getCombinationMatrix(criteria(:,idx), verbose);
        
    end
    
    out(['Left with ', num2str(length(idx)), ' indices: ', mat2str(idx)], verbose>1);
    decreaseIndent;
    
    
    % ---------------------------------------------------------------------
    % Step 2: make number of indices a multiple of 'setSize'
    out(['Index processing, step 2: making number of indices a multiple of setSize=', num2str(setSize)], verbose>1);
    increaseIndent;
    
    % ONE CRITERION?
    if size(criteria,1)==1
        criterion = criteria;
        
        % Get criterion frequencies
        [types, freqs] = analyseCriterion(criterion(idx));
        out(['Criterion types are: ', mat2str(types)], verbose>1);
        out(['Criterion freqs are: ', mat2str(freqs)], verbose>1);
        
        % Come up with a random order of unique classes
        rOrder = shuffle(nanunique(criterion));
        
        % Multiple-assurance is always by deletion, never by duplication
        
        % How much overall surplus?
        surplus = mod(length(idx), setSize);
        if (surplus == 0)
            out('No overall surplus, therefore no modifications necessary', verbose>1);
        else
            % Delete trials, one after another, of a particular class, in
            % this order, until balanced
            increaseIndent;
            for d=0:surplus-1
                % From which type to delete?
                t = rOrder(mod(d,length(rOrder))+1);
                % Find a random index of this class to delete
                class_idx = idx(criterion(idx)==t);
                class_idx = shuffle(class_idx);
                index_to_delete = class_idx(1);
                % Delete this index
                idx(idx==index_to_delete) = [];
            end
            out(['Deleted ', num2str(surplus), ' random trials', ...
                ', left with ', num2str(length(idx)), ...
                ' total indices (', num2str(length(unique(idx))), ' unique)'], verbose>1);
            decreaseIndent;
        end
        out(['Left with ', num2str(length(idx)), ' indices'], verbose>1);
        decreaseIndent;
        
        % Does a small class imbalance remain?
        [types, freqs] = analyseCriterion(criterion(idx));
        out(['--> Type frequencies in criterion 1/1 are now: ', mat2str(freqs)], verbose>1);
        if sum(diff(freqs)~=0)>0
            out(['(The remaining imbalance is a result of no balancing being requested or of ensuring multiplicity)'], verbose>1);
        end
    
    % TWO CRITERIA?
    elseif size(criteria,1)==2
        
        % Get criterion frequencies
        [types1, freqs1] = analyseCriterion(criteria(1,idx));
        out(['Criterion 1 types are: ', mat2str(types1)], verbose>1);
        out(['Criterion 1 freqs are: ', mat2str(freqs1)], verbose>1);
        [types2, freqs2] = analyseCriterion(criteria(2,idx));
        out(['Criterion 2 types are: ', mat2str(types2)], verbose>1);
        out(['Criterion 2 freqs are: ', mat2str(freqs2)], verbose>1);
        
        assert(length(types1)<=2);
        assert(length(types2)<=2);
        
        m = getCombinationMatrix(criteria(:,idx), verbose);
        
        % Come up with a random order of unique classes
        rOrder1 = shuffle(nanunique(criteria(1,:)));
        rOrder2 = shuffle(nanunique(criteria(2,:)));
        
        % How much overall surplus?
        surplus = mod(length(idx), setSize);
        if (surplus == 0)
            out('No overall surplus, therefore no modifications necessary', verbose>1);
        else
            % Delete trials, one after another, of a particular class, in
            % this order, until balanced
            increaseIndent;
            for d=0:surplus-1
                % From which type to delete?
                t1 = rOrder1(mod(d,length(rOrder1))+1);
                t2 = rOrder2(mod(d,length(rOrder2))+1);
                
                % Find a random index of this class to delete
                class_idx = idx(criteria(1,idx)==types1(t1) & criteria(2,idx)==types2(t2));
                class_idx = shuffle(class_idx);
                index_to_delete = class_idx(1);
                % Delete this index
                idx(idx==index_to_delete) = [];
            end
            out(['Deleted ', num2str(surplus), ' random trials', ...
                ', left with ', num2str(length(idx)), ...
                ' total indices (', num2str(length(unique(idx))), ' unique)'], verbose>1);
            decreaseIndent;
        end
        out(['Left with ', num2str(length(idx)), ' indices'], verbose>1);
        decreaseIndent;
        
        out(' ', verbose>1);
        out('Combination matrix:', verbose>1);
        out(mat2str(m(1,:)), verbose>1);
        out(mat2str(m(2,:)), verbose>1);
        
        % Does a small class imbalance remain?
        [types1, freqs1] = analyseCriterion(criteria(1,idx));
        [types2, freqs2] = analyseCriterion(criteria(2,idx));
        out(['--> Type frequencies in criterion 1/2 are now: ', mat2str(freqs1)], verbose>1);
        out(['--> Type frequencies in criterion 2/2 are now: ', mat2str(freqs2)], verbose>1);
        if sum(diff(freqs1)~=0)>0 || sum(diff(freqs2)~=0)>0
            out(['(The remaining imbalance is a result of no balancing being requested or of ensuring multiplicity)'], verbose>1);
        end
        
    end
    
end
