% -------------------------------------------------------------------------
% criteria: may be empty
function printIdx(idx, orig_regressors, criteria)
    
    increaseIndent;
    
    if isempty(idx)
        out('(No trials were chosen.)');
    else
        strIdx =      'Indices:  ';
        strClasses =  'Classes:  ';
        strCriteria = 'Criteria: ';
    
        for i=idx
            strIdx = [strIdx, sprintf('% 4.0f', i)];
            strClasses = [strClasses, sprintf('% 4.0f', find(orig_regressors(:,i)==1))];
            if ~isempty(criteria)
                strCriteria = [strCriteria, sprintf('% 4.0f', criteria(i))];
            end
        end
        out(strIdx);
        out(strClasses);
        if ~isempty(criteria)
            out(strCriteria);
        end
    end
    
    decreaseIndent;
    
end