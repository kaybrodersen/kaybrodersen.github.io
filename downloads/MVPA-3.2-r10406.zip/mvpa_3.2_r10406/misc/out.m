% Like MATLAB's 'disp' function, but also writes all output to a logfile,
% and allows for indentation.
% 
% Usage:
%     out(str, enabled)
% 
% Arguments:
%     str: the string to print
%     enabled (optional, default=true): if false, no output will be
%         printed; for example, a function may routinely call:
%         out('Debug information...', bVerbose)

% Kay H. Brodersen, University of Oxford
% $Id: out.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function out(str, enabled)
    
    global LOGFILE;
    global OUTPUT_INDENT;
    global OUTPUT_DISABLED;
    
    if ~exist('OUTPUT_INDENT', 'var') || isempty(OUTPUT_INDENT)
        OUTPUT_INDENT = 0;
    end
    OUTPUT_INDENT = round(OUTPUT_INDENT);
    if OUTPUT_INDENT < 0 || OUTPUT_INDENT > 200
        OUTPUT_INDENT = 0;
    end
    basicIndent = '   ';
    
    if ~exist('OUTPUT_DISABLED', 'var') || isempty(OUTPUT_DISABLED)
        OUTPUT_DISABLED = false;
    end
    
    if (~exist('enabled','var') || enabled) && ~OUTPUT_DISABLED
        % Prepend indent
        str = [repmat(basicIndent, 1, OUTPUT_INDENT), str];
        
        % Print to display
        disp(str);
        
        % Write to logfile
        if isempty(LOGFILE) || (LOGFILE == -1)
            %error('no logfile id defined');
        else
            % Otherwise, write to logfile
            fprintf(LOGFILE, [str, '\n']);
        end
    end
    
end
