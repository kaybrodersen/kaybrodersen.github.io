% Displays a kernel matirx.
% 
% Usage:
%     showKernelMatrix(data, labels)
% 
% Parameters:
%     data: a FEATURES x EXAMPLES matrix
%     labels: a vector of labels (positive integers)

% Kay H. Brodersen, ETHZ/UZH
% $ Id: $
% -------------------------------------------------------------------------
function showKernelMatrix(data, labels)
    
    % Check input
    assert(ndims(data)==2);
    labels = labels(:)';
    assert(length(labels)==size(data,2), 'invalid dimension of labels vector');
    assert(containsOnly(labels, [1:99]), 'labels must be positive integers');
    
    % Get label indices and make sorted data matrix
    nClasses = max(labels);
    nExamples = size(data,2);
    X = [];
    lengths = [];
    for c = 1:nClasses
        I = find(labels==c);
        X = [X, data(:,I)];
        lengths = [lengths, length(I)];
    end
    
    % Make kernel matrix
    K = X'*X;
    
    % Display
    figure; hold on;
    imagesc(K);
    axis tight;
    axis square;
    axis ij;
    for c = 1:length(lengths)-1
        thisLength = sum(lengths(1:c));
        plot([0.5, nExamples+0.5], [thisLength+0.5, thisLength+0.5], 'k-', 'linewidth', 2);
        plot([thisLength+0.5, thisLength+0.5], [0.5, nExamples+0.5], 'k-', 'linewidth', 2);
    end
    set(gca,'box','on');
    colorbar
    
end
