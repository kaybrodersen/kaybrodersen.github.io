% Returns an application-specific temporary directory. Creates it if it
% doesn't exist.
%
% Usage:
%     dirTmp = getDirTmp;
%     dirTmp = getDirTmp(strSubdir);
%     dirTmp = getDirTmp(strSubdir, createIfNotExist);
%
% Parameters:
%     strSubdir (optional) - e.g. 'svm'
%     createIfNotExist (optional) = true (default) | false

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function dirTmp = getDirTmp(strSubdir, createIfNotExist)

    %dirTmp = '/usr/people/kbroders/scratch/tmp';
    dirTmp = tempdir;
    
    if exist('strSubdir','var')
        dirTmp = fullfile(dirTmp, strSubdir);
    end
    if ~exist('createIfNotExist','var') || createIfNotExist
        if ~exist(dirTmp, 'dir')
            mkdir(dirTmp);
        end
    end

return;
