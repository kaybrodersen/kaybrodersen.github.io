% Prints results of an overall prediction (classification or regression).
function printResults(results, nClasses)
    increaseIndent;
    
    % Collect results from all CV folds
    if isfield(results, 'folds')
        tmp = [results.folds(:)];
    else
        tmp = results;
    end
    targs = [tmp.targs];
    preds = [tmp.preds];
    n = length(targs);
    
    % No results to display?
    if n==0
        out(['WARNING: no results to show']);
        decreaseIndent;
        return;
    end
    
    % Default: classification
    if ~exist('nClasses', 'var')
        nClasses = 1;
    end
    
    % CLASSIFICATION
    if nClasses>0
        % Confusion matrices
        c = confusionmat(targs, preds, 'order', [1 2]);
        printCM(c);
        
        % Accuracy
        out(['Accuracy: ', num2str(acc_mode(c))]);
        
        % Balanced accuracy
        out(['Balanced accuracy: ', num2str(bacc_naive(c))]);
        
    % REGRESSION
    else
        
        % Analyse targs and preds
        targs = [results.folds.targs];
        preds = [results.folds.preds];
        
        out(['This scan & cycle:     R^2      RMSE         rho_s   p_s']);
        [R2, RMSE, RHO_S, P_S] = analyse_residuals(targs, preds);
        str2 = sprintf('%9.3f', R2);
        str3 = sprintf('%9.3f', RMSE);
        str4 = sprintf('%9.3f', RHO_S);
        str5 = sprintf('%9.4f', P_S);
        str6 = [' ', p2star(P_S)];
        out(['                   ', str2, str3, '    ', str4, str5, str6]);
        
        if 0
        figure;
        plot([results.folds.targs], [results.folds.preds],'.');
        v = axis;
        v = [min([v(1) v(3)]), max([v(2) v(4)]), min([v(1) v(3)]), max([v(2) v(4)])];
        axis(v);
        axis square;
        xlabel('targs');
        ylabel('preds');
        end
    end
     
    decreaseIndent;
end
