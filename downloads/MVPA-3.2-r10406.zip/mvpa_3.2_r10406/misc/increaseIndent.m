function increaseIndent
    global OUTPUT_INDENT;
    OUTPUT_INDENT = OUTPUT_INDENT + 1;
end
