% Works out the chance level and the significantly-above-chance level.
%
% Usage:
%     [pChance, pSig] = whatIsChance(nClasses, nTrials, alpha);
%
% Parameters:
%     nClasses: how many classes there are in the problem
%     nTrials: how many independent attempts of the same classifier
%     alpha: desired significance level

% Kay H. Brodersen, ETHZ/UZH
% $Id: whatIsChance.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [pChance, pSig] = whatIsChance(nClasses, nTrials, alpha)

    pChance = 1/nClasses;
    pSig = binoinv(1-alpha, nTrials, 0.5)/nTrials;

return;
