% Checks whether the data contain features that are all zero or NaN
% (ignoring trials that are filtered out anyway)

% Kay H. Brodersen, ETHZ/UZH
% $Id: checkFeatureSanity.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function cancel = checkFeatureSanity(subj, mat, filter, name)
    
    % Inititalize return value
    cancel = false;
    
    % Check filter
    if isempty(filter)
        filter = ones(1,size(mat,2));
    end
    
    % Reduce data to not-filtered-out ('active') trials
    mat = mat(:,filter);
    
    % Check 1: check for zeros
    lines = sum(mat,2)==0;
    n = sum(lines > 0);
    if n>0
        out(['WARNING: In ''', name, ''', ', num2str(n), ...
		    ' out of ', num2str(size(mat,1)), ...
			' features have a constant zero signal']);
    end
    
    % Check 2: check for NaNs (this will be cancel-sensitive)
    m = sum(sum(isnan(mat)));
    if m>0
        out(['ABORT: In ''', name, ''', ', ...
		    num2str(m), ' NaN values were found!']);
        cancel = true;
    end
end
