% Randomizes labels.
% 
% Usage:
%     labels = randomizeLabels(labels, randomizeLabels)
%
% Arguments:
%     labels: original labels vector
%     randomizeLabels: type of randomization
%         0 = no randomiation, labels will be returned untouched
%         1 = shuffle existing labels
%         2 = create completely balanced random labels

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% $Id: randomizeLabels.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function labels = randomizeLabels(labels, randomizeLabels)
    
    % Check input
    if ~containsOnly(randomizeLabels, [0 1 2])
        error('illegal randomizeLabels value');
    end
    
	% Which kind of randomizing?
	if isempty(randomizeLabels) || (randomizeLabels == 0)
		% No randomizing, exit silently
        return;
    else
        
        % Print warning
        out(' ');
        out('!!! WARNING: LABELS ARE BEING RANDOMIZED !!!');
        
        % Create completely balanced labels?
        if randomizeLabels == 2
            out('Creating completely balanced labels...');
            if length(zerounique(nanunique(labels))) > 2
                error('not implemented yet for more than 2 labels');
            end
            if (mod(length(labels),2) ~= 0)
                error('not implemented yet for an odd number of labels');
            end
            labels_proper = labels(~isnan(labels) & labels~=0);
            labels_proper = [ones(1,round(length(labels_proper)/2)), 1+ones(1,length(labels_proper)-round(length(labels_proper)/2))];
            labels_proper = shuffle(labels_proper);
            labels(~isnan(labels) & labels~=0) = labels_proper;
            
        % Or just shuffle existing regressors?
        elseif randomizeLabels == 1
            out('Shuffling existing labels only...');
            labels_proper = labels(~isnan(labels) & labels~=0);
            labels_proper = shuffle(labels_proper);
            labels(~isnan(labels) & labels~=0) = labels_proper;
        end
	
end
