% Applies a phase filter to a given data matrix or volume.
% 
% For example, if there are 2 features per example, such as 'decide' and
% 'monitor' activity, this function allows you to, say, keep the decide
% phase only. It also allows you to choose several phases. For example,
% if the dataset contains 6 values per trial (3 values for the decide
% phase, 3 values for the monitor phase), you could specify keepPhases
% = [1 1 1 0 0 0] vs. keepPhases = [0 0 0 1 1 1].

% Kay H. Brodersen, University of Oxford / ETHZ / UZH
% -------------------------------------------------------------------------
function data = applyPhaseFilter(data, phases)
    
    % Check consistency
    assert(size(phases,1)==1);
    nReps = size(data,ndims(data)) / length(phases);
    if ~containsOnly(phases, [0 1])
        error('phase filter must only contain 0s and 1s');
    end
    if mod(size(data,ndims(data)), length(phases)) ~= 0
        error('phase filter must be a divisor of the number of examples');
    end
    
    % Before filter
    out(['Data before phase filter: ', mat2str(size(data))]);
    
    % Create phase filter
    filter = repmat(logical(phases),1,nReps);
    if ndims(data)==2
        data = data(:,filter);
    elseif ndims(data)==3
        data = data(:,:,filter);
    elseif ndims(data)==4
        data = data(:,:,:,filter);
    else
        error('dimensions > 4 not implemented yet');
    end
    
    % After filter
    out(['Data after phase filter: ', mat2str(size(data))]);
    
end
