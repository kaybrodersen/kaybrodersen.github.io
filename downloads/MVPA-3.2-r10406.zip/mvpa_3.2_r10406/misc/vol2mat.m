% Turns a volume (N x P x ... x EXAMPLE) into a matrix (N*P*... x EXAMPLES).
% Optionally also applies a mask (N x P x ...).
% 
% Usage:
%     mat = vol2mat(vol)
%     mat = vol2mat(vol, mask)
%
% Example:
%     mat_train = vol2mat(vol_train, mask)
%     
%     where vol_train is [50 50 50 120] and mask is [50 50 50],
%     returns mat_train [nLeftOverVoxels 120].

% Kay H. Brodersen, ETHZ/UZH
% $Id: vol2mat.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function mat = vol2mat(vol, mask)
    
    % Flatten data
    d_vol = ndims(vol);
    s_vol = size(vol);
    mat = reshape(vol, [prod(s_vol(1:end-1)), s_vol(end)]);
    
    % Optionally apply a mask
    if exist('mask', 'var') && ~isempty(mask)
        
        % Check dimensions
        d_mask = ndims(mask);
        s_mask = size(mask);
        if d_mask ~= d_vol-1
            error(['Since the volume has ', num2str(d_vol), ' dimensions, the mask ', ...
                'must have ', num2str(d_vol-1), ' dimensions']);
        end
        if any(s_vol(1:d_mask)~=s_mask(1:d_mask))
            error('Dimensions of data and mask are not consistent');
        end
        
        % Flatten mask
        mask = mask(:);
        
        % Apply mask
        mat = mat(mask>0,:);
    end
    
end
