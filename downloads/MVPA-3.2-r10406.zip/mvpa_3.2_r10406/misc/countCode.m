% Counts the number of lines of code in a file or a directory
% of files.
% 
% Usage:
%     count = countCode(mfile)
%     count = countCode(directory)
%     count = countCode(..., verbose)
% 
% Arguments:
%     mfile - a MATLAB file
%     directory - a directory containing MATLAB files
%     verbose - level of verbosity (0 or 1), default: 0
% 
% Return values:
%     count - a vector with two elements: the number of total
%     lines and the number of code lines.
% 
% Examples:
%     count = countCode('myscript.m');
%     count = countCode('~/studies/project/matlab');

% Kay H. Brodersen, ETH Zurich
% $ Id: $
% -----------------------------------------------------------------------------
function count = countCode(element, verbose)
	
	% Initialize code counter
	count = zeros(1,2);
	
	% Go through all files and subdirectories
	elements = dir(directory);
	for f = 1:length(elements)
		e = elements{f}.name;
		if exist(e, 'file')
			count = count + countCodeFile(e);
		elseif exist(e, 'dir')
			count = count + countCodeDir(e);
		end
	end
	
	% Print summary
	if verbose>0
		disp('SUMMARY');
		disp(element);
		disp(['   ', num2str(count(1)), ' lines']);
		disp(['   ', num2str(count(2)), ' lines of code']);
	end
	
end


function count = countCodeFile(file, verbose)
    
    % Check filename
    file = strtrim(file);
    if (strcmp(file(length(file)-1:length(file)), '.m') == 0)
        file = [file, '.m'];
    end
    
	% Initialize code counter
	count = zeros(1,2);
	
    % Open file
    fid = fopen(file, 'r');
	
    % Go through all lines
    while ~feof(fid)
        line = fgetl(fid);
        line = strtrim(line);
        
        % Count
        count(1) = count(1) + 1;
        if ~isempty(line) && ~strncmp(line, '%', 1)
            count(2) = count(2) + 1;
        end
    end
    
	% Print summary
	if verbose>0
		disp(file);
		disp(['   ', num2str(count(1)), ' lines']);
		disp(['   ', num2str(count(2)), ' lines of code']);
	end
return;
