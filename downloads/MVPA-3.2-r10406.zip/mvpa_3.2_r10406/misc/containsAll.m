% containsAll: checks whether the vector or matrix 'x' contains at least
% all of the values specified in the vector or matrix 'y'.
%
% Example:
%     containsAll([1 2 3 3 5], [1 2 3]) --> true
% 
% You can combine this with containsOnly to ensure that a vector x contains
% EXACTLY the elements specified in y.
% 
% If x is empty, returns false.
% NaN is treated like a normal number.

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function bResult = containsAll(x, y)
    bResult = containsOnly(y, x);
return;