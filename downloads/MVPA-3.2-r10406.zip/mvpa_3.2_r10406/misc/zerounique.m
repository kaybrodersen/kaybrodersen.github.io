% Returns the unique elements of a vector, ignoring 0s.
% Example: nanunique([1 2 1 0])
%     returns [1 2]
function u = zerounique(x)
    u = unique(x);
    u(u==0)=[];
end
