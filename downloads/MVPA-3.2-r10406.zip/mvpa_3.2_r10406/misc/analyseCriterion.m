% analyseCriterion - helper function to get information about a criterion
%
% Usage:
%     [types, freqs] = analyseCriterion(criterion)
%
% Example:
%     criterion = [1 2 2 2 1 2];
%     [types, freqs] = analyseCriterion(criterion);
%     --> types = [1 2]
%     --> freqs = [2 4]

% Kay H. Brodersen, University of Oxford
% $Id: analyseCriterion.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [types, freqs] = analyseCriterion(criterion)
    
    % Initialize return values
    types = zerounique(criterion);
    freqs = [];
    if any(isnan(types))
        error('criterion must not contain NaN values');
    end
    
    % Go through all types
    if isempty(types)
        types = [];
        freqs = [];
    else
        for t = types
            freqs = [freqs, sum(criterion == t)];
        end
    end
end
