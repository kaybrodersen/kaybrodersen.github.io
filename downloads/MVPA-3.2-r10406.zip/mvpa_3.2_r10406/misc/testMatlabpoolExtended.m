function results = testMatlabpoolExtended
    
%     pars(1).range = [1:10];
%     pars(2).range = [1:10];
%     results = zeros(10,10,codistributor());
%     
%     results = loop(nan(1,length(pars)), pars, results, 1);

    r = zeros(10,10,codistributor());
    for x = drange(1:10)
        for y = drange(1:10)
            pause(1);
            r(x,y) = x*y;
            disp(['(', num2str(x), ',', num2str(y), ') on ', num2str(labindex)]);
        end
    end
    res = gather(r, 1);
    if labindex == 1
        res
    end


end


%   p: current parameter index (= recursion index)
function results = loop(x, pars, results, p)
    
    % Loop over current parameter
    for i = drange(1:length(pars(p).range))
        
        % Set parameter vector
        x(p) = pars(p).range(i);
        
        % If no more parameters, evaluate parameter vector
        if p == length(pars)
            %disp(['Evaluating ', mat2str(x)]);
            v = sum(x);
            resultsX
            results.vs = [results.vs; x(1)*x(2)];
            
        % Otherwise, recurse
        else
            results = loop(x, pars, p+1);
        end
    end
    
end
