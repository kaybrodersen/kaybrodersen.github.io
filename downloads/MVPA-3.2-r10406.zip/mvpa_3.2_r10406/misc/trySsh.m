% Executes a command remotely using ssh.
%
% Usage:
%     strResult = trySsh(unixCmd, login, via);
%
% Arguments:
%     unixCmd: shell command to be executed remotely
%     login: remote login and hostname, i.e., username@host.domain.com
%     via: login and hostname of a jumping board
%
% NOTE: Make sure you have set up password-less login all the way through
% to the remote host.

% Kay Henning Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function s = trySsh(remoteCmd, login, via)

    % Check inputs
    if ~exist('login', 'var'), login = ''; end
    if ~exist('via', 'var'), via = ''; end
    if isempty(remoteCmd), error('empty remote command'); end
    if isempty(login), error('login must not be empty'); end
    
    % Turn remote command into a local command
    if isempty(via)
        localCmd = ['ssh ', login, ' ''', remoteCmd, ''''];
            
    else
        localCmd = ['ssh ', via, ' <<"EOF"', sprintf('\n'), ...
            ['ssh ', login, ' ''', remoteCmd, ''''], ...
            sprintf('\n'), 'EOF'];
    end
    
    % Wrapper to remove warnings
    if true
        localCmd = ['tmp=`', localCmd, '`; echo "$tmp" | ', ...
            'sed ''/^Warning: no access to tty (Bad file descriptor)./d'' | ', ...
            'sed ''/^Thus no job control in this shell./d'''];
    end
    
    % Execute command
    s = tryUnix(localCmd);

end
