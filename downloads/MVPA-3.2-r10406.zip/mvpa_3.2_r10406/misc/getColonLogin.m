% Turns a given login into 'login:' form, and leaves an empty string
% unchanged.
% 
% Usage:
%     colonLogin = getColonLogin(login);
% 
% Arguments:
%     login: e.g. 'bkay@brutus.ethz.ch' or ''
%
% Example:
%     unix(['rsync foo1 ', getColonLogin(login), 'foo2']);

% Kay H. Brodersen, ETHZ / UZH
% -------------------------------------------------------------------------
function colonLogin = getColonLogin(login)

    if isempty(login)
        colonLogin = '';
    elseif ~strcmp(login(end), ':')
        colonLogin = [login, ':'];
    end
end
