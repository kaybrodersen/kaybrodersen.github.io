% Prints a confusion matrix
function printCM(c)
    assert(all(size(c)==2));
    format = '%4d';
    out(['Confusion matrix: ']);
    out(['            Pred 1    Pred 2']);
    out(['Target 1      ', sprintf(format,c(1,1)), '      ', sprintf(format,c(1,2)), '     ', sprintf(format,sum(c(1,:)))]);
    out(['Target 2      ', sprintf(format,c(2,1)), '      ', sprintf(format,c(2,2)), '     ', sprintf(format,sum(c(2,:)))]);
    out(['              ', sprintf(format,sum(c(:,1))), '      ', sprintf(format,sum(c(:,2))), '     ', sprintf(format,sum(sum(c)))]);
end
