% recallData - loads previously stored data from a memory directory
%
% Can be used for subject-specific, computationally expensive data. Returns
% [] if file not found. File will always be made to have '.mat' extension.
% Use in conjunction with 'memorizeData.m'.
% 
% Usage:
%     data = recallData(dirMem, file);
%     data = recallData(dirMem, file, verbose);
%
% Default parameters:
%     verbose = true

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function data = recallData(dirMem, file, verbose)
    
    % Initialize return value
    data = [];
    
    % Check input
    if strcmpi(file(end-3:end), '.mat')
        file = file(1:end-4);
    end
    if ~exist('verbose', 'var')
        verbose = true;
    end
    
    % Does the file exist?
    completeFile = fullfile(dirMem, [file, '.mat']);
    if exist(completeFile, 'file')
        if verbose
            out(['Recalling stored file: ', completeFile]);
        end
        data = load(completeFile);
        if isfield(data, 'data')
            data = data.data;
        end
    end
    
return;