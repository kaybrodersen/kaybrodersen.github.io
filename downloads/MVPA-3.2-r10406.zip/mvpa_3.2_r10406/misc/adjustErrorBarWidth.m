% Adjusts error bar widths. Use in conjunction with errorbar().
%
% Usage:
%    adjustErrorBarWidth(hE)
%    adjustErrorBarWidth(hE, width)
%
% Example:
%    bar(x, mean(Y), 'BarWidth', 0.8);
%    adjustErrorBarWidth(errorbar(x, ...
%        mean(Y), nanstderr(Y), 'Color', [0 0 0], 'LineWidth', 2));

% -------------------------------------------------------------------------
function adjustErrorBarWidth(hE, width)
    if ~exist('width', 'var')
        width = 0.2;
    end
    
    hE_c                   = ...
        get(hE     , 'Children'    );
    errorbarXData          = ...
        get(hE_c(2), 'XData'       );
    errorbarXData(4:9:end) = ...
        errorbarXData(1:9:end) - width;
    errorbarXData(7:9:end) = ....
        errorbarXData(1:9:end) - width;
    errorbarXData(5:9:end) = ...
        errorbarXData(1:9:end) + width;
    errorbarXData(8:9:end) = ...
        errorbarXData(1:9:end) + width;
    set(hE_c(2), 'XData', errorbarXData);

return;
