% Turns a p-value into a significance-stars string.
% 
% Usage:
%     star = p2star(p)

% Kay H. Brodersen, ETHZ/UZH
% $Id: p2star.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function star = p2star(p)

    if p<0.001
        star = '***';
    elseif p<0.01
        star = '**';
    elseif p<0.05
        star = '*';
    else
        star = '';
    end
    
end
