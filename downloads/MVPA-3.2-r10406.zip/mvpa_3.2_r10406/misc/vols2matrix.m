function [dat2,coords]=vols2matrix(dat4,mask);
%[dat2,ind]=vols2matrix(dat4,mask);
%takes a 4d volume and mask and returns the 2d matrix 
%(space x time) 

%mask=reshape(mask,prod(size(mask)),1)'>0;
%dat2=reshape(dat4,prod(size(mask)),size(dat4,4))';
%dat2=dat2(:,mask)';



ind=find(mask>0);
dat2=reshape(dat4,prod(size(mask)),size(dat4,4));
dat2=dat2(ind,:);

[x,y,z] = ind2sub(size(mask),ind);
coords  = [x y z];
