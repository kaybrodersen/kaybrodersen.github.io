% Turns a path based on ~ into an absolute path, i.e., replaces the tilda
% by the current user's home directory. If the input path is a cell array,
% all elements will be processed.
%
% If the optional argument 'replaceUsers' is given, then the function will
% also modify an absolute path to become an absolute path matching the
% current machine. If 'replaceUsers' is a cell array, then any of its
% elements will be considered.
%
% Usage:
%     path = makeAbsolutePath(path)
%     path = makeAbsolutePath(path, replaceUsers)
%
% Example:
%     Imagine running the following examples on a machine where ~ expands
%     to '/usr/people/kbroders':
%
%     makeAbsolutePath('~/studies/tmp')
%     --> /usr/people/kbroders/studies/tmp
%
%     makeAbsolutePath('/cluster/home/infk/bkay/studies/tmp', 'bkay')
%     --> /usr/people/kbroders/studies/tmp
%
%     makeAbsolutePath('/cluster/home/infk/bkay/studies/tmp', {'kbroders', 'bkay'})
%     --> /usr/people/kbroders/studies/tmp
% 
%     makeAbsolutePath({'~/studies','~/studies/tmp'})
%     --> {'/usr/people/kbroders/studies','/usr/people/kbroders/studies/tmp'}
% 
% See also:
%     makeHomeRelativePath

% Kay H. Brodersen, ETZH/UZH
% $Id: makeAbsolutePath.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function path = makeAbsolutePath(path, replaceUsers)
    
    % Get current user's home directory
    dirHome = tryUnix('echo ~');
    dirHome = dirHome(1:end-1); % remove CR at end of line
    
    % Go through all strings in 'path'
    wasCell = true; if ~iscell(path), path = {path}; wasCell = false; end
    for i = 1:length(path)
        thisPath = path{i};
        if ~isempty(strfind(thisPath, '~'))
            % Replace ~ by dirHome
            thisPath = strrep(thisPath, '~', dirHome);
            
        elseif exist('replaceUsers', 'var')
            % Replace any string found in 'replaceUsers' by current home
            % directory
            if ~iscell(replaceUsers), replaceUsers = {replaceUsers}; end
            for u = 1:length(replaceUsers)
                k = strfind(thisPath, replaceUsers{u});
                if ~isempty(k) & k>1 & strcmp(thisPath(k-1),filesep)
                    thisPath = fullfile(dirHome, thisPath(k+length(replaceUsers{u}):end));
                    break;
                end
            end
        end
        path{i} = thisPath;
    end
    if ~wasCell
        assert(length(path)==1)
        path = path{1};
    end
end
