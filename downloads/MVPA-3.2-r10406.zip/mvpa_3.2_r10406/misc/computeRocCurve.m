% Computes an ROC curve for classification results.
% 
% Usage:
%     [x,y] = computeRocCurve(values, corrects)
% 
% Arguments:
%     values: decision values of the classifier (e.g., distance from
%         hyperplane). The sign of a value should reflect the final
%         decision, and the magnitude should reflect the degree of
%         certainty of the classifier in assigning this label.
%     corrects: boolean vector of the same length as 'values', specifying
%         whether a given guess was correct or incorrect
% 
% Kay H. Brodersen, ETHZ/UZH
% $Id: computeRocCurve.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [rocX,rocY] = computeRocCurve(values, corrects)
    
warning('Who does actually still use this function??');
    
    
    % Check input
    values = values(:);
    corrects = logical(corrects(:));
    assert(length(values)==length(corrects));
    
    % Sort by value (ascending order)
    [I,I] = sort(values);
    values = values(I);
    corrects = corrects(I);
    
    % Make curve
    rocX = [];
    rocY = [];
    nFalses = sum(~corrects);
    for i = 1:length(values)
        rocX = [rocX, values(i)];
        rocY = [rocY, (sum(~corrects(1:i)))/nFalses];
    end
    
    
end