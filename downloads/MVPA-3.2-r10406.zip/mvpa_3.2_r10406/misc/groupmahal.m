% Computes the (squared) Mahalanobis distance between two groups of points
% (unlike built-in mahal, which only computes the distance between a point
% and a group).
%
% Usage:
%     d2 = groupmahal(X1, X2)
%
% Arguments:
%     X1: n1 EXAMPLES x m VARIABLES matrix
%     X2: n2 EXAMPLES x m VARIABLES matrix

% Kay H. Brodersen, University of Oxford / ETZH / UZH
% $Id: groupmahal.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function d2 = groupmahal(X1, X2)
    
    % Check input
    assert(~isempty(X1) && ~isempty(X2));
    if size(X1,2) ~= size(X2,2)
        error('the two groups must have the same number of variables (columns)');
    end
    if size(X1,1)<size(X1,2)
        error('there are more variables than examples - cannot compute Mahalanobis distance');
    end
    
    % Compute covariance matrices
    C1 = cov(X1);
    C2 = cov(X2);
    
    % Compute pooled covariance matrix
    n1 = size(X1,1);
    n2 = size(X2,1);
    PC = (n1*C1 + n2*C2) / (n1+n2);
    
    % Compute difference in means for all variables
    dm = mean(X1,1)-mean(X2,1);
    
    % Compute Mahalanobis distance
    warning off
    d2 = dm/PC*dm';
    warning on
    
    % If matrix was singular to working precision, use the pseudo-inverse
    if isnan(d2)
        d2 = dm*pinv(PC)*dm';
    end

end
