% Finds a name for a new temporary file id and locks it by creating a file
% called '{id}.tmp' in the specified temp directory.
%
% Example:
%     dirTmp = getDirTmp;
%     id = getUniqueFileId(dirTmp);
%     save(fullfile(dirTmp, [id, '-mydata.mat']), 'myData');

% Kay H. Brodersen, University of Oxford
% -------------------------------------------------------------------------
function id = getUniqueFileId(dir)

    % Indefinite loop
    success = false;
    for i=1000
        % Create file id
        c = clock; c = round(c(6)*100);
        id = [datestr(now, 'yyyymmdd-HHMMSS'), '-', num2str(c), '-', num2str(round(rand*10000))];
        
        % Create lock filename
        candidateFile = [fullfile(dir, id), '.tmp'];
        
        % Check whether not existent yet
        if ~exist(candidateFile,'file')
            % Create
            unix(['touch ', candidateFile]);
            success = true;
            break;
        end
    end
    if ~success
        error('max iterations reached');
    end
    
return;