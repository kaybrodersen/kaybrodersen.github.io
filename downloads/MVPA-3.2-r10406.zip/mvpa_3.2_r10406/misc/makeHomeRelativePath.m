% Turns an absolute path into a home-relative path, i.e., starting with a
% tilda (~). If the current user's home directory cannot be found at the
% beginning of the given path, no changes are made.
%
% Usage:
%     path = makeHomeRelativePath(path)
%
% Example:
%     makeHomeRelativePath('/usr/people/kbroders/studies/decmak/scans/S_AP/tmp');
%     returns: ~/studies/decmak/scans/S_AP/tmp
%
% See also:
%     makeAbsolutePath

% Kay H. Brodersen, ETZH/UZH
% $Id: makeHomeRelativePath.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function path = makeHomeRelativePath(path)
    
    % Get current user's home directory
    dirHome = makeAbsolutePath('~');
    
    % Replace dirHome by ~ (if found)
    if strfind(path, dirHome)==1
        path = ['~', path(length(dirHome)+1:end)];
    end
    
end
