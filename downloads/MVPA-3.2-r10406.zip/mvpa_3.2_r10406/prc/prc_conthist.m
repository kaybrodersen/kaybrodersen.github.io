% Plots a contour histogram.
% 
% Usage:
%     prc_conthist(x, binWidth, color, linewidth)
% 
% Arguments:
%     x: data
%     binWidth: width of each histogram bin
%     color: line color of contour
%     linewidth: width of contour

% Copyright (C) 2010 Kay H. Brodersen and Cheng Soon Ong, ETH Zurich
% Distributed under the terms of the GNU General Public License
% (http://www.gnu.org/licenses/gpl.txt).
% $Id: prc_conthist.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function prc_conthist(x, binWidth, color, linewidth)
    
    edges = floor(min(x)/binWidth)*binWidth:binWidth:ceil(max(x)/binWidth)*binWidth;
    v = sort(repmat(edges,1,2));
    n = histc(x, edges);
    n = [0, reshape(repmat(n(1,1:end-1),2,1),1,(length(n)-1)*2), 0];
    plot(v,n,'-','color',color,'linewidth',linewidth);
    try; plotfill(v,zeros(size(v)),n, 'color', color, 'transparency', 0.2); end
    
end
