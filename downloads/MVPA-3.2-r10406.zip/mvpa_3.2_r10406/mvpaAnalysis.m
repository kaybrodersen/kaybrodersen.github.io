% Runs an MVPA analysis.
%
% Usage for an analysis in an interactive MATLAB session:
%    mvpaAnalysis('settings_kay')
%    mvpaAnalysis('settings_kay', 1:16)
% 
% Usage for an analysis in batch mode on a compute cluster:
%    batchRun('settings_kay', [1:18])
%    batchRun('~/studies/decmak/results/settings123.mat', [1:18])

% Kay H. Brodersen, ETHZ/UZH
% $Id: mvpaAnalysis.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function mvpaAnalysis(args1, args2)
    
    % ---------------------------------------------------------------------
    % Declare global variables
    global LOGFILE;
    global OUTPUT_INDENT; OUTPUT_INDENT = 0;
    global FSL_COMMAND_PREFIX; FSL_COMMAND_PREFIX = '';
    
    % Hello
    welcome;
    
    % ---------------------------------------------------------------------
    % Find settings and scans
    try, args1; catch; args1 = []; end
    try, args2; catch; args2 = []; end
    
    % Get <settings> and <iScans>
    if ischar(args1) || isempty(args1)
        % Interactive mode: create <settings> using the settings file passed
        interactive = true;
        out('INTERACTIVE MODE');
		% - settings
        if isempty(args1), error('no settings file specified'); end
		fileSettings = args1;
		settings = loadSettings(fileSettings, false);
		% - iScans
        iScans = NaN;
        % - instance
        instance = 1;
    else
        % Batch mode: load <settings> and <iScans> from disk, get working
        % instance id
        interactive = false;
        out('BATCH RUN MODE');
		% - settings
        if ~isfield(args1, 'fileSettings'), error('no fileSettings field found'), end;
		fileSettings = args1.fileSettings;
        settings = loadSettings(fileSettings);
		% - iScans
        if ~isfield(args1, 'iScans'), error('no iScans field found'), end;
        iScans = args1.iScans;
        % - instance
        if ~isfield(args1, 'instance'), args1.instance = 1; end;
        instance = args1.instance;
    end
    out(' ');
    out(['Settings ..........: ', fileSettings]);
    out(['Analysis ID .......: ', num2str(settings.analysisId)]);
    out(['Working instance ..: ', num2str(instance)]);
    
    % Locate scans on disk
    out(' ');
    out('Locating scans...');
    out(fullfile(settings.dirScans, settings.dirScansFilter));
    scans = locateScans(fullfile(settings.dirScans, settings.dirScansFilter));
    
    % If in interactive mode, pick scans to analyse, and prepare settings
    if interactive
        if isempty(args2)
            out(' ');
            out('Which scan(s) do you want to analyse interactively?');
            iScans = inputout(['Scans (1..', num2str(length(scans)), '): ']);
            if isempty(iScans), iScans = 1:length(scans); end
        else
            iScans = args2;
            out(' ');
            out(['Select scans ......: ', num2str(iScans)]);
        end
        % Finalize settings for run
        settings = finalizeSettings(settings, 'caller', 'mvpaAnalysis/interactive');
    end
    
    % Check iScans
    assert(~isempty(iScans));
    if ~containsOnly(iScans, [1:length(scans)])
        error(['The chosen scan id is not in the range of existing scans [1..', ...
            num2str(length(scans)), ']']);
    end
    
    % Warn if useMemory enabled
    if (settings.useMemory)
        out(' ');
        out(['WARNING: Previously stored files may be loaded! ', ...
            'Use ''settings.useMemory = false'' to prevent this']);
        out(' ');
    end
    
    % Ensure presence of few key settings
    try settings.skipExistingResults; catch; settings.skipExistingResults = false;end
    
    
    % ---------------------------------------------------------------------
    % Set up runtime environment
    
    % Preclaim toolbox licencess
    tryLicence(10);
    
    % Add custom matlab paths
    if isfield(settings, 'matlabPaths') && ~isempty(settings.matlabPaths)
        if isstr(settings.matlabPaths)
            addpath(settings.matlabPaths);
        else
            out(['WARNING: settings.matlabPaths should be empty or a simple ', ...
                'string with paths separated by colons (:)']);
        end
    end
    
    % Set global FSL command prefix
    try settings.fslCommandPrefix; catch; settings.fslCommandPrefix = ''; end
    FSL_COMMAND_PREFIX = settings.fslCommandPrefix;
    
    % Check paths
    out(' ');
    out('Current working directory:');
    out(['    ', pwd]);
    out(' ');
    out('Path:');
    p = path; p = p(1:min(1000,length(p)));
    out(['    ', p, '...']);
    out(' ');
    out(['Current function is:']);
    out(['    ', mfilename('fullpath')]);
    if ~interactive
        out(' ');
        out('Code expected in:');
        out(['    ', makeHomeRelativePath(settings.dirCode)]);
    end
    out(' ');
    out('Code found in:');  
    out(['    ', makeHomeRelativePath(which('mvpaAnalysis'))]);
    out(['    ', makeHomeRelativePath(which('loadLabels_wrapper'))]);
    out(['    ...']);
    if ~interactive && isempty(strfind(makeHomeRelativePath(which('analysis_wrapper')), ...
        makeHomeRelativePath(settings.dirCode)))
        out('WARNING: code not in ''settings.dirCode.'' Something wrong with your paths?');
    end
    
    
    % ---------------------------------------------------------------------
    % Initialize random number generator (optional)
    if isfield(settings, 'initRandomNumberGenerator') && settings.initRandomNumberGenerator
        tmpClock = clock;
        out(['Initializing random number generator with clock-derived seed...']);
        RandStream.setDefaultStream(RandStream('mt19937ar','Seed',rem(now,1)*1000000));
    end
    
    
    % ---------------------------------------------------------------------
    % Which cycles is this instance supposed to process?
    if ~isfield(settings, 'cycles') || isempty(settings.cycles)
        settings.cycles = 1;
    end
    assert(size(settings.cycles,1)==1);
    settings.cycles = sort(settings.cycles);
    nCyclesPerInstance = ceil(length(settings.cycles)/settings.nInstances);
    instance_cycles = settings.cycles((instance-1)*nCyclesPerInstance+1 : ...
        min(length(settings.cycles),instance*nCyclesPerInstance));
    out(' ');
    out(['Cycles processed by this instance: ', mat2str(instance_cycles)]);
    out(['There are ', num2str(settings.nInstances), ' instances overall.']);
    assert(~isempty(instance_cycles));
    
    % Start measuring wallclock time
    tic;
    
    
    % ---------------------------------------------------------------------
    % Go through all chosen scans
    for is = 1:length(iScans)
        s = iScans(is);
        
        % Create subj struct
        subj = struct;
        subj.scan = scans{s};
        
        % Set scan-specific directories within this analysis
        subj.dirScan = fullfile(settings.dirScans, subj.scan);
        subj.dirMem = fullfile(settings.dirScans, subj.scan, 'mem');
        subj.dirOut = fullfile(settings.dirAnalysis, subj.scan);
        if settings.useMemory, testWritable(subj.dirMem); end
        testWritable(subj.dirOut);
        
        % If in batch mode, create logfile
        if ~interactive
            tmpLogfile = fullfile(settings.dirLog, ['log', num2str(settings.analysisId), ...
                '_', subj.scan, '_i', num2str(instance), '.txt']);
            [LOGFILE, tmpMsg] = fopen(tmpLogfile, 'w');
        end
        
        % Show scan
        out(' ');
        out(['----------------------------------------------------------']);
        out(['SCAN ', num2str(s), '/', num2str(length(iScans)), ...
            ' (', subj.scan, ')']);
        out(['----------------------------------------------------------']);
        increaseIndent;
        
        % Create (instance-specific) subject-running file (batch mode only)
        fileSubjectRunning = fullfile(subj.dirOut, ['.running_i', num2str(instance)]);
        fileSubjectCompleted = fullfile(subj.dirOut, ['.completed_i', num2str(instance)]);
        if ~interactive
            unix(['touch ', fileSubjectRunning]);
            unix(['rm -f ', fileSubjectCompleted]);
        end        
        
        % -----------------------------------------------------------------
        % Go through all cycles that are designated for the current instance
        for cycle_counter = 1:length(instance_cycles)
            cy = instance_cycles(cycle_counter);
            
            % Print cycle (unless there is only one cycle overall)
            if length(settings.cycles)>1
                out(' ');
                out(['--------------------------------------------------']);
                out(['CYCLE ', num2str(cycle_counter), '/', ...
                    num2str(length(instance_cycles)), ' (cy ', ...
                    num2str(cy), ')']);
                out(['--------------------------------------------------']);
            end
            increaseIndent;
            
            % Store current cycle in subject
            subj.cy = cy;
            subj.nCycles = length(settings.cycles);
            
            
            % -------------------------------------------------------------
            % Run analysis
			cancel = analysis_wrapper(subj, settings, ...
				 settings.main.ana_func, settings.main.ana_args);
            if cancel
                out(['Cycle ', num2str(cy), ' cancelled after analysis.']);
                decreaseIndent;
                continue;
            end
			
            % End-of-cycle message
            out(['Cycle ', num2str(cy), ' completed.']);
            decreaseIndent;
        end % cycle cy
        
        
        % -----------------------------------------------------------------
		% Postprocessing
		if isfield(settings.main, 'postprocessing_func') ...
		    && ~isempty(settings.main.postprocessing_func)
		    postprocessing_wrapper(subj, settings, ...
                settings.main.postprocessing_func, settings.main.postprocessing_args);
        end
        
        
        % -----------------------------------------------------------------
        % End of subject
        
        % Create subject-completed file (and remove subject-running file)
        if ~interactive
            unix(['rm -f ', fileSubjectRunning]);
            unix(['touch ', fileSubjectCompleted]);
        end
        
        out(['Subject ', num2str(s), ' completed.']);
        decreaseIndent;
    end % subject s
	
    % ---------------------------------------------------------------------
    % Overall end
    elapsed = toc;
    out(' ');
    out(sprintf('Elapsed time: %02d:%02d:%02d', fix(elapsed/60/60), ...
        fix(mod(elapsed/60,60)), fix(mod(elapsed,60))));
	out(' ');
    out('Analysis completed.');
    
end
