% Reads a set of '.asc' electrophys files, converts them into a single 'D'
% file that can be read by SPM8, and performs some basic preprocessing
% (filtering, downsampling). Returns the final 'D' struct and writes all
% results to disk.
%
% NOTE: Make sure that 'spm eeg' is running in the background when
% calling this function. This is because it requires some paths to be set.
%
% Usage:
%     spm eeg
%     convertAscToSpm(filesA, filesB, dirout, downsamplingFrequency)
%
% Arguments:
%     downsamplingFrequency [Hz]
%
% Example:
%     spm eeg
%     convertAscToSpm('~/studies/audit/scans/S_A/standard-raw_*.ASC', ...
%         '~/studies/audit/scans/S_A/deviant-raw_*.ASC', ...
%         '~/studies/audit/scans/S_A/spm_200Hz/', 200);

% Kay Henning Brodersen, ETHZ/UZH
% $Id: convertAscToSpm.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function D = convertAscToSpm(filesPatternA, filesPatternB, dirout, downsamplingFrequency)
    
    % Check input
    filesPatternA = makeAbsolutePath(filesPatternA);
    filesPatternB = makeAbsolutePath(filesPatternB);
    dirout = makeAbsolutePath(dirout);
    
    % Create output directory
    mkdir(dirout);
    
    % ---------------------------------------------------------------------
    % Part 1: load .asc files
    % ---------------------------------------------------------------------
    
    % Find files
    dirin = fileparts(filesPatternA);
    filesA = dir(filesPatternA);
    filesA = {filesA.name};
    filesB = dir(filesPatternB);
    filesB = {filesB.name};
    assert(numel(filesA)>0);
    assert(numel(filesB)>0);
    assert(exist(fullfile(dirin, filesA{1}), 'file')>0);
    assert(exist(fullfile(dirin, filesB{1}), 'file')>0);
    
    % Data descriptors
    nTrials = length(filesA) + length(filesB);
    disp(['Found ', num2str(nTrials), ' files: ', num2str(length(filesA)) ' A   ', ...
        num2str(length(filesB)), ' B']);
    
    % Initialize collectors
    labels = [];
    data = cell(nTrials,1);
    iTrial = 0;
    
    % Import all A files
    disp(['Importing ', num2str(length(filesA)), ' A files...']);
    for f = 1:length(filesA)
        progress(f,length(filesA));
        iTrial = iTrial + 1;
        [time, recs] = loadAsc(fullfile(dirin, filesA{f}));
        data{iTrial} = recs;
        labels = [labels; 0];
    end
    
    % Import all B files
    disp(['Importing ', num2str(length(filesB)), ' B files...']);
    for f = 1:length(filesB)
        progress(f,length(filesB));
        iTrial = iTrial + 1;
        [time, recs] = loadAsc(fullfile(dirin, filesB{f}));
        data{iTrial} = recs;
        labels = [labels; 1];
    end
    assert(length(labels)==nTrials);
    
    % Write labels file
    disp(['Writing labels file...']);
    filelabels = fullfile(dirin, 'labelTone.txt');
    disp(['Labels will be written to: ', filelabels]);
    %input(['Continue?']);
    delete(filelabels);
    fid = fopen(filelabels, 'w');
    fprintf(fid, '%u\n', labels);
    fclose(fid);
    
    % ---------------------------------------------------------------------
    % Part 2: create ftdata struct
    % ---------------------------------------------------------------------
    
    % Construct FieldTrip struct
    disp(['Constructing FieldTrip struct...']);
    ftdata = [];
    
    % - sampling rate (Hz)
    ftdata.fsample = 1000;
    
    % - cell array of CHANNELS x TIME matrices from each trial
    % - cell array of (identical) time vectors
    nChannels = size(data{1,1},2);
    nBins = size(data{1,1},1);
    ftdata.trial = cell(nTrials,1);
    ftdata.time = cell(nTrials,1);
    for t = 1:nTrials
        progress(t,nTrials);
        ftdata.trial{t} = data{t}'; % channels x bins
        ftdata.time{t} = [0:nBins-1]/1000;
    end
    
    % - cell array of strings: list of channel names
    ftdata.label = cell(nChannels,1);
    for c = 1:nChannels
        ftdata.label{c} = ['ch', num2str(c)];
    end
    
    % ---------------------------------------------------------------------
    % Part 3: convert ftdata struct to SPM struct
    % ---------------------------------------------------------------------
    
    % Create output directory
    disp(['Converting FieldTrip struct to SPM struct...']);
    dirout = makeAbsolutePath(dirout);
    mkdir(dirout);
    
    % Convert the ftdata struct to SPM M/EEG dataset
    % and save to disk (--> 'D')
    fileD = 'D.mat';
    dirout = makeAbsolutePath(dirout);
    mkdir(dirout);
    file = fullfile(dirout, fileD);
    D = spm_eeg_ft2spm(ftdata, file);
    
    % Set channel types
    D = chantype(D, [], 'LFP');
    
    % Set condition names to true class labels
    for t = 1:nTrials
        progress(t,nTrials);
        % label 0 --> cond '1'
        % label 1 --> cond '2'
        D = conditions(D, t, num2str(labels(t)+1));
    end
    
    % Save changes, clear, load again
    D.save;
    file = fullfile(dirout, fileD);
    D = spm_eeg_load(file);
    
    % Filtering (--> 'fD')
    file = fullfile(dirout, fileD);
    S = [];
    S.D = file;
    S.filter.type = 'butterworth';
    S.filter.order = 5;
    S.filter.para = [];
    S.filter.band = 'low';
    S.filter.PHz = 100;
    D = spm_eeg_filter(S);
    
    % Artefact detection and rejection ('a')
    %spm_eeg_artefact...
    
    % Downsampling (--> 'dfD')
    file = fullfile(dirout, ['f', fileD]);
    S = [];
    S.D = file;
    S.fsample_new = downsamplingFrequency; % #### Hz #####
    D = spm_eeg_downsample(S);
    
    % Make 1st- and 2nd-half files
    D1st = clone(D, 'dfD1st.dat', [D.nchannels D.nsamples D.ntrials]);
    D2nd = clone(D, 'dfD2nd.dat', [D.nchannels D.nsamples D.ntrials]);
    D1st = reject(D1st, 2:2:D.ntrials, 1);
    D2nd = reject(D2nd, 1:2:D.ntrials, 1);
    save(D1st);
    save(D2nd);
    
    % Make trial-by-trial conditions (--> 'tdfD')
    % NOTE: Instead of using clone and then copying the data over manually,
    % could simply use 'spm_eeg_copy' instead.
    tD = clone(D, ['t' fnamedat(D)], [D.nchannels D.nsamples D.ntrials]);
    for i=1:D.nchannels
        progress(i,D.nchannels);
        tD(i,:,:) = D(i,:,:);
    end
    % Set conditions
    for t = 1:nTrials
        progress(t,nTrials);
        tD = conditions(tD, t, num2str(t));
    end
    %tD = tD.history('made trial-by-trial conditions', []);
    save(tD);
    
    % Contrast of trials [1 -1] (--> 'wfD')
    S = [];
    S.D = file;
    conds = str2num(cell2mat(D.conditions)');
    if containsOnly(conds, [0 1])
        conds(conds == 0) = -1;
    elseif containsOnly(conds, [1 2])
        conds(conds == 2) = -1;
    elseif ~containsOnly(conds, [-1 1])
        error(['unexpected conds: ', mat2str(unique(conds))]);
    end
    S.c = conds';
    S.label = {'myContrast'};
    S.WeightAve = false;
    spm_eeg_weight_epochs(S);
    
    % Done
    disp([' ']);
    disp('Conversion completed.');
    disp([' ']);
end


% -------------------------------------------------------------------------
function [time, recs] = loadAsc(file)
    
    % Load contents
    fid = fopen(file);
    s = textscan(fid, '%s%s%s', 'Headerlines', 9);
    fclose(fid);
    
    % Convert numerical format
    for c = 1:size(s,2)
        s{c} = strrep(s{c}, ',', '.');
    end
    
    % Extract values
    time = s{1};
    recs(:,1) = str2double(s{2});
    recs(:,2) = str2double(s{3});
    
end
