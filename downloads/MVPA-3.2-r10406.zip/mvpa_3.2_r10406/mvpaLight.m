% Runs an MVPA analysis. This is a lightweight version of mvpaAnalysis that
% does not require a settings file. Instead, all settings are passed as
% input arguments. Similarly, no output files are written to disk; all
% output is returned as return values.
%
% Usage:
%     mvpaLight(data,labels)
%     mvpaLight(data,labels,args)
%
% Input arguments:
%     data: FEATURES x EXAMPLES matrix
%     labels: 1 x EXAMPLES vector
%     args: optional arguments

% Kay H. Brodersen, ETHZ/UZH
% $Id: mvpaLight.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function mvpaLight(data,labels,args)
    
    % ---------------------------------------------------------------------
    % Declare global variables
    global OUTPUT_INDENT; OUTPUT_INDENT = 0;
    
    
    % ---------------------------------------------------------------------
    % Process input args
    try; args; catch; args = []; end
    defaults.setSize = 1;
    defaults.minExamplesPerClass = 1;
    args = propval(args,defaults);
    
    
    % ---------------------------------------------------------------------
    % Create settings struct
    s.analysisId = 0;
    
    % Data
    s.loadTrainData_func = @loadDataLight;
    s.loadTrainData_args.data = data;
    s.loadTestData_func = s.loadTrainData_func;
    s.loadTestData_args = s.loadTrainData_args;
    
    % Labels
    s.loadTrainLabels_func = @loadLabelsLight;
    s.loadTrainLabels_args.labels = labels;
    s.loadTestLabels_func = s.loadTrainLabels_func;
    s.loadTestLabels_args = s.loadTrainLabels_args;
    
    % Analysis
    s.main.ana_func = @anaPredictOne;
    s.useMemory = false;
    
	% Feature preprocessing
	s.main.ana_args.processFeatures_func = {@standardizeFeatures,@normalizeExamples};
    %s.main.ana_args.processFeatures_func = {};
    
    % Filter
    s.main.ana_args.loadFilter_func = [];
    s.main.ana_args.loadFilter_args = [];
    s.main.ana_args.invertFilter = false;
    
    % Cross-validation
    s.main.ana_func = @anaPredictOne;
    s.main.ana_args.cv.setSize = args.setSize;
    s.main.ana_args.cv.foldwiseBalancingType = 2;
    s.main.ana_args.cv.foldwiseExclusion = [0 0];
    s.main.ana_args.cv.minExamplesPerClass = args.minExamplesPerClass;
    s.main.ana_args.cv.verbose = 0;
    
    % Classification
    s.main.ana_args.class_args.conf_func = @conf_libsvm_optim;
    s.main.ana_args.class_args.conf_args.nFolds = 2;
    s.main.ana_args.class_args.conf_args.randomSubsetSize = [];
    
    s.main.ana_args.class_args.conf_args.pars(1).name = 't'; % type of kernel
    s.main.ana_args.class_args.conf_args.pars(1).range = 0; % linear kernel
    s.main.ana_args.class_args.conf_args.pars(2).name = 'c';
    s.main.ana_args.class_args.conf_args.pars(2).range = power(2, [-10:0.5:10]);

%     s.main.ana_args.class_args.conf_args.pars(1).name = 't'; % type of kernel
%     s.main.ana_args.class_args.conf_args.pars(1).range = 2; % RBF
%     s.main.ana_args.class_args.conf_args.pars(2).name = 'c';
%     s.main.ana_args.class_args.conf_args.pars(2).range = power(2, [-20:1:10]);
%     s.main.ana_args.class_args.conf_args.pars(3).name = 'g';
%     s.main.ana_args.class_args.conf_args.pars(3).range = power(2, [-20:1:10]);
    
    s.main.ana_args.class_args.train_func = @train_libsvm;
    s.main.ana_args.class_args.train_args = [];
    s.main.ana_args.class_args.test_func = @test_libsvm;
    s.main.ana_args.class_args.test_args = [];
    
    
    % ---------------------------------------------------------------------
    % Create subj struct
    subj = struct;
    subj.scan = 'anonymous';
    subj.dirScan = pwd;
    subj.dirMem = pwd;
    subj.dirOut = pwd;
    subj.cy = 1;
    subj.nCycles = 1;
    
    
    % -------------------------------------------------------------
    % Run analysis
    analysis_wrapper(subj, s, s.main.ana_func, s.main.ana_args);
			
end
