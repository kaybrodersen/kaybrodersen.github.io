% Adds all MVPA subdirectories to the path.
%
% Usage:
%     addMvpaPaths(dirCode)
%
% Arguments:
%     code - location of 'mvpa' (not 'mvpa/main')
%
% Example:
%     addpath('/foo/mvpa/main');
%     mvpaAddPaths('/foo/mvpa');

% Kay H. Brodersen, ETHZ/UZH
% $Id: addMvpaPaths.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function addMvpaPaths(dirCode)
    
    addpath(fullfile(dirCode, 'analysis'));
    addpath(fullfile(dirCode, 'batch'));
    addpath(fullfile(dirCode, 'balacc'));
    addpath(fullfile(dirCode, 'debug'));
    addpath(fullfile(dirCode, 'input'));
    addpath(fullfile(dirCode, 'misc'));
    addpath(fullfile(dirCode, 'postprocessing'));
    addpath(fullfile(dirCode, 'prc'));
    addpath(fullfile(dirCode, 'preprocessing'));
    addpath(fullfile(dirCode, 'recollection'));
    addpath(fullfile(dirCode, 'retrieval'));
    addpath(fullfile(dirCode, 'selection'));
    %addpath(fullfile(dirCode, ''));
    
end
