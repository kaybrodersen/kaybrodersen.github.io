% Loads settings.
% 
% (a) If fileSettings is a '.mat' fileSettings, this file will be loaded,
% and the function returns quietly. Sets settings.origin = '.mat'
%
% (b) If fileSettings is a mere string (e.g., 'settings_kay'), this
% will be treated as a function. It will be attempted to be called.
% Optionally, the user will be able to confirm the loaded analysis id. Sets
% settings.origin = '.m'
%
% (c) If fileSettings is a struct, it will be assumed to be a manually
% prepared settings struct. In this case, the function will simply return
% this struct. Sets settings.origin = '.m'
% 
% Usage:
%     settings = loadSettings(fileSettings);
%     settings = loadSettings(fileSettings, verbose);
%     settings = loadSettings(fileSettings, verbose, confirm);
%     settings = loadSettings(fileSettings, verbose, confirm, stopOnError);
%
% Parameters:
%     fileSettings: e.g., '/home/mysettings.mat' or 'settings_kay' or mySettings
%     verbose: default = true
%     confirm: asks user to confirm if settings loaded from .m fileSettings
%     stopOnError: default = true; if false then settings == [] if no
%         settings loaded
%
% Return values
%     settings
%     with an added field 'settings.fileSettings'

% Kay H. Brodersen, University of Oxford
% $Id: loadSettings.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function settings = loadSettings(fileSettings, confirm, verbose, stopOnError)
    
    % Check input
    if ~exist('confirm', 'var')
        confirm = true;
    end
    if ~exist('verbose', 'var')
        verbose = true;
    end
    if ~exist('stopOnError', 'var')
        stopOnError = true;
    end
    
    % Check whether struct
    if isstruct(fileSettings)
        settings = fileSettings;
        settings.origin = '.m';
        return;
    end
    
    % Check whether file exists
    if ~exist(fileSettings, 'file') && ~exist(fullfile(pwd, fileSettings), 'file')
        if stopOnError
            error(['File ''', fileSettings, ''' not found']);
        else
            settings = [];
            return;
        end
    end
        
    % What type of fileSettings are we given?
    if strcmpi(fileSettings(end-3:end), '.mat')
        % Try to load an existing fileSettings (.mat)
        try
            settings = load(fileSettings);
            settings = settings.settings;
        catch
            % (Have to use the old syntax because Matlab 2007a will only
            % accept this.)
            if stopOnError
                rethrow(lasterror);
            else
                settings = [];
            end
        end
        settings.origin = '.mat';
    else
        % Try to execute settings fileSettings (.m)
        if ~exist(fileSettings, 'file')
            if stopOnError
                error(['File not found: ', fileSettings]);
            else
                settings = [];
            end
        else
            [d,f,e] = fileparts(fileSettings);
            addpath(d);
            settings_func = str2func(f);
            settings = settings_func();
        end
        settings.origin = '.m';
    end
    
    % Give brief overview? Ask to confirm?
    if ~isempty(settings)
        if verbose
            briefOverview(fileSettings, settings);
        end
        if confirm
            input('Continue? ');
        end
    end            
    
    % Finally, add 'settings.fileSettings' field
    [a,b,c] = fileparts(fileSettings);
    settings.fileSettings = b;

end

% -------------------------------------------------------------------------
% Prints a brief overview of the settings that were loaded.
function briefOverview(fileSettings, settings)
    out(' ');
    out(['Loaded ''', fileSettings, ...
        ''' with analysisId ''', num2str(settings.analysisId), '''']);
end
