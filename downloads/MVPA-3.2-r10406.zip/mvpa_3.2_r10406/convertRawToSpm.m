% Reads a '.raw' electrophys file, converts it into a 'D' file that can be
% read by SPM8, and performs some basic preprocessing (filtering,
% downsampling). Returns the final 'D' struct and writes all results to
% disk.
%
% NOTE: Make sure that 'spm eeg' is running in the background when
% calling this function. This is because it requires some paths to be set.
%
% Usage:
%     spm eeg
%     convertRawToSpm(filein, fileout, downsamplingFrequency)
%
% Arguments:
%     downsamplingFrequency [Hz]
%
% Example:
%     spm eeg
%     convertRawToSpm('/usr/people/kbroders/studies/elec/scans/S_A/data_900ms.raw', ...
%         '/usr/people/kbroders/studies/elec/scans/S_A/spm_900ms_200Hz/');

% Kay Henning Brodersen, ETHZ/UZH
% $Id: convertRawToSpm.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function D = convertRawToSpm(filein, dirout, downsamplingFrequency)
    
    
    % ---------------------------------------------------------------------
    % Part 0: convert trigger times (if present)
    % ---------------------------------------------------------------------
    
    fileTrig = fullfile(fileparts(filein), 'trigger_times.mat');
    if exist(fileTrig, 'file')
        load(fileTrig);
        nTrials = size(Sweep_Start,1);
        labels = zeros(nTrials,1);
        for t = 1:nTrials
            % If a stimulus can be found in Trigger_1 between this trial's
            % timestamp and the next one, then this trial is of type 1
            a = Sweep_Start(t);
            b = Sweep_Stop(t);
            found = sum(Trigger_1 > a & Trigger_1 < b);
            if ~containsOnly(found, [0 1])
                disp(['WARNING: trial ', num2str(t), ' has ', num2str(found), ' triggers']);
            end
            labels(t) = 2 - (found>0);   % 1 vs 2
        end
        
        % Print summary
        disp(' ');
        disp('Resulting labels:');
        for c=1:2
            disp(['    Label ', num2str(c), ': ', num2str(sum(labels==c)), ' trials']);
        end
        disp(['    Sum: ', num2str(length(labels)), ' trials']);
        
        % Store labels file
        disp(' ');
        filelabels = fullfile(fileparts(filein), 'labelStimulus.txt');
        disp(['Labels will be written to: ', filelabels]);
%        input(['Continue?']);
        fid = fopen(filelabels, 'w');
        fprintf(fid, '%u\n', labels);
        fclose(fid);
        
        % Completed
        disp(' ');
%        input(['Conversion of trigger times completed. Continue with data conversion?']);
    else
%        input(['No trigger_times.mat file found. Continue with data conversion?']);
        labels = repmat([0 1], 1, 1000);
    end
   
    
    % ---------------------------------------------------------------------
    % Part 1: convert .raw file to ftdata struct
    % ---------------------------------------------------------------------
    
    % Check input
    assert(exist(filein,'file')>0);
    
    % Add paths
    addpath ~/studies/elec/matlab
    addpath ~/studies/elec/matlab/importer
    
    % Load data
    filein = makeAbsolutePath(filein);
    rfnin = filein;
    raw_in2;
    
    % Construct FieldTrip struct
    ftdata = [];
    
    % - sampling rate (Hz)
    ftdata.fsample = 1/(rbinsz/1000000);
    
    % - cell array of CHANNELS x TIME matrices from each trial
    % - cell array of (identical) time vectors
    nTrials = size(rdata,1);
    nChannels = size(rdata,2);
    nBins = size(rdata{1,1},1);
    ftdata.trial = cell(nTrials,1);
    ftdata.time = cell(nTrials,1);
    for t = 1:nTrials
        progress(t,nTrials);
        thisData = NaN(nChannels, nBins);
        for c = 1:nChannels
            thisData(c,:) = rdata{t,c}';
        end
        ftdata.trial{t} = thisData;
        %ftdata.time{t} = sweepstart(t)+([0:nBins-1]'*(rbinsz/1000000));
        ftdata.time{t} = [0:nBins-1]*(rbinsz/1000000);
    end
    
    % - cell array of strings: list of channel labels
    ftdata.label = cell(nChannels,1);
    for c = 1:nChannels
        ftdata.label{c} = ['ch', num2str(c)];
    end
    
    % ---------------------------------------------------------------------
    % Part 2: convert .raw file to ftdata struct
    % ---------------------------------------------------------------------
    
    % Create output directory
    dirout = makeAbsolutePath(dirout);
    mkdir(dirout);
    
    % Convert the ftdata struct to SPM M/EEG dataset
    % and save to disk
    fileD = 'D.mat';
    dirout = makeAbsolutePath(dirout);
    mkdir(dirout);
    file = fullfile(dirout, fileD);
    D = spm_eeg_ft2spm(ftdata, file);
    
    % Set channel types
    D = chantype(D, [], 'LFP');
    
    % Set condition names (i.e., class labels)
    for t = 1:nTrials
        D = conditions(D, t, num2str(labels(t)+1));
    end
    
    % Save changes, clear, load again
    D.save;
    file = fullfile(dirout, fileD);
    D = spm_eeg_load(file);
    
    % Filtering ('f')
    file = fullfile(dirout, fileD);
    S = [];
    S.D = file;
    S.filter.type = 'butterworth';
    S.filter.order = 5;
    S.filter.para = [];
    S.filter.band = 'low';
    S.filter.PHz = 100;
    D = spm_eeg_filter(S);
    
    % Artefact detection and rejection ('a')
    %spm_eeg_artefact...
    
    % Downsampling ('d')
    file = fullfile(dirout, ['f', fileD]);
    S = [];
    S.D = file;
    S.fsample_new = downsamplingFrequency; % #### Hz #####
    D = spm_eeg_downsample(S);
    
    % Make trial-by-trial conditions (--> 'tdfD')
    tD = clone(D, ['t' fnamedat(D)], [D.nchannels D.nsamples D.ntrials]);
    for i=1:D.nchannels
        progress(i,D.nchannels);
        tD(i,:,:) = D(i,:,:);
    end
    % Set conditions
    for t = 1:nTrials
        progress(t,nTrials);
        tD = conditions(tD, t, num2str(t));
    end
    %tD = tD.history('made trial-by-trial conditions', []);
    save(tD);
    
%     % Contrast of trials [1 -1] ('m')
%     file = fullfile(dirout, ['f', fileD]);
%     S = [];
%     S.D = file;
%     conds = str2num(cell2mat(D.conditions)');
%     if containsOnly(conds, [0 1])
%         conds(conds == 0) = -1;
%     elseif containsOnly(conds, [1 2])
%         conds(conds == 2) = -1;
%     elseif ~containsOnly(conds, [-1 1])
%         error(['unexpected conds: ', mat2str(unique(conds))]);
%     end
%     S.c = conds';
%     S.label = {'myContrast'};
%     S.WeightAve = false;
%     spm_eeg_weight_epochs(S);
    
    % Done
    disp([' ']);
    disp('Conversion completed.');
    disp([' ']);
end
