% Retrieves analysis results from a remote host and stores them locally. If
% the same analysis has also been carried out locally, any local files will
% be overwritten.
%
% Note that all files are left untouched. In particular, the settings file
% will not be changed. Thus, if absolute paths were specified in the
% settings file, recollect functions will likely not work properly after
% retrieval. Make sure only ever to specify relative paths (~) in the
% settings file.
%
% Usage:
%     retrieve_remotehost(fileSettings, varargin);
%
% Arguments:
%     fileSettings - path and filename of the presumed remote settings file
%     retrieve_args - args

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function retrieve_remotehost(fileSettings, varargin)
    
    % Check input
    defaults.login = 'bkay@brutus.ethz.ch';
    defaults.via = 'bkay@free.inf.ethz.ch';
    defaults.self = 'kbroders@iewnash.uzh.ch';
    args = propval(varargin, defaults);
    
    % Set host configuration
    remoteconf.login = args.login;
    remoteconf.via = args.via;
    remoteconf.self = args.self;
    out(' ');
    out(['Using host configuration:']);
    out(['   login ..: ', remoteconf.login]);
    out(['   via ....: ', remoteconf.via]);
    out(['   self ...: ', remoteconf.self]);
    
    % Check whether settings file present remotely
    remoteFile = fileSettings;
    [a,b,c] = fileparts(remoteFile);
    remoteFilename = [b,c];
    unixCmd = ['if [ -f ', remoteFile, ' ]; then echo 1; else echo 0; fi'];
    fileFound = str2double(trySsh(unixCmd, remoteconf.login, remoteconf.via));
    %fileFound = str2double(tryUnix(['ssh bkay@brutus.ethz.ch ''if [ -f ', remoteFile, ...
    %    ' ]; then echo 1; else echo 0; fi''']));
    %
    % Legacy
    if ~fileFound
        remoteFile = strrep(remoteFile, 'results/', 'results/mvpa/');
        unixCmd = ['if [ -f ', remoteFile, ' ]; then echo 1; else echo 0; fi'];
        fileFound = str2double(trySsh(unixCmd, remoteconf.login, remoteconf.via));
%         fileFound = str2double(tryUnix(['ssh bkay@brutus.ethz.ch ''if [ -f ', remoteFile, ...
%             ' ]; then echo 1; else echo 0; fi''']));
    end
    %
    % File found?
    if ~fileFound, error('settings file not found on Brutus'), end;
    
    % Load remote settings file (only to get path to remote analysis directory)
    tmpDir = fullfile(tempdir, getUniqueId);
    tryUnix(['mkdir -p ', tmpDir]);
    copyDir(remoteFile, tmpDir, remoteconf.login, remoteconf.via, ...
        remoteconf.self, '', true);
%     tryUnix(['rsync bkay@brutus:', remoteFile, ' ', tmpDir]);
    sremote = load(fullfile(tmpDir, remoteFilename));
    tryUnix(['rm -r ', tmpDir]);
    if isempty(sremote), error('loading remote settings file failed'); end;
    if isfield(sremote, 'settings'), sremote = sremote.settings; end
    if ~isfield(sremote, 'analysisId'), error('remote settings file is missing analysisId field'); end;
    
    % Copy remote analysis directory to local machine
    out([sremote.dirAnalysis]);
    tryUnix(['mkdir -p ', sremote.dirAnalysis]);
    copyDir([sremote.dirAnalysis, '/'], sremote.dirAnalysis, remoteconf.login, ...
        remoteconf.via, remoteconf.self, '-t', true);
%     tryUnix(['rsync -r -t bkay@brutus:', sremote.dirAnalysis, '/ ', sremote.dirAnalysis]);
    
end
