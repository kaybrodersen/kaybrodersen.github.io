% Writes the entire data matrix to a file.
%
% Implements the 'debug_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: debugExportData.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function [debug_scratch, cancel] = debugExportData(...
    subj, settings, debug_scratch, debug_args, varargin)
    
    % Get data
    try
        data_train = get_mat(subj, 'pattern', 'data_train');
    catch
        data_train = subj.mat_train;
    end
    try subj.labels; catch; subj.labels = subj.labels_train; end

    % Make tmp directory
    tryUnix(['mkdir -p ', fullfile(settings.dirBase, 'tmp')]);
    
    % Save settings
    fileSettings = fullfile(settings.dirBase, 'tmp', ['settings', num2str(settings.analysisId), '.mat']);
    save(fileSettings, 'settings');
    
    % Export data
    fileData = fullfile(settings.dirBase, 'tmp', ['data', num2str(settings.analysisId), '.txt']);
    dlmwrite(fileData, data_train, 'delimiter', '\t', 'precision', '%10.10f');
    out(['Wrote data_train to ', fileData]);
    
    % Export labels
    fileLabels = fullfile(settings.dirBase, 'tmp', ['labels', num2str(settings.analysisId), '.txt']);
    dlmwrite(fileLabels, subj.labels, 'delimiter', '\t');
    out(['Wrote labels to ', fileLabels]);
    
    % Compress
    fileArchive = fullfile(settings.dirBase, 'tmp', ['data', num2str(settings.analysisId), '.tar.gz']);
    tryUnix(['tar -cf ', fileArchive, ' ', fullfile(settings.dirBase, 'tmp', '*')]);
    out(['Compressed files into ', fileArchive]);
    
    % Stop
    cancel = true;
end
