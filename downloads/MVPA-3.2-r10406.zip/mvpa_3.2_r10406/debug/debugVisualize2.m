% Visualizes patterns.
%
% Implements the 'debug_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [debug_scratch, cancel] = debugVisualize2(...
    subj, settings, debug_scratch, debug_args)

    if ~isfield('debug_scratch','tmp')
        debug_scratch.tmp = [];
    end
    X = get_mat(subj, 'pattern', 'data_train');
    y = subj.labels;
    figure; hold on;
    title(['ROI ', num2str(tb)]);
    xlabel('time');
    colors = [0,214/255,66/255; 45/255,78/255,120/255];
    for i=1:2
        plot(X(:,y==i),'-','color',colors(i,:));
    end
    %keyboard;
    for i=1:2
        plot(X(:,y==i),'-','color',[0.8 0.8 0.8]);
    end
    for i=1:2
        plot(mean(X(:,y==i),2),'.','color',colors(i,:),'markersize',20);
        plot(mean(X(:,y==i),2)+std(X(:,y==i),0,2)/sqrt(size(X(:,y==1),2)-1),'.','color',colors(i,:),'markersize',10);
        plot(mean(X(:,y==i),2)-std(X(:,y==i),0,2)/sqrt(size(X(:,y==1),2)-1),'.','color',colors(i,:),'markersize',10);
    end
    %keyboard;
    debug_scratch.tmp = [debug_scratch.tmp, X];
    if tb==33
        X = debug_scratch.tmp;
        y = repmat(y,1,25);
        keyboard;
    end
    decreaseIndent;
    
    cancel = true;
end
