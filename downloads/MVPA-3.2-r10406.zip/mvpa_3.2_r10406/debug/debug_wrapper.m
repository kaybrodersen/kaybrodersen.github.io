% Wrapper function for debugging functionality. Used before and after the
% main analysis.
%
% Callee interface:
%     [debug_scratch, cancel] = debug_func(...
%         subj, settings, debug_scratch, debug_args)
% 
% Further varargin will be passed on to the debug function being called.
% 
% Return values:
%     debug_scratch: scratch space that is cleared at the beginning of each
%         subject
%     cancel: if set to true, mvpaAnalysis will skip current timebin after
%         the debug function

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [debug_scratch, cancel] = debug_wrapper(...
    subj, settings, debug_func, debug_args, debug_scratch, varargin)
    
    % Initialize cancel
    cancel = false;
    
    % Check input
    if ~isempty(debug_func)
        if ~iscell(debug_func)
            debug_func = {debug_func};
        end
    else
        out('(No debugging)');
        return;
    end
    
    % Go through all debugging functions in order
    for f = 1:length(debug_func)
        
        func = debug_func{f};
        out(['Debugging function ', ...
            num2str(f), '/', num2str(length(debug_func)), ': ', ...
            func2str(func)]);
        
        % Invoke function
        increaseIndent;
        func_actual = str2func(func2str(func));
        [debug_scratch, thisCancel] = func_actual(subj, settings, debug_scratch, debug_args, varargin{:});
        cancel = cancel | thisCancel;
        decreaseIndent;
    end
    
end
