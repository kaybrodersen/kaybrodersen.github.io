% Shows a 2D scatter plot of all examples. You have to specify the two
% features that are to be plotted on the two axes.
%
% Implements the 'debug_wrapper' interface.
%
% Additional named arguments:
%     'xfeature' - a feature number for the x axis
%     'yfeature' - a feature number for the y axis
%     'xlabel' - x axis label
%     'ylabel' - y axis label
%     'axis' - if given, sets the axis dimensions, e.g., [0 1 0 1]

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [debug_scratch, cancel] = debug2dScatterPlot(...
    subj, settings, debug_scratch, debug_args, varargin)

    % Check input
    defaults.xfeature = 1;
    defaults.yfeature = 2;
    defaults.xlabel = 'Feature';
    defaults.ylabel = 'Feature';
    defaults.axis = [];
    defaults.cancel = false;
    args = propval(debug_args, defaults, 'strict', false);
    %args = propval(varargin, defaults, 'strict', false);
    
    try
        data_train = get_mat(subj, 'pattern', 'data_train');
    catch
        data_train = subj.mat_train;
    end
    
    try subj.labels; catch; subj.labels = subj.labels_train; end
    
    % Define colours
    %color.lightblue = [79 129 189]/255;
    color.lightblue = [120 120 120]/255;
    color.midblue = [56 93 138]/255;
    color.lightred = [192 80 77]/255;
    color.midred = [192 0 0]/255;
        
    figure; hold on;
%     plot(data_train(args.xfeature,subj.labels==1), data_train(args.yfeature,subj.labels==1), ...
%         '.', 'color', [204 0 0]/255);
%     plot(data_train(args.xfeature,subj.labels==2), data_train(args.yfeature,subj.labels==2), ...
%         '.', 'color', [0 51 102]/255);

    % Plot in randomized order (so that classes don't overlap in a biased
    % way)
    order = randperm(size(data_train,2));
    for i=order
        if subj.labels(i)==1
            plot(data_train(args.xfeature,i), data_train(args.yfeature,i), ...
                '.', 'color', color.lightblue, 'markersize', 30);
        else
            plot(data_train(args.xfeature,i), data_train(args.yfeature,i), ...
                '.', 'color', color.midred, 'markersize', 30);
        end
    end
    
    xlabel(args.xlabel);
    ylabel(args.ylabel);
    set(gca, 'box', 'on');
    if ~isempty(args.axis)
        axis(args.axis);
    end
    title(subj.scan, 'interpreter', 'none');
    
    if isfield(args, 'results')
        s = args.results.iterations.scratchpad;
        nFeatures = size(s.model.SVs,2);
        w = repmat(s.sv_labels',1,nFeatures) ...
            .* repmat(s.model.sv_coef,1,nFeatures) ...
            .* s.model.SVs;
        w = full(sum(w,1));
        
        barh(w);
        xlabel('hyperplane component');
        ylabel('feature');
        axis ij;
        
        w(args.xfeature)/w(args.yfeature)
        
    end
    cancel = args.cancel;
end