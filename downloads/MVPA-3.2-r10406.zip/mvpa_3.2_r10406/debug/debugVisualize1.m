% Visualizes patterns.
%
% Implements the 'debug_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function [debug_scratch, cancel] = debugVisualize1(...
    subj, settings, debug_scratch, debug_args)

    data_train = get_mat(subj, 'pattern', 'data_train');
    data_test = get_mat(subj, 'pattern', 'data_test');
    figure;
    % Train/test on the same pattern?
    if nanequals(data_train, data_test)
        imagesc(data_train, [-.5 .5]); colorbar;
        xlabel([num2str(size(data_train,2)), ' samples']);
        ylabel([num2str(size(data_train,1)), ' features']);
    % Train/test on separate patterns?
    else
        subplot(1,2,1); imagesc(data_train, [-.5 .5]); colorbar;
        xlabel([num2str(size(data_train,2)), ' samples']);
        ylabel([num2str(size(data_train,1)), ' features for training']);
        subplot(1,2,2); imagesc(data_test, [-.5 .5]); colorbar;
        xlabel([num2str(size(data_test,2)), ' samples']);
        ylabel([num2str(size(data_test,1)), ' features for testing']);
    end

    % TODO: show correlation matrix, and order by label first
end