% Shows the kernel matrix of the train data (linear kernel).
%
% Implements the 'debug_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $ Id: $
% -------------------------------------------------------------------------
function [debug_scratch, cancel] = debugShowKernelMatrix(...
    subj, settings, debug_scratch, debug_args, varargin)
    
    % Get data (FEATURES x EXAMPLES) and labels (1 x EXAMPLES)
    data = get_mat(subj, 'pattern', 'data_train');
    labels = subj.labels_train;
    
    % Show kernel matrix
    showKernelMatrix(data, labels);
    
    cancel = true;
end
