% Concatenates timebin-individual maps.
% 
% Implements the 'postprocessing_wrapper' interface.

% Kay H. Brodersen, ETHZ/UZH
% $Id: concatCycleMaps.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function concatCycleMaps(subj, settings, args)
	
    % Check input
    defaults.fileOut = ['map', num2str(settings.analysisId)];
    args = propval(args, defaults);
    
	% Welcome
	out(' ');
	out(['Concatenating all ', num2str(length(settings.cycles)), ' cycle-individual maps']);
    
    % Filename for final map
    fileBase = fullfile(subj.dirOut, args.fileOut);
            
    % Make list of cycle maps
    cycleMaps = '';
    for cy = settings.cycles
        tmpFile = fullfile(subj.dirOut, ['cy', num2str(cy), '_', args.fileOut, '.nii.gz']);
        if ~exist(tmpFile, 'file'), error('invariant violated'), end
        cycleMaps = [cycleMaps, ' ', tmpFile];
    end
    
    % Call fslmerge
    tmpCmd = ['fslmerge -t ', fileBase, cycleMaps];
    out(['Invoking ''', tmpCmd, '''...']);
    tryFsl(tmpCmd);
    if ~exist([fileBase, '.nii.gz'], 'file'), error('output file not written properly'), end
    
    % Delete original cycle-individual maps
    out(['Deleting temporary files...']);
    tryUnix(['rm ', cycleMaps]);
    
end
