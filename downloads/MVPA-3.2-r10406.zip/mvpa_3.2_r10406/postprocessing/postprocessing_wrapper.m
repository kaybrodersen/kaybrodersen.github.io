% Wrapper function for postprocessing.
%
% Callee interface:
%     postprocessing_func(subj, settings, postprocessing_args);
%
% This function uses settings.errorHandling in the same way as
% analysis_wrapper.

% Kay H. Brodersen, ETHZ/UZH
% -------------------------------------------------------------------------
function postprocessing_wrapper(subj, settings, ...
	postprocessing_func, postprocessing_args)
	
    % Set default error-handling behaviour
    if ~isfield(settings, 'errorHandling') || isempty(settings.errorHandling)
        settings.errorHandling = 1;
    end
    
	% Call postprocessing function
    out(' ');
    out(['Invoking ''', which(func2str(postprocessing_func)), '''']);
    
    % No handling?
    if settings.errorHandling == 0
        postprocessing_func_actual = str2func(func2str(postprocessing_func));
    	postprocessing_func_actual(subj, settings, postprocessing_args);
    
    % Catch errors?
    elseif settings.errorHandling == 1 || settings.errorHandling == 2
        try
            postprocessing_func_actual = str2func(func2str(postprocessing_func));
            postprocessing_func_actual(subj, settings, postprocessing_args);
        catch % note backwards compatibility
            afterError(settings, mfilename);
            if settings.errorHandling == 2
                save workspace;
            end
            rethrow(lasterror);
        end
    end
    
    out(['Postprocessing completed']);
	
end
