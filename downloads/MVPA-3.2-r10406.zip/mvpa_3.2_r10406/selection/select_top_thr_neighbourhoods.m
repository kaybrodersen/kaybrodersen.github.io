% Feature selection function that selects all neighbourhoods whose central
% voxel has a score above a certain threshold.
% 
% To be used as select_features_func from within deriveMasksLegacy.
% 
% Custom arguments:
%     thr: threshold
%     adj_list [will be provided by deriveMasksLegacy]

% Kay H. Brodersen, ETHZ/UZH
% $Id: select_top_thr_neighbourhoods.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function maskvec = select_top_thr_neighbourhoods(pat, select_features_args)
    
    % Check input
    defaults.thr = 0;
    defaults.adj_list = [];
    args = propval(select_features_args, defaults, 'strict', false);
    assert(isnumeric(args.thr) && all(size(args.thr)==1));
    out(['Selecting neighbourhoods >= ', num2str(args.thr)]);
    
    % Check adjacency list
    assert(~isempty(args.adj_list), 'adjacency list must not be empty');
    
    % Initialize MASKVEC (will be a boolean vector)
    maskvec = zeros(size(pat));
    
    % Select voxels
    indPat = find(pat >= args.thr);
    for i=1:length(indPat)
        thisCentralVoxel = indPat(i);
        thisSphere = args.adj_list(thisCentralVoxel,:);
        thisSphere(thisSphere==0) = [];
        if sum(thisSphere==thisCentralVoxel)~=1
            error('invariant violated: sphere should contain its own central voxel');
        end
        if isempty(thisSphere)
            error('invariant violated: sphere cannot be empty');
        end
        maskvec(thisSphere) = 1;
    end
    
end
