% Feature selection function that selects the top N neighbourhoods.
%
% To be used as select_features_func from within deriveMasksLegacy.
% 
% Custom arguments:
%     n: number of voxels (not neighbourhoods) to select
%     adj_list [will be provided by deriveMasksLegacy]

% Kay H. Brodersen, ETHZ/UZH
% $Id: select_top_n_neighbourhoods.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function maskvec = select_top_n_neighbourhoods(pat, select_features_args)
    
    % Check input
    defaults.n = 0;
    defaults.adj_list = [];
    args = propval(select_features_args, defaults, 'strict', false);
    assert(args.n>0, 'n must be a positive integer');
    
    % Check adjacency list
    assert(~isempty(args.adj_list), 'adjacency list must not be empty');
    
    % Initialize MASKVEC (will be a boolean vector)
    maskvec = zeros(size(pat));
    
    % Sort voxels in DESCENDING order
    [~,idx] = sort(pat(~isnan(pat)), 1, 'descend');
    
    % Adjust n
    args.n = min([args.n, length(idx)]);
    
    i = 0;
    while sum(maskvec) < args.n
        i = i + 1;
        thisCentralVoxel = idx(i);
        thisSphere = args.adj_list(thisCentralVoxel,:);
        thisSphere(thisSphere==0) = [];
        assert(sum(thisSphere==thisCentralVoxel)==1, ...
            'invariant violated: neighbourhood should contain its own central voxel');
        assert(~isempty(thisSphere), ...
            'invariant violated: neighbourhood cannot be empty');
        maskvec(thisSphere) = 1;
    end
    
end
