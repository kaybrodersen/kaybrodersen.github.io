% Feature selection function that selects all voxels above a certain
% threshold (not considering neighbourhoods).
%
% To be used as select_features_func from within deriveMasksLegacy.
% 
% Custom arguments:
%     thr: threshold above which voxels will be selected

% Kay H. Brodersen, ETHZ/UZH
% $Id: select_top_thr_voxels.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function maskvec = select_top_thr_voxels(pat, select_features_args)
    
    % Check input
    defaults.thr = 0;
    args = propval(select_features_args, defaults, 'strict', false);
    assert(isnumeric(args.thr) && all(size(args.thr)==1));
    out(['Selecting voxels >= ', num2str(args.thr)]);
    
    % Initialize MASKVEC (will be a boolean vector)
    maskvec = zeros(size(pat));
    
    % Select voxels
    maskvec(pat >= args.thr) = 1;
    
end
