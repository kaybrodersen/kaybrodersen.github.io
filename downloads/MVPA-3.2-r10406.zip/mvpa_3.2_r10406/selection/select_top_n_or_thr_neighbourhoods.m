% Feature selection function that selects all neighbourhoods whose central
% voxels are among the top N voxels, or whose central voxel is above a
% certain threshold.
% 
% To be used as select_features_func from within deriveMasksLegacy.
% 
% Custom arguments:
%     n: number of voxels (not neighbourhoods) to select based on ranking
%     thr: threshold to apply
%     adj_list [will be provided by deriveMasksLegacy]

% Kay H. Brodersen, ETHZ/UZH
% $Id: select_top_n_or_thr_neighbourhoods.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function maskvec = select_top_n_or_thr_neighbourhoods(pat, select_features_args)
    
    % Check input
    defaults.n = 0;
    defaults.thr = 0;
    defaults.adj_list = [];
    args = propval(select_features_args, defaults, 'strict', false);
    assert(args.n>0, 'n must be a positive integer');
    assert(isnumeric(args.thr) && all(size(args.thr)==1));
    
    % Check adjacency list
    assert(~isempty(args.adj_list), 'adjacency list must not be empty');
    
    % Chance 1: be among the top neighbourhoods
    maskvec1 = select_top_n_neighbourhoods(pat, select_features_args);
    out(['Part 1: selected ', num2str(sum(maskvec1)), ' voxels based on n top criterion']);
    
    % Chance 2: 
    maskvec2 = select_top_thr_neighbourhoods(pat, select_features_args);
    out(['Part 2: selected ', num2str(sum(maskvec2)), ' voxels based on thr top criterion']);
    
    % Combine
    maskvec = maskvec1 | maskvec2;
    
end
