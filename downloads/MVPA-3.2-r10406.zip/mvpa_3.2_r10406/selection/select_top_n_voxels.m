% Feature selection function that selects the top N voxels (not considering
% neighbourhoods).
%
% To be used as select_features_func from within deriveMasksLegacy.
% 
% Custom arguments:
%     n: number of voxels to select

% Kay H. Brodersen, ETHZ/UZH
% $Id: select_top_n_voxels.m 10406 2011-04-26 08:12:02Z bkay $
% -------------------------------------------------------------------------
function maskvec = select_top_n_voxels(pat, select_features_args)
    
    % Check input
    defaults.n = 0;
    args = propval(select_features_args, defaults, 'strict', false);
    assert(args.n>0, 'n must be a positive integer');
    assert(isnumeric(args.n) && all(size(args.n)==[1 1]) && isint(args.n) && 1<=args.n);
    
    % Initialize MASKVEC (will be a boolean vector)
    maskvec = zeros(size(pat));
    
    % Sort voxels in DESCENDING order
    [~,idx] = sort(pat(~isnan(pat)), 1, 'descend');
    
    % Adjust n
    args.n = min([args.n, length(idx)]);
    
    % Select top voxels
    maskvec(idx(1:args.n)) = 1;
    
end
