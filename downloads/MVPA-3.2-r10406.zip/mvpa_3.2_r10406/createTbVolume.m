% For a given subject, creates a volume of time series values for each
% voxel in a given mask. For example, given n=180 subjects and k=10 desired
% time bins, the volume will be 64x64x45x(180k). The resulting volumes (one
% per subject) will be stored on disk.
%
% Note: The function obtains further settings about the dataset from
% whichever 'createSettings.m' file is on the path. See settings.tbv.*
% 
% Usage:
%     cd settings_kay;
%     createTbVolume(scan);
%
% Parameters:
%     scan (optional): in order to run the analysis on a single subject
%         only, you can give the name of the scan directory here, eg.
%         'S_AP'. If missing, all subjects will be processed in sequence.

% Kay H. Brodersen, created 21/04/2009
% -------------------------------------------------------------------------
function createTbVolume(scan)
    
    % Load settings
    settings = loadSettings;
    
    % Abbreviate some settings
    TR = settings.tbv.TR;
    if (TR~=3), disp('WARNING: TR ~= 3 may not be correctly implemented yet!'), end;
    %warning off
    
    % Which subjects?
    scans = dir(fullfile(settings.dirScans, settings.dirSubjects));
    scans = {scans.name};
    if ~exist('scan', 'var')
        iSubjects = 1:length(scans);
    else
        if strcmp(scan(end), '/')
            scan = scan(1:end-1);
        end
        disp(['Only scan to include: ', scan]);
        disp(' ');
        iSubjects = find(strcmp(scans, scan));
        if length(iSubjects) ~= 1
            error('invalid scan identifier');
        end
    end
    
    % ----------------------------------------------------
    % PART A: get mean decide and delay durations (across all subjects)
    disp(' ');
    disp('Computing mean dec and del durations...');
    
    % Initialize accumulators
    tmpDec = [];
    tmpDel = [];
    tmpMon = [];
    
    % Go through all subjects
    figure;
    nScans = 10; %length(scans);
    for s = 1:nScans
        dirScan = fullfile(settings.dirScans, scans{s});
        
        % Get event times
        [dec, del, mon] = loadEventTimes(settings.tbv.funct_loadEventTimes, dirScan, false);
        
        % Store mean durations of the trial phases (for this subject)
        tmpDec(:,s) = del(:,1)-dec(:,1);
        tmpDel(:,s) = mon(:,1)-del(:,1);
        tmpMon(:,s) = dec(2:end,1)-mon(1:end-1,1);
        
        % Visualize
        subplot(nScans,1,s);
        hist(del(:,1)-dec(:,1));
        %hist(mon(:,1)-del(:,1));
        %hist(dec(2:end,1)-mon(1:end-1,1));
        ylabel([num2str(s)]);
        axis([0 15 0 20]);
    end
    
    % Report mean
    disp(['Based on all ', num2str(length(scans)), ' subjects, we have:']);
    printInfo(tmpDec, 'Decide');
    printInfo(tmpDel, 'Delay');
    printInfo(tmpMon, 'Monitor');
    
    % Visualize distributions
    figure;
    subplot(3,1,1); hist(tmpDec(:),40); xlabel('decide (s)');
    subplot(3,1,2); hist(tmpDel(:),40); xlabel('delay (s)');
    subplot(3,1,3); hist(tmpMon(:),40); xlabel('monitor (s)');
    
    % Compute mean durations of the phases, across all subjects
    % At the same time: upsample values, such that a value at time point 3
    % is now at time point 10.
    meanFineDurDec = round(mean(tmpDec(:))*10/TR);
    meanFineDurDel = round(mean(tmpDel(:))*10/TR);
    %meanFineDurMon = round((1+5+4)*10/TR); % constant: 1 s monitor + 5 s iti + 4 s extra to be safe = 10s in total
    meanFineDurMon = round(mean(tmpMon(:))*10/TR);
    
    disp(' ');
    disp(['   meanFineDurDec: ', num2str(meanFineDurDec)]);
    disp(['   meanFineDurDel: ', num2str(meanFineDurDel)]);
    disp(['   meanFineDurMon: ', num2str(meanFineDurMon)]);
    
    % ----------------------------------------------------
    % PART B: put together time series for each voxel
    
    % Go through all subjects
    for s = iSubjects
        dirScan = fullfile(settings.dirScans, scans{s});
        fileFunc = fullfile(dirScan, settings.tbv.fileFuncData);
        fileMask = fullfile(dirScan, settings.tbv.fileMask);
        
        disp(' ');
        disp(['Processing subject ', num2str(s), '/', num2str(length(iSubjects)), ...
            ' (', scans{s}, ')']);
        disp(' ');
        
        % Inspect functional data
        dims = getVolDims(fileFunc);
        disp(['    Functional data is: ', fileFunc]);
        disp(['    Dimensions: ', mat2str(dims)]);
        nVols = dims(4);
        
        % Load mask
        disp(['    Loading mask ''', fileMask, '''...']);
        mask = read_avw(fileMask);
        nVoxels = sum(sum(sum(mask == 1)));
        disp(['    Number of voxels in mask: ', num2str(nVoxels)]);
        
        % Load timeseries for voxels in the mask
        disp('    Extracting timeseries for voxels in the mask...');
        tmpDir = getDirTmp('kbroders/ts');
        tmpFile = fullfile(tmpDir, [getUniqueFileId(tmpDir), '.txt']);
        tryFsl(['fslmeants -i ', fileFunc, ' -m ', fileMask, ...
            ' --showall -o ', tmpFile]);
        raw = load(tmpFile);
        tryUnix(['rm ', tmpFile, ' ', tmpFile(1:end-4), '.tmp']);
        disp(['    Loaded raw ', mat2str(size(raw))]);
        
        % Splitting up into coords and values
        disp('    Splitting up raw data into coords and hdrs...');
        coords = raw(1:3,:);
        hdrs = raw(4:end,:);
        if size(hdrs,1) ~= nVols
            error('unexpected number of volumes');
        end
        if size(hdrs,2) ~= nVoxels
            error('unexpected number of voxels');
        end
        disp(['    Now have coords ', mat2str(size(coords)), ' and hdrs ', mat2str(size(hdrs))]);
        
        % Check coords
        nZeros = sum(sum(coords==0));
        if nZeros>0
            disp(['    WARNING: There are ', num2str(nZeros), ' zero-coords in the dataset. These will be removed']);
            tmpProds = coords(1,:) .* coords(2,:) .* coords(3,:);
            tmpZeros = find(tmpProds==0);
            coords(:,tmpZeros) = [];
            hdrs(:,tmpZeros) = [];
            disp(['    Now have coords ', mat2str(size(coords)), ' and hdrs ', mat2str(size(hdrs))]);
            nVoxels = size(hdrs,2);
        end
        
        % Get event times
        [dec, del, mon] = loadEventTimes(settings.tbv.funct_loadEventTimes, dirScan);
        disp(['    Loaded ', num2str(size(dec,1)), ' events']);
        
        % Get number of trials
        nTrials = length(dec); % 180
        
        % Normalize timeseries?
        if settings.tbv.normalizeHdrs
            disp('    Normalizing time series...');
            hdrs = normalise(hdrs,2);
        end
        
        % Interpolate the signals (10-fold)
        disp('    Interpolating the signals...');
        t = 0:size(hdrs,1)-1;             % Indices of hdr values in TR resolution
        t_ups = 0:0.1:size(hdrs,1)-1;     % Indices in 10-fold higher resolution
        hdrs_ups = spline(t, hdrs', t_ups);  % interpolate hdr in high resolution
        hdrs_ups = hdrs_ups';
        disp(['    Now have hdrs_up ', mat2str(size(hdrs_ups))]);
        
        % Upsampling of timestamps
        fineDec = round(dec(:,1)*10/TR);
        fineDel = round(del(:,1)*10/TR);
        fineMon = round(mon(:,1)*10/TR);
        
        % Initialize output volume
        disp(['    Initializing output volume...']);
        vol = zeros(dims(1), dims(2), dims(3), nTrials*settings.tbv.nBins);
        disp(['    vol ', mat2str(size(vol))]);
        
        % For each voxel
        disp('    Processing all voxels...');
        for v = 1:nVoxels
            progress(v, nVoxels);
            
            % Get hdr_ups of current voxel
            hdr_ups = hdrs_ups(:, v)';
            
            % Make '180 trials x high-res-timestamps' grid matrix
%             % (i) LEFT alignment of decide phase (cue alignment)
%             tmpL =       repmat(fineDec, 1, meanFineDurDec) + repmat(0:meanFineDurDec-1, nTrials, 1);
%             tmpL = [tmpL repmat(fineDel, 1, meanFineDurDel) + repmat(0:meanFineDurDel-1, nTrials, 1)];
%             tmpL = [tmpL repmat(fineMon, 1, meanFineDurMon) + repmat(0:meanFineDurMon-1, nTrials, 1)];
%             tmpL(find(tmpL>length(hdr_ups))) = length(hdr_ups);
            
            % (a) Align to decision ('right alignment of decide phase')
            tmpA =       repmat(fineDel-meanFineDurDec, 1, meanFineDurDec) + repmat(0:meanFineDurDec-1, nTrials, 1);
            tmpA = [tmpA repmat(fineDel, 1, meanFineDurDel) + repmat(0:meanFineDurDel-1, nTrials, 1)];
            %tmpA = [tmpA repmat(fineMon, 1, meanFineDurMon) + repmat(0:meanFineDurMon-1, nTrials, 1)];
            
            % (b) Align to outcome
            tmpB =       repmat(fineMon-meanFineDurDel, 1, meanFineDurDel) + repmat(0:meanFineDurDel-1, nTrials, 1);
            tmpB = [tmpB repmat(fineMon, 1, meanFineDurMon) + repmat(0:meanFineDurMon-1, nTrials, 1)];
            
            % Correct for haemodynamic delay
            tmpA = tmpA + round(settings.tbv.hdDelay*10/TR);
            tmpB = tmpB + round(settings.tbv.hdDelay*10/TR);
            
            % Make sure no values beyond the end of the overall timeseries
            % are included
            tmpA(find(tmpA>length(hdr_ups))) = length(hdr_ups);
            tmpB(find(tmpB>length(hdr_ups))) = length(hdr_ups);
            
            % Now take interpolated hdr values at grid matrix times
            hdrUpsGridA = hdr_ups(tmpA);  % all trials x timestamps
            hdrUpsGridB = hdr_ups(tmpB);  % (in true experimental order)
            
            % Visualize the first three voxels
            if 1
                figure
                plot([hdrUpsGridA(1:3,:),hdrUpsGridB(1:3,:)]')
            end
            
            % Join the two grids
            hdrUpsGrid = [hdrUpsGridA, hdrUpsGridB];
            
            % Sample the grid at <k> points
            samplingPoints = round(linspace(1,size(hdrUpsGrid,2),settings.tbv.nBins));
            sampledGrid = hdrUpsGrid(:,samplingPoints);
            
            % Put all trials in series
            entireSeries = reshape(sampledGrid', size(sampledGrid,1)*size(sampledGrid,2),1);
            
            % Insert into output volume
            x = coords(1,v);
            y = coords(2,v);
            z = coords(3,v);
            vol(x,y,z,:) = entireSeries;
            
        end % voxel v
        
        % Check volume
        if sum(sum(sum(sum(isnan(vol))))) > 0
            error('There are NaN values in the volume');
        end
        
        % Store volume on disk
        tmpFilename = fullfile(dirScan, settings.tbv.dirVolumeOut, settings.tbv.fileVolumeOut);
        disp(['    Saving volume ', mat2str(size(vol))]);
        disp(['    as ''', tmpFilename, '.nii.gz''...']);
        
% TODO: replace [3 3 3 3] by real values!!!!!!
disp(['TODO: REPLACE [3 3 3 3] header by actual values!!!!!!!!!!']);
        save_avw(vol, tmpFilename, 'f', [3 3 3 3]);
        %disp('    Removing NaNs...');
        %unix(['fslmaths ', tmpFilename, ' -nan ', tmpFilename]);
        
        disp(['    Subject ', num2str(s), ' complete']);
    end % subject s
    
    disp(' ');
    disp('Script complete');
end

% -------------------------------------------------------------------------
% Returns vectors that contain all event times in the true experimental
function [dec, del, mon] = loadEventTimes(funct_loadEventTimes, dirScan, verbose)
    
    % Check input
    if ~exist('verbose', 'var')
        verbose = false;
    end
    
    % Load classes
    out(['    Loading event times using ''', func2str(funct_loadEventTimes), ...
        ''' from ''', dirScan, ''''], verbose);
    [dec, del, mon] = funct_loadEventTimes(dirScan);
    
    % We only need the first column
    dec = dec(:,1);
    del = del(:,1);
    mon = mon(:,1);
    
    % Check return value
    if size(dec,1) ~= size(del,1) || size(dec,1) ~= size(mon,1) || size(del,1) ~= size(mon,1)
        error('invariant violated');
    end
    if size(dec,2) ~= 1 || size(del,2) ~= 1 || size(mon,2) ~= 1
        error('invariant violated');
    end
    
end

function printInfo(values, strName)
    values = values(:);
    
    disp(['    ', strName, ':   Mean ', num2str(mean(values)), ...
        '   Std ', num2str(std(values)), ...
        '   Range [', num2str(min(values)), ' ', num2str(max(values)), ']']);
end